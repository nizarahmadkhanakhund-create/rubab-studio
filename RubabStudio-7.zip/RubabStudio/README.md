# Rubab Studio 🪕

An extremely sophisticated **acoustic musical instrument** app for Android. Pure
instrument — no cloud, no accounts, no networking. Every byte of effort goes into
**sound quality, expressivity and playability**, with the **Acoustic Rubab** as the
flagship.

Built with **Kotlin + Jetpack Compose** on top of a **C++ / Oboe** realtime audio
engine (sub-10 ms latency target), bridged via JNI.

---

## Highlights

- **24 instruments**, each with a *distinct* synthesis model and articulation set:
  - **Flagship — Acoustic Rubab**: extended Karplus–Strong with string dispersion,
    dual body resonances, jawari/bridge buzz, sympathetic resonance bank, meend
    (microtonal bends), tremolo, palm-mute, natural harmonics and velocity dynamics.
  - **Acoustic strings**: steel / nylon / 12-string guitar, oud, mandolin, banjo,
    acoustic bass.
  - **World strings**: sitar (sympathetic + buzz + meend), santoor.
  - **Classical / world**: grand piano (coupled inharmonic strings), violin, cello,
    viola (bowed stick-slip model), harmonium (free-reed drone).
  - **Winds**: concert flute, bansuri, ney, duduk (breath-excited resonator bank,
    flute↔reed morph).
  - **Percussion**: tabla (na/tin/dha/ge bols + pitch glide), dhol, frame drum,
    cajon, hand percussion (modal synthesis with open/closed/rim/bass strokes).
- **Modular instrument registry** — new instruments plug in via a single data entry
  in `InstrumentRegistry.cpp` (+ its Kotlin mirror). The engine never branches on
  instrument identity.
- **Realtime engine**: polyphonic voice pools with voice stealing, click-free
  envelopes, denormal protection, device sample-rate handling, lock-free event queue.
- **Acoustic space**: FFT (uniform-partitioned) **convolution reverb** driven by
  **procedurally generated impulse responses** (Room / Chamber / Hall / Cathedral /
  Plate) + algorithmic (Freeverb) reverb, stereo delay, chorus/ensemble, 3-band EQ,
  saturation, and an always-on **spatializer** (width + early reflections).
- **Three multi-touch surfaces**: piano keyboard, fretboard (horizontal-drag meend,
  vertical-drag vibrato), drum pads (stroke-per-pad).
- **Recording & multi-track looper**, metronome, chromatic **tuner** (on-device
  autocorrelation pitch detection), scale/chord assist (incl. ragas), **MIDI input**,
  and **WAV export**.
- **On-device innovation** (all local, no services):
  - **Markov Rubab phrase generator** + looping practice accompaniment.
  - **Heuristic articulation detection** from touch gestures.
  - **Adaptive difficulty learn mode** that reacts to your accuracy and timing.
- Haptics, animated surfaces, warm wood/amber theme (light + dark), tablet/phone
  adaptive layouts, settings persisted via DataStore.

---

## Requirements

- Android Studio **Koala (2024.1)** or newer
- **Android SDK 34**, **NDK** (r26+), **CMake 3.22.1** (install via SDK Manager)
- Min SDK **26** (Android 8.0), target/compile SDK **34**
- JDK **17**

## Build

1. Open the project in Android Studio (**File ▸ Open** → the `RubabStudio` folder).
   Android Studio will sync Gradle and offer to install any missing NDK/CMake.
2. Let it generate the Gradle wrapper JAR if prompted (or run `gradle wrapper`
   from the project root if you have a local Gradle ≥ 8.7).
3. Select a device/emulator and **Run ▶**. For true low latency, use a **physical
   device** (emulators do not expose low-latency audio paths).

Command line (with a local Gradle ≥ 8.7, or after the wrapper JAR exists):

```bash
./gradlew assembleDebug        # build the debug APK
./gradlew installDebug         # install on a connected device
```

> **Note on the Gradle wrapper:** `gradlew` / `gradlew.bat` and
> `gradle/wrapper/gradle-wrapper.properties` are included. The binary
> `gradle-wrapper.jar` is intentionally omitted (binaries aren't shipped in
> source form); Android Studio regenerates it on first sync, or run
> `gradle wrapper --gradle-version 8.9`.

## Get an APK without an x86-64 machine (GitHub Actions)

The Android toolchain (`aapt2`, `cmake`, `adb`) ships as **x86-64** binaries, so
builds fail on ARM64 hosts with `Exec format error` / `Syntax error: ")"
unexpected`. The repo includes a ready CI workflow
(`.github/workflows/android.yml`) that builds on GitHub's **x86-64** runners:

1. Push this project to a GitHub repo.
2. Open the **Actions** tab → the **Build APK** workflow runs automatically
   (or click **Run workflow**).
3. When it finishes, download the **`rubab-studio-debug-apk`** artifact — an
   installable debug APK. Enable "install unknown apps" on your phone to sideload it.

For a **signed release** APK, add repo secrets `RUBAB_KEYSTORE_BASE64`
(`base64 -w0 your.jks`), `RUBAB_STORE_PASSWORD`, `RUBAB_KEY_ALIAS`,
`RUBAB_KEY_PASSWORD`, then **Run workflow** — the `release` job produces
`rubab-studio-release-apk`.

## Release signing

Copy `keystore.properties.template` → `keystore.properties`, fill in your
keystore details (or set the `RUBAB_*` env vars on CI), then
`./gradlew assembleRelease` yields a **signed** APK. With no keystore present,
debug builds and Gradle syncs still work and the release APK is produced
unsigned (sign later with `apksigner`). Signing material is gitignored.

## Troubleshooting

- **`aapt2: Exec format error` / "AAPT2 daemon startup failed"** — you're on an
  **ARM64 Linux** host; Google's Build-Tools ship an x86-64 `aapt2` that can't
  run there. Build on an x86-64 machine, use Android Studio (which bundles a
  matching `aapt2`), or point Gradle at an ARM64 `aapt2` build via
  `android.aapt2FromMavenOverride=/abs/path/to/aapt2` in `gradle.properties`.
  This is an environment limitation, not a project issue.

## Permissions

- `RECORD_AUDIO` — **only** for the tuner and live-input monitoring (optional; the
  instrument itself needs no mic).
- `VIBRATE` — expressive haptics.
- MIDI feature — optional external controller input.

Nothing leaves the device.

---

See [`docs/ARCHITECTURE.md`](docs/ARCHITECTURE.md) for a full tour of the engine and
app layers, and [`docs/FEATURE_TIERS.md`](docs/FEATURE_TIERS.md) for the tiering of
every requested feature.
