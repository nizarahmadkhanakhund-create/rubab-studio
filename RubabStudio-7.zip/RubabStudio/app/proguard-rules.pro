# Keep JNI entry points: method names called from native must survive shrinking.
-keepclasseswithmembernames class * {
    native <methods>;
}

# The native engine calls back into this bridge by name/signature.
-keep class com.epic.rubab.engine.NativeBridge { *; }
-keep class com.epic.rubab.engine.NativeAudioCallback { *; }

# Kotlin metadata / coroutines
-keepclassmembers class kotlinx.** { *; }
-dontwarn kotlinx.**

# Compose keeps itself; just silence optional warnings.
-dontwarn org.jetbrains.annotations.**
