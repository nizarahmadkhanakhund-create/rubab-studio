#include "ConvolutionReverb.h"
#include "../util/DspMath.h"
#include <cmath>
#include <algorithm>

namespace rubab {

void ConvolutionReverb::prepare(double sampleRate, int partition) {
    sr_ = sampleRate;
    B_ = partition;
    N_ = B_ * 2;
    fft_.resize(N_);

    inBuf_.assign(B_, 0.0f);
    scRe_.assign(N_, 0.0f);
    scIm_.assign(N_, 0.0f);
    accReL_.assign(N_, 0.0f); accImL_.assign(N_, 0.0f);
    accReR_.assign(N_, 0.0f); accImR_.assign(N_, 0.0f);
    tailL_.assign(B_, 0.0f);
    tailR_.assign(B_, 0.0f);

    fifoCap_ = B_ * 8;
    fifoL_.assign(fifoCap_, 0.0f);
    fifoR_.assign(fifoCap_, 0.0f);
    fifoRead_ = fifoWrite_ = fifoCount_ = 0;
    inCount_ = 0;
    ready_ = false;
}

void ConvolutionReverb::partitionIR(const std::vector<float>& ir, std::vector<float>& reOut,
                                    std::vector<float>& imOut, int& partsOut) {
    const int maxLen = (int)(maxTail_ * sr_);
    const int irLen = std::min((int)ir.size(), maxLen);
    const int parts = (irLen + B_ - 1) / B_;
    reOut.assign((size_t)parts * N_, 0.0f);
    imOut.assign((size_t)parts * N_, 0.0f);

    std::vector<float> re(N_), im(N_);
    for (int p = 0; p < parts; ++p) {
        std::fill(re.begin(), re.end(), 0.0f);
        std::fill(im.begin(), im.end(), 0.0f);
        for (int i = 0; i < B_; ++i) {
            const int src = p * B_ + i;
            re[i] = (src < irLen) ? ir[src] : 0.0f;
        }
        fft_.forward(re.data(), im.data());
        std::copy(re.begin(), re.end(), reOut.begin() + (size_t)p * N_);
        std::copy(im.begin(), im.end(), imOut.begin() + (size_t)p * N_);
    }
    partsOut = parts;
}

void ConvolutionReverb::loadSpace(ImpulseFactory::Space space) {
    std::vector<float> irL, irR;
    ImpulseFactory::generate(space, sr_, irL, irR);

    int pL = 0, pR = 0;
    partitionIR(irL, hReL_, hImL_, pL);
    partitionIR(irR, hReR_, hImR_, pR);
    P_ = std::max(pL, pR);
    // Pad the shorter channel's partition set so both share one FDL.
    hReL_.resize((size_t)P_ * N_, 0.0f); hImL_.resize((size_t)P_ * N_, 0.0f);
    hReR_.resize((size_t)P_ * N_, 0.0f); hImR_.resize((size_t)P_ * N_, 0.0f);

    fdlRe_.assign((size_t)P_ * N_, 0.0f);
    fdlIm_.assign((size_t)P_ * N_, 0.0f);
    fdlWrite_ = 0;
    std::fill(tailL_.begin(), tailL_.end(), 0.0f);
    std::fill(tailR_.begin(), tailR_.end(), 0.0f);
    ready_ = true;
}

void ConvolutionReverb::reset() {
    std::fill(fdlRe_.begin(), fdlRe_.end(), 0.0f);
    std::fill(fdlIm_.begin(), fdlIm_.end(), 0.0f);
    std::fill(tailL_.begin(), tailL_.end(), 0.0f);
    std::fill(tailR_.begin(), tailR_.end(), 0.0f);
    fifoRead_ = fifoWrite_ = fifoCount_ = 0;
    inCount_ = 0;
}

void ConvolutionReverb::runBlock() {
    // FFT of the zero-padded input block into the FDL slot.
    float* xr = fdlRe_.data() + (size_t)fdlWrite_ * N_;
    float* xi = fdlIm_.data() + (size_t)fdlWrite_ * N_;
    for (int i = 0; i < B_; ++i) { xr[i] = inBuf_[i]; xi[i] = 0.0f; }
    for (int i = B_; i < N_; ++i) { xr[i] = 0.0f; xi[i] = 0.0f; }
    fft_.forward(xr, xi);

    std::fill(accReL_.begin(), accReL_.end(), 0.0f);
    std::fill(accImL_.begin(), accImL_.end(), 0.0f);
    std::fill(accReR_.begin(), accReR_.end(), 0.0f);
    std::fill(accImR_.begin(), accImR_.end(), 0.0f);

    // Complex multiply-accumulate across all partitions.
    for (int p = 0; p < P_; ++p) {
        const int idx = (fdlWrite_ - p + P_) % P_;
        const float* Xr = fdlRe_.data() + (size_t)idx * N_;
        const float* Xi = fdlIm_.data() + (size_t)idx * N_;
        const float* HrL = hReL_.data() + (size_t)p * N_;
        const float* HiL = hImL_.data() + (size_t)p * N_;
        const float* HrR = hReR_.data() + (size_t)p * N_;
        const float* HiR = hImR_.data() + (size_t)p * N_;
        for (int b = 0; b < N_; ++b) {
            const float xr2 = Xr[b], xi2 = Xi[b];
            accReL_[b] += xr2 * HrL[b] - xi2 * HiL[b];
            accImL_[b] += xr2 * HiL[b] + xi2 * HrL[b];
            accReR_[b] += xr2 * HrR[b] - xi2 * HiR[b];
            accImR_[b] += xr2 * HiR[b] + xi2 * HrR[b];
        }
    }

    // IFFT and overlap-add.
    fft_.inverse(accReL_.data(), accImL_.data());
    fft_.inverse(accReR_.data(), accImR_.data());

    for (int i = 0; i < B_; ++i) {
        const float oL = accReL_[i] + tailL_[i];
        const float oR = accReR_[i] + tailR_[i];
        // push to FIFO
        fifoL_[fifoWrite_] = oL;
        fifoR_[fifoWrite_] = oR;
        fifoWrite_ = (fifoWrite_ + 1) % fifoCap_;
        if (fifoCount_ < fifoCap_) ++fifoCount_;
    }
    for (int i = 0; i < B_; ++i) {
        tailL_[i] = accReL_[B_ + i];
        tailR_[i] = accReR_[B_ + i];
    }

    fdlWrite_ = (fdlWrite_ + 1) % P_;
}

void ConvolutionReverb::process(float* left, float* right, int n) {
    if (!ready_ || wet_ <= 0.0001f) return;

    for (int k = 0; k < n; ++k) {
        inBuf_[inCount_++] = (left[k] + right[k]) * 0.5f;
        if (inCount_ >= B_) { runBlock(); inCount_ = 0; }

        float wL = 0.0f, wR = 0.0f;
        if (fifoCount_ > 0) {
            wL = fifoL_[fifoRead_];
            wR = fifoR_[fifoRead_];
            fifoRead_ = (fifoRead_ + 1) % fifoCap_;
            --fifoCount_;
        }
        left[k]  += wL * wet_;
        right[k] += wR * wet_;
    }
}

} // namespace rubab
