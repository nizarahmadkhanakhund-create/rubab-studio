#pragma once
#include <vector>
#include <cstdint>

namespace rubab {

// Procedurally generates stereo impulse responses for the convolution reverb.
// No external sample files: every acoustic space (room, chamber, hall,
// cathedral, plate) is synthesised from early-reflection patterns plus a
// damped, decorrelated diffuse tail. Called off the audio thread.
class ImpulseFactory {
public:
    enum Space { ROOM = 0, CHAMBER, HALL, CATHEDRAL, PLATE, SPACE_COUNT };

    // Fills outL/outR with a stereo IR for the given space.
    static void generate(Space space, double sampleRate,
                         std::vector<float>& outL, std::vector<float>& outR);

    static const char* spaceName(Space s);
};

} // namespace rubab
