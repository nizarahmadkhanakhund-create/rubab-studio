#pragma once
#include "../util/DspMath.h"

namespace rubab {

// Transposed Direct Form II biquad. Stable, low-noise, denormal-safe.
class Biquad {
public:
    enum Type { LOWPASS, HIGHPASS, BANDPASS, PEAK, LOWSHELF, HIGHSHELF, NOTCH };

    void setSampleRate(double sr) { sr_ = sr; }

    void set(Type type, float freq, float q, float gainDb = 0.0f);

    inline float process(float x) {
        const float y = b0_ * x + z1_;
        z1_ = b1_ * x - a1_ * y + z2_;
        z2_ = b2_ * x - a2_ * y;
        z1_ = flushDenorm(z1_);
        z2_ = flushDenorm(z2_);
        return y;
    }

    void reset() { z1_ = z2_ = 0.0f; }

private:
    double sr_ = 48000.0;
    float b0_ = 1, b1_ = 0, b2_ = 0, a1_ = 0, a2_ = 0;
    float z1_ = 0, z2_ = 0;
};

} // namespace rubab
