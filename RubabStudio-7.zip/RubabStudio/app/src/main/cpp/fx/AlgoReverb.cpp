#include "AlgoReverb.h"

namespace rubab {

// Classic Freeverb tunings (samples @ 44.1k), scaled to the actual rate.
static const int kCombTune[8]    = {1116, 1188, 1277, 1356, 1422, 1491, 1557, 1617};
static const int kAllpassTune[4] = {556, 441, 341, 225};
static const int kStereoSpread   = 23;

void AlgoReverb::prepare(double sampleRate) {
    const float scale = static_cast<float>(sampleRate / 44100.0);
    for (int i = 0; i < kCombs; ++i) {
        combL_[i].buf.assign(std::max(1, (int)(kCombTune[i] * scale)), 0.0f);
        combR_[i].buf.assign(std::max(1, (int)((kCombTune[i] + kStereoSpread) * scale)), 0.0f);
    }
    for (int i = 0; i < kAllpass; ++i) {
        apL_[i].buf.assign(std::max(1, (int)(kAllpassTune[i] * scale)), 0.0f);
        apR_[i].buf.assign(std::max(1, (int)((kAllpassTune[i] + kStereoSpread) * scale)), 0.0f);
        apL_[i].fb = apR_[i].fb = 0.5f;
    }
    updateCombs();
}

void AlgoReverb::updateCombs() {
    // Shorter, cleaner tail: lower feedback and a touch more damping.
    const float fb = roomSize_ * 0.26f + 0.6f;
    for (int i = 0; i < kCombs; ++i) {
        combL_[i].fb = combR_[i].fb = fb;
        combL_[i].damp = combR_[i].damp = 0.2f + damping_ * 0.5f;
    }
}

void AlgoReverb::setRoomSize(float v) { roomSize_ = clampf(v, 0.0f, 1.0f); updateCombs(); }
void AlgoReverb::setDamping(float v)  { damping_ = clampf(v, 0.0f, 1.0f); updateCombs(); }
void AlgoReverb::setWidth(float v)    { width_ = clampf(v, 0.0f, 1.0f); }
void AlgoReverb::setMix(float v)      { wet_ = clampf(v, 0.0f, 1.0f); }

void AlgoReverb::reset() {
    for (int i = 0; i < kCombs; ++i) {
        std::fill(combL_[i].buf.begin(), combL_[i].buf.end(), 0.0f);
        std::fill(combR_[i].buf.begin(), combR_[i].buf.end(), 0.0f);
        combL_[i].store = combR_[i].store = 0.0f;
    }
    for (int i = 0; i < kAllpass; ++i) {
        std::fill(apL_[i].buf.begin(), apL_[i].buf.end(), 0.0f);
        std::fill(apR_[i].buf.begin(), apR_[i].buf.end(), 0.0f);
    }
}

void AlgoReverb::process(float* left, float* right, int n) {
    const float dry = 1.0f - wet_;
    for (int k = 0; k < n; ++k) {
        const float inL = left[k];
        const float inR = right[k];
        const float input = (inL + inR) * 0.5f * 0.015f; // input gain

        float accL = 0.0f, accR = 0.0f;
        for (int i = 0; i < kCombs; ++i) {
            accL += combL_[i].process(input);
            accR += combR_[i].process(input);
        }
        for (int i = 0; i < kAllpass; ++i) {
            accL = apL_[i].process(accL);
            accR = apR_[i].process(accR);
        }
        // Stereo width blend.
        const float wet1 = 0.5f + width_ * 0.5f;
        const float wet2 = 0.5f - width_ * 0.5f;
        const float outL = accL * wet1 + accR * wet2;
        const float outR = accR * wet1 + accL * wet2;

        left[k]  = inL * dry + outL * wet_;
        right[k] = inR * dry + outR * wet_;
    }
}

} // namespace rubab
