#pragma once
#include "../util/DelayLine.h"
#include "../util/DspMath.h"
#include "Biquad.h"

namespace rubab {

// Spatial renderer for the acoustic stage. Widens the stereo image (mid/side),
// adds decorrelated early reflections for depth, and applies a gentle
// head-shadow tilt so sources feel placed in a room rather than panned flat.
// This is the always-on spatial layer that sits in front of the reverbs.
class Spatializer {
public:
    void prepare(double sampleRate);
    void setWidth(float w) { width_ = clampf(w, 0.0f, 2.0f); }
    void setDepth(float d) { depth_ = clampf(d, 0.0f, 1.0f); }
    void process(float* left, float* right, int n);
    void reset();

private:
    double sr_ = 48000.0;
    float width_ = 1.2f, depth_ = 0.35f;
    DelayLine erL_, erR_;
    Biquad shadowL_, shadowR_;
};

} // namespace rubab
