#include "Saturator.h"
// Saturator is header-only (inline hot path); this TU anchors the object file.
namespace rubab { /* intentionally empty */ }
