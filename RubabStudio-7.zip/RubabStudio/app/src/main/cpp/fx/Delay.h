#pragma once
#include "../util/DelayLine.h"
#include "Biquad.h"

namespace rubab {

// Stereo feedback delay with ping-pong cross-feed and a lowpass in the feedback
// path for natural, darkening repeats.
class Delay {
public:
    void prepare(double sampleRate);
    void setTimeMs(float l, float r);
    void setFeedback(float fb) { feedback_ = clampf(fb, 0.0f, 0.95f); }
    void setMix(float m) { mix_ = clampf(m, 0.0f, 1.0f); }
    void setCrossFeed(float c) { cross_ = clampf(c, 0.0f, 1.0f); }
    void setDamp(float hz);
    void process(float* left, float* right, int n);
    void reset();

private:
    double sr_ = 48000.0;
    DelayLine dl_, dr_;
    float timeL_ = 1000.0f, timeR_ = 1000.0f;
    float feedback_ = 0.35f, mix_ = 0.2f, cross_ = 0.3f;
    Biquad dampL_, dampR_;
    float fbL_ = 0.0f, fbR_ = 0.0f;
};

} // namespace rubab
