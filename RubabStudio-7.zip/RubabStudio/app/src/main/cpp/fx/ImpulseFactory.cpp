#include "ImpulseFactory.h"
#include "../util/Random.h"
#include "../util/DspMath.h"
#include <cmath>

namespace rubab {

struct SpaceSpec {
    float lengthSec;
    float decayPow;     // tail decay shape (higher = faster)
    float damping;      // tail lowpass amount (0 bright .. 1 dark)
    float erGain;       // early reflection level
    int   erCount;      // number of discrete early reflections
    float preDelayMs;
};

static SpaceSpec specFor(ImpulseFactory::Space s) {
    // Shorter, smoother, lower early-reflection levels → a diffuse studio tail
    // rather than audible slap-back echoes.
    switch (s) {
        case ImpulseFactory::ROOM:      return {0.30f, 7.0f, 0.55f, 0.28f, 5,  5.0f};
        case ImpulseFactory::CHAMBER:   return {0.60f, 6.0f, 0.48f, 0.24f, 7,  8.0f};
        case ImpulseFactory::HALL:      return {1.20f, 4.8f, 0.45f, 0.20f, 9,  16.0f};
        case ImpulseFactory::CATHEDRAL: return {2.40f, 3.4f, 0.52f, 0.16f, 11, 28.0f};
        case ImpulseFactory::PLATE:     return {0.80f, 6.0f, 0.28f, 0.14f, 4,  2.0f};
        default:                        return {0.70f, 6.0f, 0.48f, 0.22f, 7,  8.0f};
    }
}

static void buildChannel(const SpaceSpec& spec, double sr, uint32_t seed,
                         std::vector<float>& out) {
    const int len = std::max(16, (int)(spec.lengthSec * sr));
    out.assign(len, 0.0f);
    Xorshift rng(seed);

    const int preDelay = (int)(spec.preDelayMs * 0.001f * sr);

    // Diffuse tail: damped noise with exponential decay.
    float lp = 0.0f;
    const float damp = clampf(spec.damping, 0.0f, 0.95f);
    for (int i = preDelay; i < len; ++i) {
        const float t = (float)(i - preDelay) / (float)(len - preDelay);
        const float env = std::pow(1.0f - t, spec.decayPow);
        float w = rng.nextBipolar();
        lp = (1.0f - damp) * w + damp * lp;
        out[i] += lp * env;
    }

    // Early reflections: softened, diffuse taps (no loud discrete slaps).
    float tap = preDelay + 0.001f * sr;
    float g = spec.erGain;
    for (int e = 0; e < spec.erCount; ++e) {
        const int idx = (int)tap;
        if (idx < len) out[idx] += g * rng.nextBipolar();
        tap *= 1.0f + 0.45f * rng.nextUnipolar() + 0.2f;
        g *= 0.8f;
    }

    // Gentle onset (not a hard click) for a little definition.
    if (preDelay < len) out[preDelay] += 0.2f;

    // Normalise to a modest level so the wet send stays subtle.
    float peak = 1.0e-6f;
    for (float v : out) peak = std::max(peak, std::fabs(v));
    const float norm = 0.35f / peak;
    for (float& v : out) v *= norm;
}

void ImpulseFactory::generate(Space space, double sampleRate,
                              std::vector<float>& outL, std::vector<float>& outR) {
    const SpaceSpec spec = specFor(space);
    buildChannel(spec, sampleRate, 0x1234567u + space * 101u, outL);
    buildChannel(spec, sampleRate, 0x89ABCDEu + space * 211u, outR); // decorrelated
}

const char* ImpulseFactory::spaceName(Space s) {
    switch (s) {
        case ROOM: return "Room";
        case CHAMBER: return "Chamber";
        case HALL: return "Concert Hall";
        case CATHEDRAL: return "Cathedral";
        case PLATE: return "Plate";
        default: return "Space";
    }
}

} // namespace rubab
