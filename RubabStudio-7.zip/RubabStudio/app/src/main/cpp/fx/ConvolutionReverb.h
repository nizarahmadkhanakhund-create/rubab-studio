#pragma once
#include <vector>
#include "../util/Fft.h"
#include "../util/DspMath.h"
#include "ImpulseFactory.h"

namespace rubab {

// Uniform-partitioned (overlap-add) FFT convolution reverb. Convolves a mono
// send with a procedurally generated stereo impulse response to place the
// instrument in a real acoustic space. Fixed B-sample latency on the wet path.
class ConvolutionReverb {
public:
    void prepare(double sampleRate, int partition = 256);
    void loadSpace(ImpulseFactory::Space space); // off audio thread
    void setMix(float wet) { wet_ = clampf(wet, 0.0f, 1.0f); }
    void setMaxTailSec(float s) { maxTail_ = s; }
    void process(float* left, float* right, int n);
    void reset();

private:
    void partitionIR(const std::vector<float>& ir, std::vector<float>& reOut,
                     std::vector<float>& imOut, int& partsOut);
    void runBlock();

    double sr_ = 48000.0;
    int B_ = 256, N_ = 512;
    float wet_ = 0.25f;
    float maxTail_ = 0.6f;

    Fft fft_;

    // IR partitions (frequency domain), per channel: P * N bins.
    std::vector<float> hReL_, hImL_, hReR_, hImR_;
    int P_ = 0;

    // Input frequency-domain delay line.
    std::vector<float> fdlRe_, fdlIm_;
    int fdlWrite_ = 0;

    // Scratch.
    std::vector<float> inBuf_, scRe_, scIm_, accReL_, accImL_, accReR_, accImR_;
    std::vector<float> tailL_, tailR_;
    int inCount_ = 0;

    // Output FIFO.
    std::vector<float> fifoL_, fifoR_;
    int fifoRead_ = 0, fifoWrite_ = 0, fifoCount_ = 0, fifoCap_ = 0;
    bool ready_ = false;
};

} // namespace rubab
