#include "Delay.h"

namespace rubab {

void Delay::prepare(double sampleRate) {
    sr_ = sampleRate;
    const int maxSamp = (int)(2.5 * sr_);
    dl_.prepare(maxSamp);
    dr_.prepare(maxSamp);
    dampL_.setSampleRate(sr_);
    dampR_.setSampleRate(sr_);
    setDamp(4000.0f);
}

void Delay::setTimeMs(float l, float r) {
    timeL_ = clampf(l, 1.0f, 2400.0f);
    timeR_ = clampf(r, 1.0f, 2400.0f);
}

void Delay::setDamp(float hz) {
    dampL_.set(Biquad::LOWPASS, hz, 0.707f);
    dampR_.set(Biquad::LOWPASS, hz, 0.707f);
}

void Delay::reset() { dl_.clear(); dr_.clear(); fbL_ = fbR_ = 0.0f; dampL_.reset(); dampR_.reset(); }

void Delay::process(float* left, float* right, int n) {
    if (mix_ <= 0.0001f) return;
    const float dSampL = timeL_ * 0.001f * sr_;
    const float dSampR = timeR_ * 0.001f * sr_;
    for (int k = 0; k < n; ++k) {
        const float inL = left[k];
        const float inR = right[k];

        const float yL = dl_.read(dSampL);
        const float yR = dr_.read(dSampR);

        // Feedback with cross-feed (ping-pong) and damping.
        const float fbInL = dampL_.process(yL * (1.0f - cross_) + yR * cross_);
        const float fbInR = dampR_.process(yR * (1.0f - cross_) + yL * cross_);

        dl_.push(inL + fbInL * feedback_);
        dr_.push(inR + fbInR * feedback_);

        left[k]  = inL * (1.0f - mix_) + yL * mix_;
        right[k] = inR * (1.0f - mix_) + yR * mix_;
    }
}

} // namespace rubab
