#include "Spatializer.h"

namespace rubab {

void Spatializer::prepare(double sampleRate) {
    sr_ = sampleRate;
    erL_.prepare((int)(0.05 * sr_));
    erR_.prepare((int)(0.05 * sr_));
    shadowL_.setSampleRate(sr_);
    shadowR_.setSampleRate(sr_);
    shadowL_.set(Biquad::HIGHSHELF, 6000.0f, 0.707f, -2.0f);
    shadowR_.set(Biquad::HIGHSHELF, 6000.0f, 0.707f, -2.0f);
}

void Spatializer::reset() { erL_.clear(); erR_.clear(); shadowL_.reset(); shadowR_.reset(); }

void Spatializer::process(float* left, float* right, int n) {
    // Early reflection tap times (ms) for a small stage.
    const float t1L = 7.0f * 0.001f * sr_;
    const float t2L = 19.0f * 0.001f * sr_;
    const float t1R = 11.0f * 0.001f * sr_;
    const float t2R = 23.0f * 0.001f * sr_;
    const float erGain = depth_ * 0.5f;

    for (int k = 0; k < n; ++k) {
        float l = left[k];
        float r = right[k];

        // Mid/side width.
        const float mid = (l + r) * 0.5f;
        const float side = (l - r) * 0.5f * width_;
        l = mid + side;
        r = mid - side;

        // Decorrelated early reflections (depth cue).
        erL_.push(l);
        erR_.push(r);
        l += (erL_.read(t1L) * 0.6f + erR_.read(t2L) * 0.4f) * erGain;
        r += (erR_.read(t1R) * 0.6f + erL_.read(t2R) * 0.4f) * erGain;

        // Gentle head-shadow tilt.
        left[k]  = shadowL_.process(l);
        right[k] = shadowR_.process(r);
    }
}

} // namespace rubab
