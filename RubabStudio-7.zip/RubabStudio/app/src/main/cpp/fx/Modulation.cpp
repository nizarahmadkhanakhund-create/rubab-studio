#include "Modulation.h"
#include <cmath>

namespace rubab {

void Modulation::prepare(double sampleRate) {
    sr_ = sampleRate;
    const int maxSamp = (int)(0.05 * sr_);
    dl_.prepare(maxSamp);
    dr_.prepare(maxSamp);
    phase_ = 0.0f;
}

void Modulation::reset() { dl_.clear(); dr_.clear(); phase_ = 0.0f; }

void Modulation::process(float* left, float* right, int n) {
    if (mix_ <= 0.0001f) return;
    const float inc = kTwoPi * rate_ / static_cast<float>(sr_);
    const float baseSamp = baseMs_ * 0.001f * sr_;
    const float depthSamp = depthMs_ * 0.001f * sr_;
    for (int k = 0; k < n; ++k) {
        phase_ += inc; if (phase_ > kTwoPi) phase_ -= kTwoPi;
        const float modL = baseSamp + depthSamp * (0.5f + 0.5f * std::sin(phase_));
        const float modR = baseSamp + depthSamp * (0.5f + 0.5f * std::sin(phase_ + kPi * 0.5f));

        dl_.push(left[k]);
        dr_.push(right[k]);
        const float wL = dl_.read(std::max(modL, 2.0f));
        const float wR = dr_.read(std::max(modR, 2.0f));

        left[k]  = left[k]  * (1.0f - mix_) + wL * mix_;
        right[k] = right[k] * (1.0f - mix_) + wR * mix_;
    }
}

} // namespace rubab
