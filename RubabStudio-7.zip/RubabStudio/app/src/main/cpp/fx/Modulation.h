#pragma once
#include "../util/DelayLine.h"
#include "../util/DspMath.h"

namespace rubab {

// Stereo chorus / ensemble: multiple modulated delay voices widen and thicken
// the sound (lovely on santoor, 12-string, harmonium). Doubles as a subtle
// flanger at short delay times.
class Modulation {
public:
    void prepare(double sampleRate);
    void setRateHz(float r) { rate_ = clampf(r, 0.05f, 8.0f); }
    void setDepthMs(float d) { depthMs_ = clampf(d, 0.0f, 20.0f); }
    void setMix(float m) { mix_ = clampf(m, 0.0f, 1.0f); }
    void process(float* left, float* right, int n);
    void reset();

private:
    double sr_ = 48000.0;
    DelayLine dl_, dr_;
    float phase_ = 0.0f;
    float rate_ = 0.5f, depthMs_ = 6.0f, mix_ = 0.0f;
    float baseMs_ = 12.0f;
};

} // namespace rubab
