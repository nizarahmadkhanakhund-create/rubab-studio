#include "Biquad.h"
#include <cmath>

namespace rubab {

void Biquad::set(Type type, float freq, float q, float gainDb) {
    freq = clampf(freq, 10.0f, static_cast<float>(sr_ * 0.49));
    q = std::max(q, 0.0001f);
    const float w0 = kTwoPi * freq / static_cast<float>(sr_);
    const float cw = std::cos(w0);
    const float sw = std::sin(w0);
    const float alpha = sw / (2.0f * q);
    const float A = std::pow(10.0f, gainDb / 40.0f);

    float b0, b1, b2, a0, a1, a2;

    switch (type) {
        case LOWPASS:
            b0 = (1 - cw) * 0.5f; b1 = 1 - cw; b2 = b0;
            a0 = 1 + alpha; a1 = -2 * cw; a2 = 1 - alpha;
            break;
        case HIGHPASS:
            b0 = (1 + cw) * 0.5f; b1 = -(1 + cw); b2 = b0;
            a0 = 1 + alpha; a1 = -2 * cw; a2 = 1 - alpha;
            break;
        case BANDPASS:
            b0 = alpha; b1 = 0; b2 = -alpha;
            a0 = 1 + alpha; a1 = -2 * cw; a2 = 1 - alpha;
            break;
        case NOTCH:
            b0 = 1; b1 = -2 * cw; b2 = 1;
            a0 = 1 + alpha; a1 = -2 * cw; a2 = 1 - alpha;
            break;
        case PEAK:
            b0 = 1 + alpha * A; b1 = -2 * cw; b2 = 1 - alpha * A;
            a0 = 1 + alpha / A; a1 = -2 * cw; a2 = 1 - alpha / A;
            break;
        case LOWSHELF: {
            const float s = 2.0f * std::sqrt(A) * alpha;
            b0 = A * ((A + 1) - (A - 1) * cw + s);
            b1 = 2 * A * ((A - 1) - (A + 1) * cw);
            b2 = A * ((A + 1) - (A - 1) * cw - s);
            a0 = (A + 1) + (A - 1) * cw + s;
            a1 = -2 * ((A - 1) + (A + 1) * cw);
            a2 = (A + 1) + (A - 1) * cw - s;
            break;
        }
        case HIGHSHELF: {
            const float s = 2.0f * std::sqrt(A) * alpha;
            b0 = A * ((A + 1) + (A - 1) * cw + s);
            b1 = -2 * A * ((A - 1) + (A + 1) * cw);
            b2 = A * ((A + 1) + (A - 1) * cw - s);
            a0 = (A + 1) - (A - 1) * cw + s;
            a1 = 2 * ((A - 1) - (A + 1) * cw);
            a2 = (A + 1) - (A - 1) * cw - s;
            break;
        }
        default:
            b0 = 1; b1 = 0; b2 = 0; a0 = 1; a1 = 0; a2 = 0;
    }

    const float inv = 1.0f / a0;
    b0_ = b0 * inv; b1_ = b1 * inv; b2_ = b2 * inv;
    a1_ = a1 * inv; a2_ = a2 * inv;
}

} // namespace rubab
