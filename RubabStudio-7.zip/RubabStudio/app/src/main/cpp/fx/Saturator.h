#pragma once
#include "../util/DspMath.h"

namespace rubab {

// Gentle analogue-style saturation + soft limiter for the master bus. Adds
// warmth to the acoustic tone and prevents hard digital clipping on dense
// polyphony. Stereo, oversampling-free (cheap, musically transparent).
class Saturator {
public:
    void setDrive(float d) { drive_ = clampf(d, 1.0f, 8.0f); }
    void setMix(float m) { mix_ = clampf(m, 0.0f, 1.0f); }
    void setCeiling(float c) { ceiling_ = clampf(c, 0.1f, 1.0f); }

    inline void process(float* left, float* right, int n) {
        for (int k = 0; k < n; ++k) {
            left[k]  = sat(left[k]);
            right[k] = sat(right[k]);
        }
    }

private:
    inline float sat(float x) {
        const float d = fastTanh(x * drive_) / fastTanh(drive_);
        float y = x * (1.0f - mix_) + d * mix_;
        // Final soft ceiling.
        if (y > ceiling_)  y = ceiling_ + fastTanh((y - ceiling_) * 2.0f) * 0.05f;
        if (y < -ceiling_) y = -ceiling_ + fastTanh((y + ceiling_) * 2.0f) * 0.05f;
        return y;
    }
    float drive_ = 1.5f, mix_ = 0.25f, ceiling_ = 0.98f;
};

} // namespace rubab
