#pragma once
#include <vector>
#include "../util/DspMath.h"

namespace rubab {

// Freeverb-style algorithmic reverb (8 parallel combs + 4 series allpasses per
// channel). Cheap, always-available acoustic space; used alone or in series
// before the convolution reverb. Stereo.
class AlgoReverb {
public:
    void prepare(double sampleRate);
    void setRoomSize(float v);   // 0..1
    void setDamping(float v);    // 0..1
    void setWidth(float v);      // 0..1
    void setMix(float v);        // 0..1 wet
    void process(float* left, float* right, int n);
    void reset();

private:
    struct Comb {
        std::vector<float> buf; int idx = 0; float store = 0.0f; float fb = 0.0f; float damp = 0.0f;
        inline float process(float x) {
            float y = buf[idx];
            store = y * (1.0f - damp) + store * damp;
            store = flushDenorm(store);
            buf[idx] = x + store * fb;
            if (++idx >= (int)buf.size()) idx = 0;
            return y;
        }
    };
    struct Allpass {
        std::vector<float> buf; int idx = 0; float fb = 0.5f;
        inline float process(float x) {
            float y = buf[idx];
            float out = -x + y;
            buf[idx] = x + y * fb;
            if (++idx >= (int)buf.size()) idx = 0;
            return out;
        }
    };

    static constexpr int kCombs = 8;
    static constexpr int kAllpass = 4;
    Comb combL_[kCombs], combR_[kCombs];
    Allpass apL_[kAllpass], apR_[kAllpass];

    float roomSize_ = 0.7f, damping_ = 0.4f, width_ = 1.0f, wet_ = 0.3f;
    void updateCombs();
};

} // namespace rubab
