cmake_minimum_required(VERSION 3.22.1)
project(rubabengine LANGUAGES C CXX)

set(CMAKE_CXX_STANDARD 17)
set(CMAKE_CXX_STANDARD_REQUIRED ON)

# Oboe comes from the AAR as a prefab package (buildFeatures.prefab = true).
find_package(oboe REQUIRED CONFIG)

add_library(rubabengine SHARED
        native-lib.cpp
        engine/AudioEngine.cpp
        engine/VoiceAllocator.cpp
        engine/InstrumentRegistry.cpp
        engine/Recorder.cpp
        engine/WavWriter.cpp
        synth/PluckedStringVoice.cpp
        synth/BowedStringVoice.cpp
        synth/WindVoice.cpp
        synth/ModalPercussionVoice.cpp
        synth/KeyedVoice.cpp
        synth/SympatheticBank.cpp
        fx/Biquad.cpp
        fx/AlgoReverb.cpp
        fx/ConvolutionReverb.cpp
        fx/Delay.cpp
        fx/Saturator.cpp
        fx/Modulation.cpp
        fx/Spatializer.cpp
        fx/ImpulseFactory.cpp
        util/Fft.cpp
        util/Random.cpp
)

target_include_directories(rubabengine PRIVATE
        ${CMAKE_CURRENT_SOURCE_DIR}
)

target_link_libraries(rubabengine
        oboe::oboe
        android
        log
)

# Enable NEON intrinsics path on ARM when available.
if (ANDROID_ABI STREQUAL "arm64-v8a" OR ANDROID_ABI STREQUAL "armeabi-v7a")
    target_compile_definitions(rubabengine PRIVATE RUBAB_NEON=1)
endif()
