#include "Fft.h"
#include "DspMath.h"
#include <cmath>

namespace rubab {

void Fft::resize(size_t n) {
    if (n == n_) return;
    n_ = n;
    bitrev_.resize(n);
    // Precompute bit-reversal permutation.
    int logn = 0;
    while ((size_t(1) << logn) < n) ++logn;
    for (size_t i = 0; i < n; ++i) {
        int r = 0;
        for (int b = 0; b < logn; ++b) {
            if (i & (size_t(1) << b)) r |= 1 << (logn - 1 - b);
        }
        bitrev_[i] = r;
    }
    // Precompute twiddle factors for the largest stage.
    cosTab_.resize(n / 2);
    sinTab_.resize(n / 2);
    for (size_t i = 0; i < n / 2; ++i) {
        const float a = -kTwoPi * static_cast<float>(i) / static_cast<float>(n);
        cosTab_[i] = std::cos(a);
        sinTab_[i] = std::sin(a);
    }
}

void Fft::transform(float* re, float* im, bool inverse) const {
    const size_t n = n_;
    // Reorder into bit-reversed order.
    for (size_t i = 0; i < n; ++i) {
        const int j = bitrev_[i];
        if (j > static_cast<int>(i)) {
            std::swap(re[i], re[j]);
            std::swap(im[i], im[j]);
        }
    }
    // Butterflies.
    for (size_t len = 2; len <= n; len <<= 1) {
        const size_t half = len >> 1;
        const size_t stride = n / len;
        for (size_t base = 0; base < n; base += len) {
            for (size_t k = 0; k < half; ++k) {
                const size_t t = k * stride;
                float wr = cosTab_[t];
                float wi = inverse ? -sinTab_[t] : sinTab_[t];
                const size_t a = base + k;
                const size_t b = base + k + half;
                const float xr = re[b] * wr - im[b] * wi;
                const float xi = re[b] * wi + im[b] * wr;
                re[b] = re[a] - xr;
                im[b] = im[a] - xi;
                re[a] += xr;
                im[a] += xi;
            }
        }
    }
}

void Fft::forward(float* re, float* im) const {
    transform(re, im, false);
}

void Fft::inverse(float* re, float* im) const {
    transform(re, im, true);
    const float inv = 1.0f / static_cast<float>(n_);
    for (size_t i = 0; i < n_; ++i) { re[i] *= inv; im[i] *= inv; }
}

} // namespace rubab
