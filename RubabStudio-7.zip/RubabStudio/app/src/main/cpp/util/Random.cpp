#include "Random.h"
// Xorshift is fully inline in the header; this TU exists so the build system
// has an object file and to anchor any future non-inline helpers.
namespace rubab { /* intentionally empty */ }
