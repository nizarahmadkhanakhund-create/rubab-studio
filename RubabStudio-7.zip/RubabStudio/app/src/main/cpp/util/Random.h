#pragma once
#include <cstdint>

namespace rubab {

// Fast, allocation-free xorshift RNG. Each voice owns one so round-robin
// and noise excitation are deterministic per voice yet varied across voices.
class Xorshift {
public:
    explicit Xorshift(uint32_t seed = 0x9E3779B9u) : state_(seed ? seed : 1u) {}

    inline uint32_t nextU32() {
        uint32_t x = state_;
        x ^= x << 13;
        x ^= x >> 17;
        x ^= x << 5;
        state_ = x;
        return x;
    }

    // Uniform float in [-1, 1).
    inline float nextBipolar() {
        return (static_cast<float>(nextU32()) * (1.0f / 2147483648.0f)) - 1.0f;
    }

    // Uniform float in [0, 1).
    inline float nextUnipolar() {
        return static_cast<float>(nextU32()) * (1.0f / 4294967296.0f);
    }

    void seed(uint32_t s) { state_ = s ? s : 1u; }

private:
    uint32_t state_;
};

} // namespace rubab
