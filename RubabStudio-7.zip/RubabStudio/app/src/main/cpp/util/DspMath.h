#pragma once
// Header-only DSP helpers shared across the engine.
// Everything here is realtime-safe: no allocation, no locks, no exceptions.

#include <cmath>
#include <cstdint>
#include <algorithm>

namespace rubab {

constexpr float kPi      = 3.14159265358979323846f;
constexpr float kTwoPi   = 6.28318530717958647692f;
constexpr float kDenorm  = 1.0e-20f; // tiny DC offset to kill denormals

// --- Denormal protection ------------------------------------------------
// Denormals on ARM/x86 can cost 10-100x CPU in feedback loops. We add a
// vanishingly small value that is inaudible but keeps numbers normalized.
inline float flushDenorm(float x) {
    x += kDenorm;
    x -= kDenorm;
    return x;
}

// --- Clamping / mapping -------------------------------------------------
inline float clampf(float x, float lo, float hi) {
    return x < lo ? lo : (x > hi ? hi : x);
}

inline float lerp(float a, float b, float t) { return a + (b - a) * t; }

// Convert MIDI note (with fractional cents for bends) to frequency in Hz.
inline float midiToHz(float note) {
    return 440.0f * std::pow(2.0f, (note - 69.0f) / 12.0f);
}

// --- Fast approximations ------------------------------------------------
// Padé-style tanh approximation; accurate enough for saturation and bowing.
inline float fastTanh(float x) {
    if (x < -3.0f) return -1.0f;
    if (x >  3.0f) return  1.0f;
    const float x2 = x * x;
    return x * (27.0f + x2) / (27.0f + 9.0f * x2);
}

// Cubic (Catmull-Rom) interpolation for fractional delay reads.
inline float cubicInterp(float y0, float y1, float y2, float y3, float t) {
    const float a0 = -0.5f * y0 + 1.5f * y1 - 1.5f * y2 + 0.5f * y3;
    const float a1 =        y0 - 2.5f * y1 + 2.0f * y2 - 0.5f * y3;
    const float a2 = -0.5f * y0            + 0.5f * y2;
    const float a3 =                   y1;
    return ((a0 * t + a1) * t + a2) * t + a3;
}

// --- One-pole smoother for click-free parameter changes -----------------
struct OnePole {
    float a = 0.0f; // coefficient derived from time constant
    float z = 0.0f; // state

    void setTime(float timeMs, float sampleRate) {
        const float tc = std::max(timeMs, 0.01f) * 0.001f;
        a = std::exp(-1.0f / (tc * sampleRate));
    }
    inline float process(float target) {
        z = target + a * (z - target);
        return z;
    }
    void reset(float v) { z = v; }
};

// Linear attack/release envelope used to ramp voice gain in/out.
struct Ramp {
    float value = 0.0f;
    float target = 0.0f;
    float step = 0.0f;
    int   remaining = 0;

    void to(float t, int samples) {
        target = t;
        remaining = std::max(samples, 1);
        step = (target - value) / static_cast<float>(remaining);
    }
    void reset(float v) {
        value = v; target = v; step = 0.0f; remaining = 0;
    }
    inline float next() {
        if (remaining > 0) {
            value += step;
            if (--remaining == 0) value = target;
        }
        return value;
    }
    bool done() const { return remaining == 0; }
};

} // namespace rubab
