#pragma once
#include <vector>
#include "DspMath.h"

namespace rubab {

// Circular delay line with cubic-interpolated fractional read. Used for
// waveguide strings, sympathetic strings, chorus, and delay effects.
class DelayLine {
public:
    void prepare(int maxLenSamples) {
        size_ = 1;
        while (size_ < maxLenSamples + 4) size_ <<= 1; // power of two for cheap wrap
        mask_ = size_ - 1;
        buf_.assign(size_, 0.0f);
        write_ = 0;
    }

    inline void push(float x) {
        buf_[write_] = x;
        write_ = (write_ + 1) & mask_;
    }

    // Read `delay` samples in the past (delay >= 1), cubic-interpolated.
    inline float read(float delay) const {
        const float rp = static_cast<float>(write_) - delay;
        int i = static_cast<int>(std::floor(rp));
        const float frac = rp - static_cast<float>(i);
        const int i0 = (i - 1) & mask_;
        const int i1 = i & mask_;
        const int i2 = (i + 1) & mask_;
        const int i3 = (i + 2) & mask_;
        return cubicInterp(buf_[i0], buf_[i1], buf_[i2], buf_[i3], frac);
    }

    // Integer tap (no interpolation), for comb/pick-position.
    inline float readInt(int delay) const {
        return buf_[(write_ - delay) & mask_];
    }

    void clear() { std::fill(buf_.begin(), buf_.end(), 0.0f); write_ = 0; }
    int capacity() const { return size_; }

private:
    std::vector<float> buf_;
    int size_ = 0, mask_ = 0, write_ = 0;
};

} // namespace rubab
