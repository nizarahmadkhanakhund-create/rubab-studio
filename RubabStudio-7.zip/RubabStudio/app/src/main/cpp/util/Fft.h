#pragma once
#include <vector>
#include <cstddef>

namespace rubab {

// Iterative radix-2 Cooley-Tukey FFT used by the convolution reverb and the
// procedural impulse-response factory. Sizes must be powers of two.
// Not realtime-safe on construction (allocates twiddles); process() is
// allocation-free once sized.
class Fft {
public:
    void resize(size_t n);                 // n must be power of two
    size_t size() const { return n_; }

    // In-place complex FFT. re/im length == n.
    void forward(float* re, float* im) const;
    void inverse(float* re, float* im) const; // includes 1/n scaling

private:
    void transform(float* re, float* im, bool inverse) const;

    size_t n_ = 0;
    std::vector<int>   bitrev_;
    std::vector<float> cosTab_;
    std::vector<float> sinTab_;
};

} // namespace rubab
