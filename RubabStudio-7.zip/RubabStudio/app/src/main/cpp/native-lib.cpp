#include <jni.h>
#include <memory>
#include <string>
#include "engine/AudioEngine.h"
#include "engine/InstrumentRegistry.h"

using namespace rubab;

// Single global engine instance. Created on nativeInit, torn down on destroy.
static std::unique_ptr<AudioEngine> gEngine;

extern "C" {

JNIEXPORT jboolean JNICALL
Java_com_epic_rubab_engine_NativeBridge_nativeInit(JNIEnv*, jobject) {
    if (!gEngine) gEngine = std::make_unique<AudioEngine>();
    return gEngine->start() ? JNI_TRUE : JNI_FALSE;
}

JNIEXPORT void JNICALL
Java_com_epic_rubab_engine_NativeBridge_nativeDestroy(JNIEnv*, jobject) {
    if (gEngine) { gEngine->stop(); gEngine.reset(); }
}

JNIEXPORT jdouble JNICALL
Java_com_epic_rubab_engine_NativeBridge_nativeSampleRate(JNIEnv*, jobject) {
    return gEngine ? gEngine->sampleRate() : 0.0;
}

JNIEXPORT jint JNICALL
Java_com_epic_rubab_engine_NativeBridge_nativeActiveVoices(JNIEnv*, jobject) {
    return gEngine ? gEngine->activeVoices() : 0;
}

JNIEXPORT jint JNICALL
Java_com_epic_rubab_engine_NativeBridge_nativeInstrumentCount(JNIEnv*, jobject) {
    return InstrumentRegistry::instance().count();
}

// ---------------- Note events ----------------
JNIEXPORT void JNICALL
Java_com_epic_rubab_engine_NativeBridge_nativeNoteOn(JNIEnv*, jobject, jint touchId, jint instrumentId,
                                                     jfloat midiNote, jfloat velocity, jint articulation,
                                                     jfloat artParam) {
    if (gEngine) gEngine->postNoteOn(touchId, instrumentId, midiNote, velocity, articulation, artParam);
}

JNIEXPORT void JNICALL
Java_com_epic_rubab_engine_NativeBridge_nativeNoteOff(JNIEnv*, jobject, jint touchId) {
    if (gEngine) gEngine->postNoteOff(touchId);
}

JNIEXPORT void JNICALL
Java_com_epic_rubab_engine_NativeBridge_nativeBend(JNIEnv*, jobject, jint touchId, jfloat semitones) {
    if (gEngine) gEngine->postBend(touchId, semitones);
}

JNIEXPORT void JNICALL
Java_com_epic_rubab_engine_NativeBridge_nativePressure(JNIEnv*, jobject, jint touchId, jfloat pressure) {
    if (gEngine) gEngine->postPressure(touchId, pressure);
}

JNIEXPORT void JNICALL
Java_com_epic_rubab_engine_NativeBridge_nativeAllNotesOff(JNIEnv*, jobject) {
    if (gEngine) gEngine->postAllNotesOff();
}

// ---------------- FX / parameters ----------------
JNIEXPORT void JNICALL
Java_com_epic_rubab_engine_NativeBridge_nativeSetMasterGain(JNIEnv*, jobject, jfloat g) {
    if (gEngine) gEngine->setMasterGain(g);
}
JNIEXPORT void JNICALL
Java_com_epic_rubab_engine_NativeBridge_nativeSetReverbSpace(JNIEnv*, jobject, jint space) {
    if (gEngine) gEngine->setReverbSpace(space);
}
JNIEXPORT void JNICALL
Java_com_epic_rubab_engine_NativeBridge_nativeSetReverbMix(JNIEnv*, jobject, jfloat mix) {
    if (gEngine) gEngine->setReverbMix(mix);
}
JNIEXPORT void JNICALL
Java_com_epic_rubab_engine_NativeBridge_nativeSetAlgoReverb(JNIEnv*, jobject, jfloat room, jfloat damp, jfloat mix) {
    if (gEngine) gEngine->setAlgoReverb(room, damp, mix);
}
JNIEXPORT void JNICALL
Java_com_epic_rubab_engine_NativeBridge_nativeSetDelay(JNIEnv*, jobject, jfloat timeMs, jfloat fb, jfloat mix) {
    if (gEngine) gEngine->setDelay(timeMs, fb, mix);
}
JNIEXPORT void JNICALL
Java_com_epic_rubab_engine_NativeBridge_nativeSetModulation(JNIEnv*, jobject, jfloat rate, jfloat depth, jfloat mix) {
    if (gEngine) gEngine->setModulation(rate, depth, mix);
}
JNIEXPORT void JNICALL
Java_com_epic_rubab_engine_NativeBridge_nativeSetEq(JNIEnv*, jobject, jfloat lo, jfloat mid, jfloat hi) {
    if (gEngine) gEngine->setEq(lo, mid, hi);
}
JNIEXPORT void JNICALL
Java_com_epic_rubab_engine_NativeBridge_nativeSetSaturation(JNIEnv*, jobject, jfloat drive, jfloat mix) {
    if (gEngine) gEngine->setSaturation(drive, mix);
}
JNIEXPORT void JNICALL
Java_com_epic_rubab_engine_NativeBridge_nativeSetSpatial(JNIEnv*, jobject, jfloat width, jfloat depth) {
    if (gEngine) gEngine->setSpatial(width, depth);
}
JNIEXPORT void JNICALL
Java_com_epic_rubab_engine_NativeBridge_nativeSetMetronome(JNIEnv*, jobject, jboolean on, jfloat bpm, jint beats) {
    if (gEngine) gEngine->setMetronome(on == JNI_TRUE, bpm, beats);
}

// ---------------- Recording ----------------
JNIEXPORT void JNICALL
Java_com_epic_rubab_engine_NativeBridge_nativeRecordArm(JNIEnv*, jobject) { if (gEngine) gEngine->recordArm(); }
JNIEXPORT void JNICALL
Java_com_epic_rubab_engine_NativeBridge_nativeRecordDisarm(JNIEnv*, jobject) { if (gEngine) gEngine->recordDisarm(); }
JNIEXPORT jboolean JNICALL
Java_com_epic_rubab_engine_NativeBridge_nativeIsRecording(JNIEnv*, jobject) {
    return (gEngine && gEngine->isRecording()) ? JNI_TRUE : JNI_FALSE;
}
JNIEXPORT jint JNICALL
Java_com_epic_rubab_engine_NativeBridge_nativeExportWav(JNIEnv* env, jobject, jstring path) {
    if (!gEngine) return 0;
    const char* p = env->GetStringUTFChars(path, nullptr);
    const int frames = gEngine->exportWav(std::string(p));
    env->ReleaseStringUTFChars(path, p);
    return frames;
}

} // extern "C"
