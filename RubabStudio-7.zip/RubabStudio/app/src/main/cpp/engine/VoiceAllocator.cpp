#include "VoiceAllocator.h"
#include "../synth/PluckedStringVoice.h"
#include "../synth/BowedStringVoice.h"
#include "../synth/WindVoice.h"
#include "../synth/ModalPercussionVoice.h"
#include "../synth/KeyedVoice.h"
#include <cmath>

namespace rubab {

static constexpr int kPluckedPool = 48;
static constexpr int kBowedPool   = 16;
static constexpr int kWindPool    = 16;
static constexpr int kModalPool   = 32;
static constexpr int kKeyedPool   = 28;

void VoiceAllocator::prepare(double sampleRate, int maxBlock) {
    sampleRate_ = sampleRate;
    maxBlock_ = maxBlock;
    scratch_.assign(maxBlock, 0.0f);
    rng_.seed(0x51ED5EEDu);

    auto fill = [&](std::vector<std::unique_ptr<Voice>>& pool, int n, auto factory) {
        pool.clear();
        for (int i = 0; i < n; ++i) {
            auto v = factory();
            v->prepare(sampleRate, maxBlock);
            pool.push_back(std::move(v));
        }
    };
    fill(plucked_, kPluckedPool, []{ return std::make_unique<PluckedStringVoice>(); });
    fill(bowed_,   kBowedPool,   []{ return std::make_unique<BowedStringVoice>(); });
    fill(wind_,    kWindPool,    []{ return std::make_unique<WindVoice>(); });
    fill(modal_,   kModalPool,   []{ return std::make_unique<ModalPercussionVoice>(); });
    fill(keyed_,   kKeyedPool,   []{ return std::make_unique<KeyedVoice>(); });
}

std::vector<std::unique_ptr<Voice>>& VoiceAllocator::poolFor(ModelType m) {
    switch (m) {
        case MODEL_BOWED:      return bowed_;
        case MODEL_WIND:       return wind_;
        case MODEL_MODAL_PERC: return modal_;
        case MODEL_KEYED:      return keyed_;
        case MODEL_PLUCKED:
        default:               return plucked_;
    }
}

Voice* VoiceAllocator::acquire(ModelType m) {
    auto& pool = poolFor(m);
    // 1) a free voice
    for (auto& v : pool) if (!v->isActive()) return v.get();
    // 2) steal: prefer a released voice, else the oldest
    Voice* best = nullptr;
    uint64_t bestAge = UINT64_MAX;
    for (auto& v : pool) {
        const uint64_t age = v->startAge;
        const bool rel = v->released;
        // Released voices weighted older so they are stolen first.
        const uint64_t score = rel ? (age / 2) : age;
        if (score < bestAge) { bestAge = score; best = v.get(); }
    }
    return best;
}

Voice* VoiceAllocator::noteOn(int touchId, const InstrumentDefinition& def, float midiNote,
                              float velocity, Articulation art, float artParam) {
    Voice* v = acquire(def.p.model);
    if (!v) return nullptr;
    if (v->isActive()) v->kill();

    v->touchId = touchId;
    v->instrumentId = def.id;
    v->released = false;
    v->startAge = ageCounter_++;

    // Place in the stereo field by pitch (keyboard-style spread).
    const float spread = def.p.stereoSpread;
    v->pan = clampf((midiNote - 60.0f) / 36.0f, -1.0f, 1.0f) * spread
             + rng_.nextBipolar() * 0.05f;

    v->noteOn(def.p, midiNote, velocity, art, artParam, rng_);
    return v;
}

void VoiceAllocator::noteOff(int touchId) {
    auto scan = [&](std::vector<std::unique_ptr<Voice>>& pool) {
        for (auto& v : pool)
            if (v->isActive() && v->touchId == touchId && !v->released) v->noteOff();
    };
    scan(plucked_); scan(bowed_); scan(wind_); scan(modal_); scan(keyed_);
}

void VoiceAllocator::setBend(int touchId, float semitones) {
    auto scan = [&](std::vector<std::unique_ptr<Voice>>& pool) {
        for (auto& v : pool) if (v->isActive() && v->touchId == touchId) v->setBend(semitones);
    };
    scan(plucked_); scan(bowed_); scan(wind_); scan(modal_); scan(keyed_);
}

void VoiceAllocator::setPressure(int touchId, float pressure) {
    auto scan = [&](std::vector<std::unique_ptr<Voice>>& pool) {
        for (auto& v : pool) if (v->isActive() && v->touchId == touchId) v->setPressure(pressure);
    };
    scan(plucked_); scan(bowed_); scan(wind_); scan(modal_); scan(keyed_);
}

void VoiceAllocator::allNotesOff(bool hard) {
    auto scan = [&](std::vector<std::unique_ptr<Voice>>& pool) {
        for (auto& v : pool) if (v->isActive()) { if (hard) v->kill(); else v->noteOff(); }
    };
    scan(plucked_); scan(bowed_); scan(wind_); scan(modal_); scan(keyed_);
}

void VoiceAllocator::renderAdd(float* busL, float* busR, int n) {
    auto mix = [&](std::vector<std::unique_ptr<Voice>>& pool) {
        for (auto& v : pool) {
            if (!v->isActive()) continue;
            std::fill(scratch_.begin(), scratch_.begin() + n, 0.0f);
            v->renderAdd(scratch_.data(), n);
            // Equal-power pan.
            const float angle = (v->pan * 0.5f + 0.5f) * (kPi * 0.5f);
            const float gl = std::cos(angle);
            const float gr = std::sin(angle);
            for (int k = 0; k < n; ++k) {
                const float s = scratch_[k];
                busL[k] += s * gl;
                busR[k] += s * gr;
            }
        }
    };
    mix(plucked_); mix(bowed_); mix(wind_); mix(modal_); mix(keyed_);
}

int VoiceAllocator::activeCount() const {
    int c = 0;
    auto count = [&](const std::vector<std::unique_ptr<Voice>>& pool) {
        for (auto& v : pool) if (v->isActive()) ++c;
    };
    count(plucked_); count(bowed_); count(wind_); count(modal_); count(keyed_);
    return c;
}

} // namespace rubab
