#pragma once
#include <memory>
#include <vector>
#include "EngineTypes.h"
#include "Voice.h"
#include "../util/Random.h"

namespace rubab {

// Owns pre-allocated pools of voices (one pool per synthesis model) and routes
// note events to a free or stolen voice. All note-time work is allocation-free.
class VoiceAllocator {
public:
    void prepare(double sampleRate, int maxBlock);

    Voice* noteOn(int touchId, const InstrumentDefinition& def, float midiNote,
                  float velocity, Articulation art, float artParam);
    void noteOff(int touchId);
    void setBend(int touchId, float semitones);
    void setPressure(int touchId, float pressure);
    void allNotesOff(bool hard);

    // Renders & pans every active voice into the stereo bus (adds).
    void renderAdd(float* busL, float* busR, int n);

    int activeCount() const;

private:
    std::vector<std::unique_ptr<Voice>>& poolFor(ModelType m);
    Voice* acquire(ModelType m);

    double sampleRate_ = 48000.0;
    int maxBlock_ = 256;

    std::vector<std::unique_ptr<Voice>> plucked_, bowed_, wind_, modal_, keyed_;
    std::vector<float> scratch_;
    Xorshift rng_;
    uint64_t ageCounter_ = 0;
};

} // namespace rubab
