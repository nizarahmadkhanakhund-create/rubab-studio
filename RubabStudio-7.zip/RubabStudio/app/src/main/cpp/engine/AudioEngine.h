#pragma once
#include <oboe/Oboe.h>
#include <mutex>
#include <atomic>
#include <array>
#include <string>

#include "VoiceAllocator.h"
#include "Recorder.h"
#include "../synth/SympatheticBank.h"
#include "../fx/Biquad.h"
#include "../fx/AlgoReverb.h"
#include "../fx/ConvolutionReverb.h"
#include "../fx/Delay.h"
#include "../fx/Modulation.h"
#include "../fx/Spatializer.h"
#include "../fx/Saturator.h"
#include "../fx/ImpulseFactory.h"

namespace rubab {

// The realtime audio engine. Owns the Oboe stream, the voice pool and the
// master effects chain. UI/JNI threads communicate purely through a lock-free
// event queue, so the audio callback never blocks.
class AudioEngine : public oboe::AudioStreamDataCallback,
                    public oboe::AudioStreamErrorCallback {
public:
    bool start();
    void stop();
    bool isRunning() const { return stream_ != nullptr; }
    double sampleRate() const { return sampleRate_; }

    // --- Event API (thread-safe, non-blocking to the audio thread) ---
    void postNoteOn(int touchId, int instrumentId, float midiNote, float velocity,
                    int articulation, float artParam);
    void postNoteOff(int touchId);
    void postBend(int touchId, float semitones);
    void postPressure(int touchId, float pressure);
    void postAllNotesOff();

    // --- Parameters (atomic; applied next block) ---
    void setMasterGain(float g) { masterGain_.store(g); }
    void setReverbSpace(int space);                 // reconfigures convolution IR (off-thread)
    void setReverbMix(float m) { convMix_.store(clampf(m, 0, 1)); }
    void setAlgoReverb(float room, float damp, float mix);
    void setDelay(float timeMs, float feedback, float mix);
    void setModulation(float rateHz, float depthMs, float mix);
    void setEq(float lowDb, float midDb, float highDb);
    void setSaturation(float drive, float mix);
    void setSpatial(float width, float depth);
    void setMetronome(bool on, float bpm, int beatsPerBar);

    // --- Recording / export ---
    void recordArm()    { recorder_.arm(); }
    void recordDisarm() { recorder_.disarm(); }
    bool isRecording() const { return recorder_.isRecording(); }
    int  exportWav(const std::string& path) { return recorder_.exportWav(path); }

    int activeVoices() const { return activeVoices_.load(); }

    // oboe callbacks
    oboe::DataCallbackResult onAudioReady(oboe::AudioStream*, void* audioData, int32_t numFrames) override;
    void onErrorAfterClose(oboe::AudioStream*, oboe::Result) override;

private:
    struct Event {
        enum Type : uint8_t { NOTE_ON, NOTE_OFF, BEND, PRESSURE, ALL_OFF } type;
        int32_t touchId = 0;
        int32_t instrumentId = 0;
        int32_t iarg = 0;
        float f0 = 0, f1 = 0, f2 = 0;
    };
    static constexpr int kQueueSize = 2048;

    void push(const Event& e);
    void drainEvents();
    void applyPendingReverb();
    void buildFxChain();

    std::shared_ptr<oboe::AudioStream> stream_;
    double sampleRate_ = 48000.0;
    int maxBlock_ = 1024;

    VoiceAllocator alloc_;
    SympatheticBank symBank_;
    std::atomic<int> symActive_{0};
    std::atomic<float> symDrive_{0.0f};

    // FX
    Biquad eqL_[3], eqR_[3];
    Spatializer spatial_;
    Modulation modulation_;
    Delay delay_;
    AlgoReverb algoReverb_;
    ConvolutionReverb convReverb_;
    Saturator saturator_;

    std::atomic<float> masterGain_{0.9f};
    std::atomic<float> convMix_{0.22f};
    std::atomic<int> pendingSpace_{-1};
    std::mutex reverbMutex_;

    // Buses
    std::array<float, 4096> busL_{}, busR_{};

    // Event queue (SPSC-ish; producers guarded by a mutex, consumer lock-free)
    std::array<Event, kQueueSize> queue_;
    std::atomic<uint32_t> qHead_{0}; // write
    std::atomic<uint32_t> qTail_{0}; // read
    std::mutex produceMutex_;

    // Metronome
    std::atomic<bool> metroOn_{false};
    std::atomic<float> metroBpm_{100.0f};
    std::atomic<int> metroBeats_{4};
    double metroPhase_ = 0.0;   // samples until next beat
    int metroBeatIdx_ = 0;
    float metroClick_ = 0.0f;
    float metroClickInc_ = 0.0f;
    int metroClickLen_ = 0;
    int metroClickPos_ = 0;

    Recorder recorder_;
    std::atomic<int> activeVoices_{0};
};

} // namespace rubab
