#pragma once
#include "EngineTypes.h"

namespace rubab {

// Central, data-driven catalogue of every instrument. The engine never
// hard-codes instrument behaviour — it looks up an InstrumentDefinition here
// and drives the generic voice models with it. Adding an instrument means
// adding one entry (and its Kotlin mirror); no engine changes required.
class InstrumentRegistry {
public:
    static const InstrumentRegistry& instance();

    const InstrumentDefinition& get(int id) const;
    int count() const { return INST_COUNT; }

private:
    InstrumentRegistry();
    InstrumentDefinition defs_[INST_COUNT];
};

} // namespace rubab
