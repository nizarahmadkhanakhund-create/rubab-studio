#include "InstrumentRegistry.h"

namespace rubab {

// Helpers to fill modal arrays concisely.
static void setModes(InstrumentParams& p, int n,
                     const float* ratio, const float* decay, const float* amp) {
    p.mp_numModes = n;
    for (int i = 0; i < n && i < kMaxModes; ++i) {
        p.mp_ratio[i] = ratio[i];
        p.mp_decay[i] = decay[i];
        p.mp_amp[i]   = amp[i];
    }
}

const InstrumentRegistry& InstrumentRegistry::instance() {
    static InstrumentRegistry reg;
    return reg;
}

const InstrumentDefinition& InstrumentRegistry::get(int id) const {
    if (id < 0 || id >= INST_COUNT) id = INST_RUBAB;
    return defs_[id];
}

InstrumentRegistry::InstrumentRegistry() {
    // ============================ PLUCKED ============================
    {   // FLAGSHIP: Acoustic Rubab — the most carefully voiced instrument here.
        auto& d = defs_[INST_RUBAB]; d.id = INST_RUBAB; d.name = "Acoustic Rubab";
        auto& p = d.p; p.model = MODEL_PLUCKED;
        p.ks_decaySec = 2.0f; p.ks_brightness = 0.56f; p.ks_inharm = 0.00050f;
        p.ks_dispStages = 3; p.ks_pickPos = 0.19f;
        // Mulberry-wood body: low bowl resonance, mid, and a bright membrane/air mode.
        p.ks_bodyHz = 186.0f;  p.ks_bodyQ  = 4.5f; p.ks_bodyMix = 0.34f;
        p.ks_body2Hz = 520.0f; p.ks_body2Q = 6.0f;
        p.ks_body3Hz = 1150.0f; p.ks_body3Q = 9.0f;              // goat-skin "sparkle"
        p.ks_sympathetic = 0.08f; p.ks_sympCount = 13; p.ks_buzz = 0.07f;
        p.ks_unison = 1; p.gainDb = 0.0f;
        // Per-string register voicing across the rubab's range (G2..G5).
        p.ks_regLowMidi = 43.0f; p.ks_regHighMidi = 79.0f;
        p.ks_decayLowScale = 1.15f; p.ks_decayHighScale = 0.78f;
        p.ks_brightLow = 0.42f; p.ks_brightHigh = 0.74f;
        p.ks_inharmLowScale = 1.8f; p.ks_inharmHighScale = 0.6f;
        // Dual-polarization gut/steel strings → living two-stage decay & bloom.
        p.ks_dualPolar = true; p.ks_polarDetune = 4.5f; p.ks_polarDecay = 1.35f; p.ks_polarLevel = 0.42f;
        p.ks_fingerNoise = 0.16f; p.ks_humanCents = 1.8f;
    }
    {   auto& d = defs_[INST_STEEL_GUITAR]; d.id = INST_STEEL_GUITAR; d.name = "Steel-String Guitar";
        auto& p = d.p; p.model = MODEL_PLUCKED;
        p.ks_decaySec = 3.6f; p.ks_brightness = 0.70f; p.ks_inharm = 0.00060f;
        p.ks_pickPos = 0.15f; p.ks_bodyHz = 110.0f; p.ks_bodyQ = 3.0f; p.ks_bodyMix = 0.30f;
        p.ks_body2Hz = 215.0f; p.ks_body2Q = 5.0f; p.ks_unison = 1;
        p.ks_body3Hz = 2600.0f; p.ks_body3Q = 2.0f; p.ks_regLowMidi = 40.0f; p.ks_regHighMidi = 76.0f;
        p.ks_dualPolar = true; p.ks_polarDetune = 3.5f; p.ks_polarDecay = 1.7f; p.ks_polarLevel = 0.5f;
        p.ks_fingerNoise = 0.14f;
    }
    {   auto& d = defs_[INST_NYLON_GUITAR]; d.id = INST_NYLON_GUITAR; d.name = "Nylon Guitar";
        auto& p = d.p; p.model = MODEL_PLUCKED;
        p.ks_decaySec = 2.8f; p.ks_brightness = 0.40f; p.ks_inharm = 0.00022f;
        p.ks_pickPos = 0.18f; p.ks_bodyHz = 95.0f; p.ks_bodyQ = 3.0f; p.ks_bodyMix = 0.36f;
        p.ks_body2Hz = 190.0f; p.ks_body2Q = 5.0f; p.ks_unison = 1;
        p.ks_body3Hz = 1400.0f; p.ks_body3Q = 4.0f; p.ks_regLowMidi = 40.0f; p.ks_regHighMidi = 76.0f;
        p.ks_dualPolar = true; p.ks_polarDetune = 3.0f; p.ks_polarDecay = 1.6f; p.ks_polarLevel = 0.55f;
        p.ks_fingerNoise = 0.10f;
    }
    {   auto& d = defs_[INST_TWELVE_STRING]; d.id = INST_TWELVE_STRING; d.name = "12-String Guitar";
        auto& p = d.p; p.model = MODEL_PLUCKED;
        p.ks_decaySec = 3.2f; p.ks_brightness = 0.74f; p.ks_inharm = 0.00058f;
        p.ks_pickPos = 0.15f; p.ks_bodyHz = 108.0f; p.ks_bodyQ = 3.0f; p.ks_bodyMix = 0.30f;
        p.ks_body2Hz = 220.0f; p.ks_body2Q = 5.0f; p.ks_unison = 2; p.ks_unisonDet = 11.0f;
        p.ks_body3Hz = 2800.0f; p.ks_body3Q = 2.0f; p.ks_regLowMidi = 40.0f; p.ks_regHighMidi = 76.0f;
        p.ks_dualPolar = true; p.ks_polarDetune = 5.0f; p.ks_polarDecay = 1.7f; p.ks_polarLevel = 0.5f;
        p.ks_fingerNoise = 0.14f;
    }
    {   auto& d = defs_[INST_SITAR]; d.id = INST_SITAR; d.name = "Sitar";
        auto& p = d.p; p.model = MODEL_PLUCKED;
        p.ks_decaySec = 2.6f; p.ks_brightness = 0.62f; p.ks_inharm = 0.00040f;
        p.ks_pickPos = 0.12f; p.ks_bodyHz = 160.0f; p.ks_bodyQ = 4.0f; p.ks_bodyMix = 0.33f;
        p.ks_body2Hz = 430.0f; p.ks_body2Q = 6.0f;
        p.ks_buzz = 0.38f; p.ks_sympathetic = 0.10f; p.ks_sympCount = 13; p.ks_unison = 1;
        p.ks_body3Hz = 1300.0f; p.ks_body3Q = 8.0f; p.ks_regLowMidi = 48.0f; p.ks_regHighMidi = 84.0f;
        p.ks_dualPolar = true; p.ks_polarDetune = 5.0f; p.ks_polarDecay = 2.1f; p.ks_polarLevel = 0.6f;
        p.ks_fingerNoise = 0.12f; p.ks_humanCents = 2.0f;
    }
    {   auto& d = defs_[INST_SANTOOR]; d.id = INST_SANTOOR; d.name = "Santoor";
        auto& p = d.p; p.model = MODEL_PLUCKED;
        p.ks_decaySec = 1.5f; p.ks_brightness = 0.80f; p.ks_inharm = 0.00085f;
        p.ks_pickPos = 0.10f; p.ks_bodyHz = 300.0f; p.ks_bodyQ = 5.0f; p.ks_bodyMix = 0.25f;
        p.ks_body2Hz = 900.0f; p.ks_body2Q = 7.0f; p.ks_unison = 3; p.ks_unisonDet = 6.0f;
        p.ks_body3Hz = 3200.0f; p.ks_body3Q = 3.0f; p.ks_regLowMidi = 55.0f; p.ks_regHighMidi = 91.0f;
        p.ks_dualPolar = true; p.ks_polarDetune = 6.0f; p.ks_polarDecay = 1.5f; p.ks_polarLevel = 0.5f;
        p.ks_fingerNoise = 0.10f;
    }
    {   auto& d = defs_[INST_OUD]; d.id = INST_OUD; d.name = "Oud";
        auto& p = d.p; p.model = MODEL_PLUCKED;
        p.ks_decaySec = 2.2f; p.ks_brightness = 0.46f; p.ks_inharm = 0.00020f;
        p.ks_pickPos = 0.16f; p.ks_bodyHz = 120.0f; p.ks_bodyQ = 3.0f; p.ks_bodyMix = 0.40f;
        p.ks_body2Hz = 240.0f; p.ks_body2Q = 5.0f; p.ks_unison = 2; p.ks_unisonDet = 5.0f;
        p.ks_body3Hz = 1100.0f; p.ks_body3Q = 5.0f; p.ks_regLowMidi = 43.0f; p.ks_regHighMidi = 76.0f;
        p.ks_dualPolar = true; p.ks_polarDetune = 4.0f; p.ks_polarDecay = 1.8f; p.ks_polarLevel = 0.6f;
        p.ks_fingerNoise = 0.13f; p.ks_humanCents = 2.2f;
    }
    {   auto& d = defs_[INST_MANDOLIN]; d.id = INST_MANDOLIN; d.name = "Mandolin";
        auto& p = d.p; p.model = MODEL_PLUCKED;
        p.ks_decaySec = 1.8f; p.ks_brightness = 0.76f; p.ks_inharm = 0.00060f;
        p.ks_pickPos = 0.12f; p.ks_bodyHz = 260.0f; p.ks_bodyQ = 5.0f; p.ks_bodyMix = 0.28f;
        p.ks_body2Hz = 540.0f; p.ks_body2Q = 6.0f; p.ks_unison = 2; p.ks_unisonDet = 7.0f;
        p.ks_body3Hz = 3000.0f; p.ks_body3Q = 2.5f; p.ks_regLowMidi = 55.0f; p.ks_regHighMidi = 91.0f;
        p.ks_dualPolar = true; p.ks_polarDetune = 6.0f; p.ks_polarDecay = 1.5f; p.ks_polarLevel = 0.5f;
        p.ks_fingerNoise = 0.12f;
    }
    {   auto& d = defs_[INST_BANJO]; d.id = INST_BANJO; d.name = "Banjo";
        auto& p = d.p; p.model = MODEL_PLUCKED;
        p.ks_decaySec = 1.2f; p.ks_brightness = 0.86f; p.ks_inharm = 0.00070f;
        p.ks_pickPos = 0.09f; p.ks_bodyHz = 220.0f; p.ks_bodyQ = 2.0f; p.ks_bodyMix = 0.50f;
        p.ks_body2Hz = 500.0f; p.ks_body2Q = 4.0f; p.ks_unison = 1;
        p.ks_body3Hz = 3400.0f; p.ks_body3Q = 2.0f; p.ks_regLowMidi = 50.0f; p.ks_regHighMidi = 86.0f;
        p.ks_dualPolar = true; p.ks_polarDetune = 4.0f; p.ks_polarDecay = 1.4f; p.ks_polarLevel = 0.45f;
        p.ks_fingerNoise = 0.16f;
    }
    {   auto& d = defs_[INST_ACOUSTIC_BASS]; d.id = INST_ACOUSTIC_BASS; d.name = "Acoustic Bass";
        auto& p = d.p; p.model = MODEL_PLUCKED;
        p.ks_decaySec = 4.5f; p.ks_brightness = 0.30f; p.ks_inharm = 0.00030f;
        p.ks_pickPos = 0.14f; p.ks_bodyHz = 70.0f; p.ks_bodyQ = 3.0f; p.ks_bodyMix = 0.42f;
        p.ks_body2Hz = 150.0f; p.ks_body2Q = 5.0f; p.ks_unison = 1; p.gainDb = 1.5f;
        p.ks_regLowMidi = 28.0f; p.ks_regHighMidi = 60.0f;
        p.ks_decayLowScale = 1.5f; p.ks_decayHighScale = 0.85f;
        p.ks_dualPolar = true; p.ks_polarDetune = 2.5f; p.ks_polarDecay = 2.0f; p.ks_polarLevel = 0.6f;
        p.ks_fingerNoise = 0.10f;
    }

    // ============================ KEYED ============================
    {   auto& d = defs_[INST_PIANO]; d.id = INST_PIANO; d.name = "Grand Piano";
        auto& p = d.p; p.model = MODEL_KEYED;
        p.key_sustained = false; p.key_decaySec = 7.0f; p.key_inharm = 0.00090f;
        p.key_unison = 3; p.key_unisonDet = 1.4f; p.key_hammerHard = 0.5f;
    }
    {   auto& d = defs_[INST_HARMONIUM]; d.id = INST_HARMONIUM; d.name = "Harmonium";
        auto& p = d.p; p.model = MODEL_KEYED;
        p.key_sustained = true; p.key_reedHarm = 0.8f;
    }

    // ============================ BOWED ============================
    {   auto& d = defs_[INST_VIOLIN]; d.id = INST_VIOLIN; d.name = "Violin";
        auto& p = d.p; p.model = MODEL_BOWED;
        p.bow_force = 0.30f; p.bow_position = 0.10f; p.bow_vibRate = 6.0f; p.bow_vibDepth = 0.18f;
        p.bow_bodyHz = 300.0f; p.bow_bodyQ = 5.0f; p.bow_attackMs = 55.0f;
        p.bow_bright = 0.64f; p.bow_regLowMidi = 55.0f; p.bow_regHighMidi = 100.0f;
    }
    {   auto& d = defs_[INST_CELLO]; d.id = INST_CELLO; d.name = "Cello";
        auto& p = d.p; p.model = MODEL_BOWED;
        p.bow_force = 0.35f; p.bow_position = 0.11f; p.bow_vibRate = 5.0f; p.bow_vibDepth = 0.15f;
        p.bow_bodyHz = 180.0f; p.bow_bodyQ = 5.0f; p.bow_attackMs = 70.0f; p.gainDb = 1.0f;
        p.bow_bright = 0.42f; p.bow_regLowMidi = 36.0f; p.bow_regHighMidi = 76.0f;
    }
    {   auto& d = defs_[INST_VIOLA]; d.id = INST_VIOLA; d.name = "Viola";
        auto& p = d.p; p.model = MODEL_BOWED;
        p.bow_force = 0.32f; p.bow_position = 0.11f; p.bow_vibRate = 5.5f; p.bow_vibDepth = 0.16f;
        p.bow_bodyHz = 230.0f; p.bow_bodyQ = 5.0f; p.bow_attackMs = 62.0f;
        p.bow_bright = 0.5f; p.bow_regLowMidi = 48.0f; p.bow_regHighMidi = 88.0f;
    }

    // ============================ WIND ============================
    {   auto& d = defs_[INST_FLUTE]; d.id = INST_FLUTE; d.name = "Concert Flute";
        auto& p = d.p; p.model = MODEL_WIND;
        p.wind_reediness = 0.0f; p.wind_breath = 0.35f; p.wind_formant1 = 800.0f;
        p.wind_vibRate = 5.0f; p.wind_vibDepth = 0.06f; p.wind_attackMs = 35.0f;
    }
    {   auto& d = defs_[INST_BANSURI]; d.id = INST_BANSURI; d.name = "Bansuri";
        auto& p = d.p; p.model = MODEL_WIND;
        p.wind_reediness = 0.08f; p.wind_breath = 0.45f; p.wind_formant1 = 700.0f;
        p.wind_vibRate = 5.0f; p.wind_vibDepth = 0.09f; p.wind_attackMs = 45.0f;
    }
    {   auto& d = defs_[INST_NEY]; d.id = INST_NEY; d.name = "Ney";
        auto& p = d.p; p.model = MODEL_WIND;
        p.wind_reediness = 0.25f; p.wind_breath = 0.5f; p.wind_formant1 = 900.0f;
        p.wind_vibRate = 4.5f; p.wind_vibDepth = 0.07f; p.wind_attackMs = 55.0f;
    }
    {   auto& d = defs_[INST_DUDUK]; d.id = INST_DUDUK; d.name = "Duduk";
        auto& p = d.p; p.model = MODEL_WIND;
        p.wind_reediness = 0.85f; p.wind_breath = 0.2f; p.wind_formant1 = 550.0f;
        p.wind_vibRate = 5.5f; p.wind_vibDepth = 0.10f; p.wind_attackMs = 50.0f;
    }

    // ============================ MODAL PERCUSSION ============================
    {   auto& d = defs_[INST_TABLA]; d.id = INST_TABLA; d.name = "Tabla";
        auto& p = d.p; p.model = MODEL_MODAL_PERC;
        const float r[5] = {1.0f, 2.0f, 3.0f, 4.0f, 5.0f};        // loaded ~harmonic
        const float dc[5] = {0.9f, 0.6f, 0.4f, 0.25f, 0.15f};
        const float am[5] = {1.0f, 0.7f, 0.5f, 0.3f, 0.18f};
        setModes(p, 5, r, dc, am);
        p.mp_baseHz = 220.0f; p.mp_noiseAmt = 0.25f; p.mp_noiseDecay = 0.006f; p.mp_pitchGlide = 0.16f;
    }
    {   auto& d = defs_[INST_DHOL]; d.id = INST_DHOL; d.name = "Dhol";
        auto& p = d.p; p.model = MODEL_MODAL_PERC;
        const float r[4] = {1.0f, 1.6f, 2.3f, 3.1f};
        const float dc[4] = {0.5f, 0.3f, 0.2f, 0.12f};
        const float am[4] = {1.0f, 0.6f, 0.4f, 0.25f};
        setModes(p, 4, r, dc, am);
        p.mp_baseHz = 90.0f; p.mp_noiseAmt = 0.5f; p.mp_noiseDecay = 0.01f; p.mp_pitchGlide = 0.05f;
    }
    {   auto& d = defs_[INST_FRAME_DRUM]; d.id = INST_FRAME_DRUM; d.name = "Frame Drum";
        auto& p = d.p; p.model = MODEL_MODAL_PERC;
        const float r[4] = {1.0f, 1.5f, 2.1f, 2.8f};
        const float dc[4] = {0.35f, 0.22f, 0.15f, 0.1f};
        const float am[4] = {1.0f, 0.55f, 0.35f, 0.2f};
        setModes(p, 4, r, dc, am);
        p.mp_baseHz = 120.0f; p.mp_noiseAmt = 0.45f; p.mp_noiseDecay = 0.012f;
    }
    {   auto& d = defs_[INST_CAJON]; d.id = INST_CAJON; d.name = "Cajon";
        auto& p = d.p; p.model = MODEL_MODAL_PERC;
        const float r[3] = {1.0f, 3.5f, 6.0f};
        const float dc[3] = {0.28f, 0.08f, 0.05f};
        const float am[3] = {1.0f, 0.5f, 0.35f};
        setModes(p, 3, r, dc, am);
        p.mp_baseHz = 90.0f; p.mp_noiseAmt = 0.6f; p.mp_noiseDecay = 0.03f;
    }
    {   auto& d = defs_[INST_HAND_PERCUSSION]; d.id = INST_HAND_PERCUSSION; d.name = "Hand Percussion";
        auto& p = d.p; p.model = MODEL_MODAL_PERC;
        const float r[3] = {1.0f, 2.4f, 4.1f};
        const float dc[3] = {0.15f, 0.08f, 0.05f};
        const float am[3] = {1.0f, 0.6f, 0.4f};
        setModes(p, 3, r, dc, am);
        p.mp_baseHz = 300.0f; p.mp_noiseAmt = 0.5f; p.mp_noiseDecay = 0.02f;
    }
}

} // namespace rubab
