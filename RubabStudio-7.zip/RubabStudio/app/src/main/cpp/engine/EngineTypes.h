#pragma once
#include <cstdint>

namespace rubab {

// ---------------------------------------------------------------------------
// Instrument identity. Order is the canonical registry order and MUST match
// the Kotlin InstrumentRegistry. New instruments append at the end; the engine
// never branches on these directly — it reads InstrumentDefinition instead —
// so a new instrument "plugs in" purely via the registry (modular design).
// ---------------------------------------------------------------------------
enum InstrumentId : int32_t {
    INST_RUBAB = 0,          // FLAGSHIP
    INST_STEEL_GUITAR,
    INST_NYLON_GUITAR,
    INST_TWELVE_STRING,
    INST_SITAR,
    INST_SANTOOR,
    INST_OUD,
    INST_MANDOLIN,
    INST_BANJO,
    INST_ACOUSTIC_BASS,
    INST_PIANO,
    INST_VIOLIN,
    INST_CELLO,
    INST_VIOLA,
    INST_FLUTE,
    INST_BANSURI,
    INST_NEY,
    INST_DUDUK,
    INST_HARMONIUM,
    INST_TABLA,
    INST_DHOL,
    INST_FRAME_DRUM,
    INST_CAJON,
    INST_HAND_PERCUSSION,
    INST_COUNT
};

// Synthesis engine chosen per instrument for realism. Each maps to a distinct
// Voice subclass with its own articulation model.
enum ModelType : int32_t {
    MODEL_PLUCKED = 0,   // extended Karplus-Strong (dispersion + body + sympathetic)
    MODEL_BOWED,         // friction-driven bowed string
    MODEL_WIND,          // breath-excited waveguide / modal reed & flute
    MODEL_MODAL_PERC,    // modal bank + membrane transient
    MODEL_KEYED          // piano (coupled strings) & harmonium (free reed)
};

// Articulation applied to a note. Which ones are meaningful depends on the
// model; a voice ignores articulations it does not implement.
enum Articulation : int32_t {
    ART_NORMAL = 0,
    ART_PLUCK,           // hard transient pluck
    ART_STRUM,           // offset within a strummed chord
    ART_TREMOLO,         // rapid re-excitation
    ART_HAMMER,          // hammer-on / legato re-pitch, soft attack
    ART_MUTE,            // palm/finger damp — short decay
    ART_HARMONIC,        // flageolet — node excitation
    ART_BOW_LEGATO,
    ART_BOW_ACCENT,
    ART_BREATH_SOFT,
    ART_BREATH_ACCENT,
    ART_PERC_OPEN,       // open ringing stroke (dha, dhol open)
    ART_PERC_CLOSED,     // damped stroke (na, tin, ka)
    ART_PERC_RIM,        // rim / edge stroke
    ART_PERC_BASS        // bass stroke (ge / dhol bass)
};

constexpr int kMaxModes = 10;        // modal partials per percussion voice
constexpr int kMaxUnison = 3;        // coupled strings per keyed/plucked note

// ---------------------------------------------------------------------------
// Flat parameter block describing one instrument's timbre. A single struct
// spans all models; each voice reads only the fields it needs. This keeps the
// registry data-driven and lets the Kotlin layer edit presets without code.
// ---------------------------------------------------------------------------
struct InstrumentParams {
    ModelType model = MODEL_PLUCKED;

    // --- Common ---
    float gainDb        = 0.0f;
    float tuneSemis     = 0.0f;    // overall transpose/fine tune
    float stereoSpread  = 0.3f;    // 0..1 placement width across the keyboard

    // --- Plucked string (extended Karplus-Strong) ---
    float ks_decaySec    = 2.5f;   // -60 dB time of the fundamental
    float ks_brightness  = 0.5f;   // loop lowpass (0 dark .. 1 bright)
    float ks_damping     = 0.0f;   // extra high-freq loss for muted notes
    float ks_inharm      = 0.0004f;// dispersion / stiffness (string "metalness")
    int   ks_dispStages  = 2;      // number of dispersion allpasses
    float ks_pickPos     = 0.18f;  // comb notch position 0..0.5
    float ks_bodyHz      = 180.0f; // main body resonance
    float ks_bodyQ       = 4.0f;
    float ks_bodyMix     = 0.25f;  // dry/body blend
    float ks_body2Hz     = 430.0f; // secondary body mode
    float ks_body2Q      = 6.0f;
    float ks_sympathetic = 0.0f;   // sympathetic string drive (sitar/rubab)
    int   ks_sympCount   = 0;
    float ks_buzz        = 0.0f;   // jawari / bridge buzz (sitar)
    int   ks_unison      = 1;      // courses (12-string=2, mandolin=2)
    float ks_unisonDet   = 0.0f;   // cents of detune between course strings

    // --- Premium voicing: per-register morph (makes every note individual) ---
    // Decay, brightness and inharmonicity are interpolated across the pitch
    // range so low strings ring long/warm and high notes are tight/bright.
    float ks_decayLowScale  = 1.12f; // decay multiplier at the lowest register
    float ks_decayHighScale = 0.80f; // decay multiplier at the highest register
    float ks_brightLow      = -1.0f; // <0 → derive from ks_brightness
    float ks_brightHigh     = -1.0f; // <0 → derive from ks_brightness
    float ks_inharmLowScale = 1.70f; // bass strings are stiffer / more inharmonic
    float ks_inharmHighScale= 0.65f;
    float ks_regLowMidi     = 40.0f; // midi mapped to register 0.0
    float ks_regHighMidi    = 88.0f; // midi mapped to register 1.0

    // --- Dual polarization (horizontal + vertical waveguides) ---
    // The two planes decay at different rates and detune slightly, producing the
    // two-stage decay and living beating of a real plucked string.
    bool  ks_dualPolar   = false;
    float ks_polarDetune = 4.0f;   // cents between the two polarizations
    float ks_polarDecay  = 1.35f;  // vertical plane rings a little longer
    float ks_polarLevel  = 0.40f;  // level of the vertical plane

    // --- Extra body mode + air + humanization ---
    float ks_body3Hz     = 0.0f;   // 3rd body/air resonance (0 = disabled)
    float ks_body3Q      = 8.0f;
    float ks_fingerNoise = 0.12f;  // breathy finger/pick contact transient
    float ks_humanCents  = 1.5f;   // per-note random micro-detune (analogue life)

    // --- Bowed string ---
    float bow_force      = 0.3f;
    float bow_position   = 0.12f;  // bow point along string
    float bow_vibRate    = 5.5f;
    float bow_vibDepth   = 0.15f;  // semitones
    float bow_bodyHz     = 300.0f;
    float bow_bodyQ      = 5.0f;
    float bow_attackMs   = 60.0f;
    float bow_regLowMidi = 36.0f;  // register morph refs
    float bow_regHighMidi= 91.0f;
    float bow_vibLowScale = 0.7f;  // less vibrato in the low register
    float bow_vibHighScale= 1.25f;
    float bow_bright     = 0.5f;   // 0 dark .. 1 bright (upper harmonic content)

    // --- Wind / reed ---
    float wind_breath    = 0.25f;  // breath noise amount
    float wind_formant1  = 600.0f;
    float wind_formant2  = 1200.0f;
    float wind_reediness = 0.0f;   // 0 flute .. 1 reed (duduk/ney)
    float wind_vibRate   = 5.0f;
    float wind_vibDepth  = 0.08f;
    float wind_attackMs  = 40.0f;
    float wind_breathLowScale  = 1.3f;  // breathier low register
    float wind_breathHighScale = 0.7f;
    float wind_regLowMidi  = 55.0f;
    float wind_regHighMidi = 96.0f;

    // --- Modal percussion ---
    int   mp_numModes    = 4;
    float mp_ratio[kMaxModes]  = {1,1,1,1,1,1,1,1,1,1};
    float mp_decay[kMaxModes]  = {0.4f,0.3f,0.2f,0.15f,0,0,0,0,0,0};
    float mp_amp[kMaxModes]    = {1,0.6f,0.4f,0.25f,0,0,0,0,0,0};
    float mp_baseHz      = 180.0f; // tunable drums (tabla) override at noteOn
    float mp_noiseAmt    = 0.3f;   // membrane transient noise
    float mp_noiseDecay  = 0.02f;
    float mp_pitchGlide  = 0.0f;   // tabla "dha/dhun" downward glide amount

    // --- Keyed ---
    bool  key_sustained  = false;  // harmonium reed sustains while held
    float key_decaySec   = 6.0f;   // piano string decay
    float key_inharm     = 0.0008f;
    int   key_unison     = 3;
    float key_unisonDet  = 1.2f;   // cents
    float key_hammerHard = 0.5f;
    float key_reedHarm   = 0.0f;   // harmonium additive reed richness
    float key_decayLowScale  = 1.6f; // bass strings sustain far longer
    float key_decayHighScale = 0.55f;// treble decays quickly
    float key_regLowMidi  = 21.0f;
    float key_regHighMidi = 108.0f;
};

// Interpolates a per-note voicing value across the playable register.
// t = 0 at regLow (bass), 1 at regHigh (treble).
inline float registerT(float midi, float regLow, float regHigh) {
    const float d = (regHigh - regLow);
    if (d <= 0.0f) return 0.5f;
    float t = (midi - regLow) / d;
    return t < 0.0f ? 0.0f : (t > 1.0f ? 1.0f : t);
}

// Full instrument definition kept in the native registry.
struct InstrumentDefinition {
    InstrumentId id = INST_RUBAB;
    const char*  name = "Rubab";
    InstrumentParams p;
};

} // namespace rubab
