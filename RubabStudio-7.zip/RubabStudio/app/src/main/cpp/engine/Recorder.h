#pragma once
#include <vector>
#include <atomic>
#include <string>

namespace rubab {

// Captures the master stereo output into a pre-allocated buffer (realtime-safe:
// no allocation while recording) and exports it as a WAV. The audio thread
// calls capture(); the UI thread arms, disarms and exports.
class Recorder {
public:
    void prepare(double sampleRate, int maxSeconds = 600);

    void arm();          // start capturing (UI thread)
    void disarm();       // stop (UI thread)
    bool isRecording() const { return recording_.load(); }
    int  recordedFrames() const { return (int)writeFrame_.load(); }

    // Audio thread: append one block of interleaved stereo.
    void capture(const float* interleavedStereo, int frames);

    // UI thread: write captured audio to a WAV file. Returns frames written.
    int exportWav(const std::string& path);
    void clear();

private:
    double sr_ = 48000.0;
    int capacityFrames_ = 0;
    std::vector<float> buffer_;      // interleaved stereo
    std::atomic<bool> recording_{false};
    std::atomic<size_t> writeFrame_{0};
};

} // namespace rubab
