#include "Recorder.h"
#include "WavWriter.h"
#include <algorithm>

namespace rubab {

void Recorder::prepare(double sampleRate, int maxSeconds) {
    sr_ = sampleRate;
    capacityFrames_ = (int)(sampleRate * maxSeconds);
    buffer_.assign((size_t)capacityFrames_ * 2, 0.0f); // pre-allocate, realtime-safe
    writeFrame_.store(0);
    recording_.store(false);
}

void Recorder::arm() {
    writeFrame_.store(0);
    recording_.store(true);
}

void Recorder::disarm() {
    recording_.store(false);
}

void Recorder::clear() {
    recording_.store(false);
    writeFrame_.store(0);
}

void Recorder::capture(const float* interleavedStereo, int frames) {
    if (!recording_.load()) return;
    size_t w = writeFrame_.load();
    for (int i = 0; i < frames; ++i) {
        if ((int)w >= capacityFrames_) { recording_.store(false); break; }
        buffer_[w * 2]     = interleavedStereo[i * 2];
        buffer_[w * 2 + 1] = interleavedStereo[i * 2 + 1];
        ++w;
    }
    writeFrame_.store(w);
}

int Recorder::exportWav(const std::string& path) {
    const int frames = (int)writeFrame_.load();
    if (frames <= 0) return 0;
    WavWriter wav;
    if (!wav.open(path.c_str(), (int)sr_, 2)) return 0;
    // Write in chunks.
    const int chunk = 4096;
    int written = 0;
    while (written < frames) {
        const int c = std::min(chunk, frames - written);
        wav.writeInterleaved(buffer_.data() + (size_t)written * 2, c);
        written += c;
    }
    wav.close();
    return frames;
}

} // namespace rubab
