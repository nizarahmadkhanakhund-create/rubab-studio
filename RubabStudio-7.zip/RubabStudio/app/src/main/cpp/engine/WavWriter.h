#pragma once
#include <cstdint>
#include <cstdio>

namespace rubab {

// Minimal 16-bit PCM stereo WAV writer. Used for offline export of recordings.
class WavWriter {
public:
    bool open(const char* path, int sampleRate, int channels);
    void writeInterleaved(const float* data, int frames); // float [-1,1]
    void close();
    bool isOpen() const { return file_ != nullptr; }

private:
    void writeHeader();
    void patchHeader();

    FILE* file_ = nullptr;
    int sampleRate_ = 48000;
    int channels_ = 2;
    uint32_t dataBytes_ = 0;
};

} // namespace rubab
