#include "WavWriter.h"
#include "../util/DspMath.h"
#include <cstring>

namespace rubab {

static void writeU32(FILE* f, uint32_t v) { fwrite(&v, 4, 1, f); }
static void writeU16(FILE* f, uint16_t v) { fwrite(&v, 2, 1, f); }

bool WavWriter::open(const char* path, int sampleRate, int channels) {
    file_ = fopen(path, "wb");
    if (!file_) return false;
    sampleRate_ = sampleRate;
    channels_ = channels;
    dataBytes_ = 0;
    writeHeader();
    return true;
}

void WavWriter::writeHeader() {
    const uint16_t bits = 16;
    const uint32_t byteRate = sampleRate_ * channels_ * bits / 8;
    const uint16_t blockAlign = channels_ * bits / 8;
    fwrite("RIFF", 1, 4, file_);
    writeU32(file_, 0); // patched on close
    fwrite("WAVE", 1, 4, file_);
    fwrite("fmt ", 1, 4, file_);
    writeU32(file_, 16);
    writeU16(file_, 1);            // PCM
    writeU16(file_, channels_);
    writeU32(file_, sampleRate_);
    writeU32(file_, byteRate);
    writeU16(file_, blockAlign);
    writeU16(file_, bits);
    fwrite("data", 1, 4, file_);
    writeU32(file_, 0); // patched on close
}

void WavWriter::writeInterleaved(const float* data, int frames) {
    if (!file_) return;
    const int samples = frames * channels_;
    for (int i = 0; i < samples; ++i) {
        float x = clampf(data[i], -1.0f, 1.0f);
        int16_t s = (int16_t)(x * 32767.0f);
        writeU16(file_, (uint16_t)s);
    }
    dataBytes_ += (uint32_t)samples * 2u;
}

void WavWriter::patchHeader() {
    fseek(file_, 4, SEEK_SET);
    writeU32(file_, 36 + dataBytes_);
    fseek(file_, 40, SEEK_SET);
    writeU32(file_, dataBytes_);
}

void WavWriter::close() {
    if (!file_) return;
    patchHeader();
    fclose(file_);
    file_ = nullptr;
}

} // namespace rubab
