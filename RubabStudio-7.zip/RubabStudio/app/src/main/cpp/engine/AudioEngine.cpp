#include "AudioEngine.h"
#include "InstrumentRegistry.h"
#include <android/log.h>
#include <cmath>

#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, "RubabEngine", __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, "RubabEngine", __VA_ARGS__)

namespace rubab {

bool AudioEngine::start() {
    if (stream_) return true;

    oboe::AudioStreamBuilder b;
    b.setDirection(oboe::Direction::Output)
     ->setPerformanceMode(oboe::PerformanceMode::LowLatency)
     ->setSharingMode(oboe::SharingMode::Exclusive)
     ->setFormat(oboe::AudioFormat::Float)
     ->setChannelCount(2)
     ->setSampleRate(48000)
     ->setSampleRateConversionQuality(oboe::SampleRateConversionQuality::Medium)
     ->setUsage(oboe::Usage::Media)
     ->setContentType(oboe::ContentType::Music)
     ->setDataCallback(this)
     ->setErrorCallback(this);

    oboe::Result r = b.openStream(stream_);
    if (r != oboe::Result::OK || !stream_) {
        LOGE("Failed to open stream: %s", oboe::convertToText(r));
        stream_.reset();
        return false;
    }

    sampleRate_ = stream_->getSampleRate();
    maxBlock_ = 1024;

    // Prepare the whole signal path at the real device sample rate.
    alloc_.prepare(sampleRate_, maxBlock_);
    symBank_.prepare(sampleRate_);
    symBank_.configure(14, 146.83f, 2.0f, 0.07f); // D3 drone ladder, subtle & short
    symBank_.setEnabled(true);

    for (int i = 0; i < 3; ++i) { eqL_[i].setSampleRate(sampleRate_); eqR_[i].setSampleRate(sampleRate_); }
    spatial_.prepare(sampleRate_);
    modulation_.prepare(sampleRate_);
    delay_.prepare(sampleRate_);
    algoReverb_.prepare(sampleRate_);
    convReverb_.prepare(sampleRate_, 256);
    convReverb_.setMaxTailSec(0.6f);
    convReverb_.loadSpace(ImpulseFactory::HALL);
    recorder_.prepare(sampleRate_, 600);

    buildFxChain();

    r = stream_->requestStart();
    if (r != oboe::Result::OK) {
        LOGE("Failed to start stream: %s", oboe::convertToText(r));
        stream_->close();
        stream_.reset();
        return false;
    }
    LOGI("Engine started @ %.0f Hz, burst=%d", sampleRate_, stream_->getFramesPerBurst());
    return true;
}

void AudioEngine::stop() {
    if (!stream_) return;
    stream_->requestStop();
    stream_->close();
    stream_.reset();
}

void AudioEngine::buildFxChain() {
    // Dry, clean studio defaults. A little air, not a wash.
    setEq(0.0f, 0.0f, 0.0f);
    setAlgoReverb(0.4f, 0.6f, 0.03f);
    setDelay(380.0f, 0.3f, 0.0f);
    setModulation(0.5f, 6.0f, 0.0f);
    setSaturation(1.4f, 0.15f);
    setSpatial(1.05f, 0.18f);
    convMix_.store(0.10f);
    masterGain_.store(0.9f);
}

// ---------------- Event queue ----------------
void AudioEngine::push(const Event& e) {
    std::lock_guard<std::mutex> lk(produceMutex_);
    const uint32_t head = qHead_.load(std::memory_order_relaxed);
    const uint32_t next = (head + 1) % kQueueSize;
    if (next == qTail_.load(std::memory_order_acquire)) return; // full: drop
    queue_[head] = e;
    qHead_.store(next, std::memory_order_release);
}

void AudioEngine::drainEvents() {
    uint32_t tail = qTail_.load(std::memory_order_relaxed);
    const uint32_t head = qHead_.load(std::memory_order_acquire);
    while (tail != head) {
        const Event& e = queue_[tail];
        switch (e.type) {
            case Event::NOTE_ON: {
                const InstrumentDefinition& def = InstrumentRegistry::instance().get(e.instrumentId);
                alloc_.noteOn(e.touchId, def, e.f0, e.f1, (Articulation)e.iarg, e.f2);
                // Sympathetic resonance follows the played instrument.
                symActive_.store(def.p.ks_sympCount > 0 ? def.p.ks_sympCount : 0);
                symDrive_.store(def.p.ks_sympathetic);
                break;
            }
            case Event::NOTE_OFF:  alloc_.noteOff(e.touchId); break;
            case Event::BEND:      alloc_.setBend(e.touchId, e.f0); break;
            case Event::PRESSURE:  alloc_.setPressure(e.touchId, e.f0); break;
            case Event::ALL_OFF:   alloc_.allNotesOff(false); break;
        }
        tail = (tail + 1) % kQueueSize;
    }
    qTail_.store(tail, std::memory_order_release);
}

void AudioEngine::postNoteOn(int touchId, int instrumentId, float midiNote, float velocity,
                             int articulation, float artParam) {
    Event e; e.type = Event::NOTE_ON; e.touchId = touchId; e.instrumentId = instrumentId;
    e.f0 = midiNote; e.f1 = velocity; e.f2 = artParam; e.iarg = articulation; push(e);
}
void AudioEngine::postNoteOff(int touchId) { Event e; e.type = Event::NOTE_OFF; e.touchId = touchId; push(e); }
void AudioEngine::postBend(int touchId, float s) { Event e; e.type = Event::BEND; e.touchId = touchId; e.f0 = s; push(e); }
void AudioEngine::postPressure(int touchId, float p) { Event e; e.type = Event::PRESSURE; e.touchId = touchId; e.f0 = p; push(e); }
void AudioEngine::postAllNotesOff() { Event e; e.type = Event::ALL_OFF; push(e); }

// ---------------- Parameter setters ----------------
void AudioEngine::setReverbSpace(int space) {
    if (space < 0 || space >= ImpulseFactory::SPACE_COUNT) return;
    std::lock_guard<std::mutex> lk(reverbMutex_);
    convReverb_.loadSpace((ImpulseFactory::Space)space);
}

void AudioEngine::setAlgoReverb(float room, float damp, float mix) {
    algoReverb_.setRoomSize(room);
    algoReverb_.setDamping(damp);
    algoReverb_.setMix(mix);
}

void AudioEngine::setDelay(float timeMs, float feedback, float mix) {
    delay_.setTimeMs(timeMs, timeMs * 1.5f);
    delay_.setFeedback(feedback);
    delay_.setMix(mix);
    delay_.setCrossFeed(0.35f);
}

void AudioEngine::setModulation(float rateHz, float depthMs, float mix) {
    modulation_.setRateHz(rateHz);
    modulation_.setDepthMs(depthMs);
    modulation_.setMix(mix);
}

void AudioEngine::setEq(float lowDb, float midDb, float highDb) {
    for (int ch = 0; ch < 2; ++ch) {
        Biquad* eq = (ch == 0) ? eqL_ : eqR_;
        eq[0].set(Biquad::LOWSHELF, 180.0f, 0.707f, lowDb);
        eq[1].set(Biquad::PEAK, 1200.0f, 0.9f, midDb);
        eq[2].set(Biquad::HIGHSHELF, 4500.0f, 0.707f, highDb);
    }
}

void AudioEngine::setSaturation(float drive, float mix) {
    saturator_.setDrive(drive);
    saturator_.setMix(mix);
    saturator_.setCeiling(0.98f);
}

void AudioEngine::setSpatial(float width, float depth) {
    spatial_.setWidth(width);
    spatial_.setDepth(depth);
}

void AudioEngine::setMetronome(bool on, float bpm, int beatsPerBar) {
    metroOn_.store(on);
    metroBpm_.store(clampf(bpm, 20.0f, 300.0f));
    metroBeats_.store(std::max(1, beatsPerBar));
    if (on) { metroPhase_ = 0.0; metroBeatIdx_ = 0; }
}

// ---------------- Audio callback ----------------
oboe::DataCallbackResult AudioEngine::onAudioReady(oboe::AudioStream*, void* audioData, int32_t numFrames) {
    float* out = static_cast<float*>(audioData);
    drainEvents();

    symBank_.setRuntime(symActive_.load(), symDrive_.load());
    convReverb_.setMix(convMix_.load());
    const float mg = masterGain_.load();

    int done = 0;
    while (done < numFrames) {
        const int n = std::min(numFrames - done, maxBlock_);
        float* L = busL_.data();
        float* R = busR_.data();
        std::fill(L, L + n, 0.0f);
        std::fill(R, R + n, 0.0f);

        // 1) Voices.
        alloc_.renderAdd(L, R, n);

        // 2) Sympathetic resonance (driven by the full mix).
        if (symActive_.load() > 0) {
            for (int k = 0; k < n; ++k) {
                const float mono = (L[k] + R[k]) * 0.5f;
                const float s = symBank_.process(mono);
                L[k] += s * 0.5f; R[k] += s * 0.5f;
            }
        }

        // 3) Master EQ.
        for (int k = 0; k < n; ++k) {
            float l = L[k], r = R[k];
            l = eqL_[0].process(l); l = eqL_[1].process(l); l = eqL_[2].process(l);
            r = eqR_[0].process(r); r = eqR_[1].process(r); r = eqR_[2].process(r);
            L[k] = l; R[k] = r;
        }

        // 4) Metronome click.
        if (metroOn_.load()) {
            const double spb = sampleRate_ * 60.0 / metroBpm_.load();
            for (int k = 0; k < n; ++k) {
                if (metroPhase_ <= 0.0) {
                    metroPhase_ += spb;
                    const bool down = (metroBeatIdx_ == 0);
                    metroBeatIdx_ = (metroBeatIdx_ + 1) % metroBeats_.load();
                    metroClickInc_ = kTwoPi * (down ? 2000.0f : 1200.0f) / (float)sampleRate_;
                    metroClickLen_ = (int)(0.03 * sampleRate_);
                    metroClickPos_ = 0;
                    metroClick_ = 0.0f;
                }
                if (metroClickPos_ < metroClickLen_) {
                    const float env = std::exp(-(float)metroClickPos_ / (0.008f * sampleRate_));
                    const float c = std::sin(metroClick_) * env * 0.25f;
                    metroClick_ += metroClickInc_;
                    L[k] += c; R[k] += c;
                    ++metroClickPos_;
                }
                metroPhase_ -= 1.0;
            }
        }

        // 5) Spatial stage + modulation + delay.
        spatial_.process(L, R, n);
        modulation_.process(L, R, n);
        delay_.process(L, R, n);

        // 6) Reverbs (algorithmic always; convolution under try-lock).
        algoReverb_.process(L, R, n);
        if (reverbMutex_.try_lock()) {
            convReverb_.process(L, R, n);
            reverbMutex_.unlock();
        }

        // 7) Master saturation + gain → interleaved output.
        saturator_.process(L, R, n);
        float* dst = out + done * 2;
        for (int k = 0; k < n; ++k) {
            dst[k * 2]     = L[k] * mg;
            dst[k * 2 + 1] = R[k] * mg;
        }

        // 8) Capture for recording (post-master).
        recorder_.capture(dst, n);

        done += n;
    }

    activeVoices_.store(alloc_.activeCount());
    return oboe::DataCallbackResult::Continue;
}

void AudioEngine::onErrorAfterClose(oboe::AudioStream*, oboe::Result result) {
    LOGE("Stream error after close: %s — attempting restart", oboe::convertToText(result));
    stream_.reset();
    start();
}

void AudioEngine::applyPendingReverb() { /* handled directly in setReverbSpace */ }

} // namespace rubab
