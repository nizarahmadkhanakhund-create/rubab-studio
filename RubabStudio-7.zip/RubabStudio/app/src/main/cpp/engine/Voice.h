#pragma once
#include "EngineTypes.h"
#include "../util/Random.h"
#include "../util/DspMath.h"

namespace rubab {

// Base class for every synthesis voice. Voices are pre-allocated in pools at
// engine start (prepare) so note-on is allocation-free and realtime-safe.
class Voice {
public:
    virtual ~Voice() = default;

    // Called once, off the audio thread, to size buffers.
    virtual void prepare(double sampleRate, int maxBlock) {
        sampleRate_ = sampleRate;
        maxBlock_ = maxBlock;
    }

    // Start a note. midiNote may be fractional (micro-tuning / bends start).
    virtual void noteOn(const InstrumentParams& ip, float midiNote, float velocity,
                        Articulation art, float artParam, Xorshift& rng) = 0;

    // Begin release. The voice keeps ringing until isActive() goes false.
    virtual void noteOff() = 0;

    // Continuous expression updates (fretboard gestures / MIDI / aftertouch).
    virtual void setBend(float semitones) { bendSemis_ = semitones; }
    virtual void setPressure(float pressure) { pressure_ = clampf(pressure, 0.0f, 1.0f); }

    // Add this voice's mono output into `out` (length n). Panning is applied
    // by the mixer, not here.
    virtual void renderAdd(float* out, int n) = 0;

    virtual bool isActive() const = 0;

    // Immediate silence (used on reset / voice reuse safety).
    virtual void kill() { active_ = false; }

    // Mixer bookkeeping.
    int      touchId     = -1;
    int      instrumentId = -1;
    float    pan         = 0.0f;   // -1..1
    float    level       = 1.0f;   // velocity-derived gain
    uint64_t startAge    = 0;      // for "steal oldest" logic
    bool     released    = false;

protected:
    double sampleRate_ = 48000.0;
    int    maxBlock_   = 256;
    float  bendSemis_  = 0.0f;
    float  pressure_   = 0.0f;
    bool   active_     = false;
};

} // namespace rubab
