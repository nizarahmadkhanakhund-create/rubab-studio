#pragma once
#include "../engine/Voice.h"
#include "../fx/Biquad.h"

namespace rubab {

// Breath-excited harmonic resonator bank. A filtered breath-noise source drives
// a set of high-Q harmonic resonators whose relative levels morph from a pure,
// hollow flute (bansuri, concert flute) to a rich double-reed (duduk) via the
// `reediness` parameter. Expressive breath pressure and vibrato are continuous.
class WindVoice : public Voice {
public:
    void prepare(double sampleRate, int maxBlock) override;
    void noteOn(const InstrumentParams& ip, float midiNote, float velocity,
                Articulation art, float artParam, Xorshift& rng) override;
    void noteOff() override;
    void renderAdd(float* out, int n) override;
    bool isActive() const override { return active_; }
    void kill() override;

private:
    static constexpr int kHarm = 5;
    void retuneResonators(float vibSemis);

    InstrumentParams ip_;
    Biquad res_[kHarm];
    Biquad formant_;
    float  harmAmp_[kHarm] = {1, 0.3f, 0.15f, 0.07f, 0.03f};

    float  baseFreq_ = 440.0f;
    float  breathLpState_ = 0.0f;
    Ramp   breath_;
    float  breathNoise_ = 0.25f;

    Ramp   gateRamp_;
    float  ampFollow_ = 0.0f;
    float  vibPhase_ = 0.0f;
    float  vibRate_ = 5.0f;
    float  vibDepth_ = 0.08f;
    Xorshift rng_;
};

} // namespace rubab
