#include "KeyedVoice.h"
#include <cmath>

namespace rubab {

void KeyedVoice::prepare(double sampleRate, int maxBlock) {
    Voice::prepare(sampleRate, maxBlock);
    for (auto& d : dl_) d.prepare(4096);
    board1_.setSampleRate(sampleRate);
    board2_.setSampleRate(sampleRate);
}

void KeyedVoice::noteOn(const InstrumentParams& ip, float midiNote, float velocity,
                        Articulation art, float artParam, Xorshift& rng) {
    ip_ = ip;
    rng_.seed(rng.nextU32());
    sustained_ = ip.key_sustained;
    baseFreq_ = midiToHz(midiNote + ip.tuneSemis);
    bendSemis_ = 0.0f;
    pressure_ = 0.0f;
    released = false;
    ampFollow_ = 0.0f;
    vibPhase_ = 0.0f;
    level = 0.25f + 0.75f * clampf(velocity, 0.0f, 1.0f);

    if (!sustained_) {
        // ---- Piano ----
        numStr_ = clampf(static_cast<float>(ip.key_unison), 1, kStr);
        const float baseDelay = static_cast<float>(sampleRate_) / baseFreq_;
        const float roundTrip = baseDelay / static_cast<float>(sampleRate_);
        // Per-key voicing: bass strings sustain far longer than the treble, as
        // on a real piano.
        const float reg = registerT(midiNote, ip.key_regLowMidi, ip.key_regHighMidi);
        const float keyDecay = ip.key_decaySec * lerp(ip.key_decayLowScale, ip.key_decayHighScale, reg);
        loopGain_ = clampf(std::pow(10.0f, -3.0f * roundTrip / std::max(keyDecay, 0.1f)),
                           0.0f, 0.99998f);
        loopDamp_ = clampf(0.12f + (1.0f - velocity) * 0.18f, 0.0f, 0.49f);
        dispCoef_ = clampf(ip.key_inharm * 260.0f, 0.0f, 0.4f);
        dispStages_ = 3;

        for (int s = 0; s < numStr_; ++s) {
            dl_[s].clear();
            lpPrev_[s] = 0.0f;
            for (int a = 0; a < 6; ++a) { apX_[s][a] = 0; apY_[s][a] = 0; }
            float cents = (numStr_ > 1) ? ip.key_unisonDet * (static_cast<float>(s) / (numStr_ - 1) - 0.5f) : 0.0f;
            detune_[s] = std::pow(2.0f, cents / 1200.0f);
            curDelay_[s] = baseDelay * detune_[s];
        }

        // Hammer burst: softer / broader than a pluck, brightness from velocity.
        const float hard = clampf(ip.key_hammerHard + velocity * 0.4f, 0.0f, 1.0f);
        int len = static_cast<int>((6.0f + (1.0f - hard) * 10.0f) * 0.001f * sampleRate_);
        if (len > 4096) len = 4096;
        float lp = 0.0f;
        const float c = clampf(0.7f - hard * 0.5f, 0.05f, 0.9f);
        for (int i = 0; i < len; ++i) {
            float w = rng_.nextBipolar();
            lp = (1.0f - c) * w + c * lp;
            const float win = std::sin(kPi * i / len); // soft hammer contact window
            burst_[i] = lp * win;
        }
        const float vg = 0.3f + 0.6f * velocity;
        for (int i = 0; i < len; ++i) burst_[i] *= vg;
        burstLen_ = len; burstPos_ = 0;

        board1_.reset(); board2_.reset();
        board1_.set(Biquad::PEAK, 120.0f, 1.5f, 4.0f);
        board2_.set(Biquad::PEAK, 2600.0f, 0.8f, 3.0f);
    } else {
        // ---- Harmonium ----
        for (int i = 0; i < kPartials; ++i) {
            phase_[i] = 0.0f;
            phaseB_[i] = rng_.nextUnipolar() * kTwoPi;
            // Reed spectrum: 1/n with extra richness controlled by key_reedHarm.
            const float base = 1.0f / (i + 1.0f);
            const float rich = std::pow((i + 1.0f), -0.4f) * ip.key_reedHarm;
            partAmp_[i] = base + rich;
        }
        reedLpState_ = 0.0f;
        sustainEnv_.reset(0.0f);
        sustainEnv_.to(0.55f + 0.3f * velocity, static_cast<int>(0.035f * sampleRate_));
    }

    gateRamp_.reset(0.0f);
    gateRamp_.to(1.0f, static_cast<int>(0.002f * sampleRate_));
    active_ = true;
}

void KeyedVoice::noteOff() {
    if (!active_) return;
    released = true;
    if (gateRamp_.value < 0.25f) gateRamp_.value = 0.9f; // ensure quick taps sound
    if (!sustained_) {
        // Piano damper falls on the strings: defined fade + raised damping.
        gateRamp_.to(0.0f, static_cast<int>(0.26f * sampleRate_));
        loopGain_ *= 0.94f;
        loopDamp_ = clampf(loopDamp_ + 0.25f, 0.0f, 0.49f);
    } else {
        // Harmonium: bellows closes.
        sustainEnv_.to(0.0f, static_cast<int>(0.12f * sampleRate_));
        gateRamp_.to(0.0f, static_cast<int>(0.18f * sampleRate_));
    }
}

void KeyedVoice::kill() {
    gateRamp_.to(0.0f, static_cast<int>(0.003f * sampleRate_));
    released = true;
}

void KeyedVoice::renderPiano(float* out, int n) {
    const float invSr = static_cast<float>(sampleRate_);
    for (int k = 0; k < n; ++k) {
        const float freq = baseFreq_ * std::pow(2.0f, bendSemis_ / 12.0f);
        const float baseDelay = invSr / std::max(freq, 20.0f);

        float bs = 0.0f;
        if (burstPos_ < burstLen_) bs = burst_[burstPos_++];

        float s = 0.0f;
        for (int si = 0; si < numStr_; ++si) {
            curDelay_[si] = baseDelay * detune_[si];
            float d = dl_[si].read(curDelay_[si]);
            float x = d;
            for (int a = 0; a < dispStages_; ++a) {
                const float y = dispCoef_ * x + apX_[si][a] - dispCoef_ * apY_[si][a];
                apX_[si][a] = x; apY_[si][a] = flushDenorm(y); x = y;
            }
            const float lp = (1.0f - loopDamp_) * x + loopDamp_ * lpPrev_[si];
            lpPrev_[si] = flushDenorm(lp);
            dl_[si].push(lp * loopGain_ + bs);
            s += d;
        }
        s *= (numStr_ > 1) ? 0.6f : 1.0f;

        const float board = 0.6f * s + 0.4f * (board1_.process(s) + board2_.process(s)) * 0.5f;
        const float g = gateRamp_.next() * level;
        const float o = board * g;
        out[k] += o;
        const float a = std::fabs(o);
        ampFollow_ = (a > ampFollow_) ? a : ampFollow_ * 0.99985f;
    }
    if (gateRamp_.done() && gateRamp_.value <= 0.0001f) active_ = false;
    if (ampFollow_ < 2.0e-5f && (released || burstPos_ >= burstLen_)) active_ = false;
}

void KeyedVoice::renderHarmonium(float* out, int n) {
    const float vibInc = kTwoPi * 4.5f / static_cast<float>(sampleRate_);
    for (int k = 0; k < n; ++k) {
        vibPhase_ += vibInc; if (vibPhase_ > kTwoPi) vibPhase_ -= kTwoPi;
        const float vib = 0.015f * std::sin(vibPhase_);
        const float freq = baseFreq_ * std::pow(2.0f, (bendSemis_ + vib) / 12.0f);

        float sig = 0.0f;
        for (int i = 0; i < kPartials; ++i) {
            const float hf = freq * (i + 1);
            if (hf > sampleRate_ * 0.45f) continue;
            const float inc = kTwoPi * hf / static_cast<float>(sampleRate_);
            phase_[i] += inc;  if (phase_[i] > kTwoPi) phase_[i] -= kTwoPi;
            phaseB_[i] += inc * 1.0008f; if (phaseB_[i] > kTwoPi) phaseB_[i] -= kTwoPi; // reed beating
            sig += (std::sin(phase_[i]) + std::sin(phaseB_[i])) * 0.5f * partAmp_[i];
        }
        // Bellows air.
        const float air = (rng_.nextBipolar());
        reedLpState_ = 0.5f * air + 0.5f * reedLpState_;
        sig = sig * 0.25f + reedLpState_ * 0.03f;

        const float env = sustainEnv_.next();
        const float g = gateRamp_.next() * level;
        const float o = fastTanh(sig * (1.0f + pressure_ * 0.5f)) * env * g;
        out[k] += o;
        const float a = std::fabs(o);
        ampFollow_ = (a > ampFollow_) ? a : ampFollow_ * 0.9997f;
    }
    if (gateRamp_.done() && gateRamp_.value <= 0.0001f) active_ = false;
    if (released && sustainEnv_.done() && ampFollow_ < 3.0e-4f) active_ = false;
}

void KeyedVoice::renderAdd(float* out, int n) {
    if (!active_) return;
    if (sustained_) renderHarmonium(out, n);
    else renderPiano(out, n);
}

} // namespace rubab
