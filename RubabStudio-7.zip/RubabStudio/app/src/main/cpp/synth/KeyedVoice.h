#pragma once
#include "../engine/Voice.h"
#include "../util/DelayLine.h"
#include "../fx/Biquad.h"

namespace rubab {

// Keyed instruments. Two sub-engines selected by InstrumentParams::key_sustained:
//   * Piano    — coupled, detuned, inharmonic hammered strings + soundboard.
//   * Harmonium — additive free-reed drone that sustains while the key is held,
//                 with reed beating and a breath of bellows noise.
class KeyedVoice : public Voice {
public:
    void prepare(double sampleRate, int maxBlock) override;
    void noteOn(const InstrumentParams& ip, float midiNote, float velocity,
                Articulation art, float artParam, Xorshift& rng) override;
    void noteOff() override;
    void renderAdd(float* out, int n) override;
    bool isActive() const override { return active_; }
    void kill() override;

private:
    void renderPiano(float* out, int n);
    void renderHarmonium(float* out, int n);

    InstrumentParams ip_;
    bool sustained_ = false;
    float baseFreq_ = 440.0f;

    // ---- Piano strings ----
    static constexpr int kStr = kMaxUnison;
    DelayLine dl_[kStr];
    float curDelay_[kStr] = {0};
    float detune_[kStr] = {1, 1, 1};
    float loopGain_ = 0.9999f;
    float loopDamp_ = 0.2f;
    float lpPrev_[kStr] = {0};
    float dispCoef_ = 0.0f;
    int   dispStages_ = 2;
    float apX_[kStr][6] = {{0}};
    float apY_[kStr][6] = {{0}};
    int   numStr_ = 3;

    float burst_[4096];
    int   burstLen_ = 0, burstPos_ = 0;

    Biquad board1_, board2_;

    // ---- Harmonium additive ----
    static constexpr int kPartials = 10;
    float phase_[kPartials] = {0};
    float phaseB_[kPartials] = {0};
    float partAmp_[kPartials] = {0};
    float reedLpState_ = 0.0f;
    Ramp  sustainEnv_;

    Ramp  gateRamp_;
    float ampFollow_ = 0.0f;
    Xorshift rng_;
    float vibPhase_ = 0.0f;
};

} // namespace rubab
