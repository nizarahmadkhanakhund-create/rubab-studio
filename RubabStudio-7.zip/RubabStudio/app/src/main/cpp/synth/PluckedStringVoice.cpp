#include "PluckedStringVoice.h"
#include <cmath>

namespace rubab {

// ----------------------- KsString -----------------------
void KsString::reset() {
    dl.clear();
    lpPrev = 0.0f;
    for (int i = 0; i < 8; ++i) { apX[i] = 0.0f; apY[i] = 0.0f; }
}

void KsString::retune(float freqHz, double sr, bool glide) {
    targetDelay = static_cast<float>(sr) / std::max(freqHz, 20.0f) * detuneRatio;
    if (!glide) curDelay = targetDelay;
}

void KsString::excite(float*, int) { /* excitation injected via step() input */ }

inline float KsString::step(float extraInput) {
    const float d = dl.read(curDelay);

    // Dispersion (string stiffness → stretched, inharmonic partials).
    float x = d;
    for (int s = 0; s < dispStages; ++s) {
        const float y = dispCoef * x + apX[s] - dispCoef * apY[s];
        apX[s] = x;
        apY[s] = flushDenorm(y);
        x = y;
    }

    // Loop lowpass: progressive high-frequency decay (brightness/damping).
    const float lp = (1.0f - loopDamp) * x + loopDamp * lpPrev;
    lpPrev = flushDenorm(lp);

    // Jawari / bridge buzz: soft saturating nonlinearity (sitar shimmer).
    float br = lp;
    if (buzz > 0.0f) {
        const float shaped = fastTanh(br * (1.0f + buzz * 6.0f));
        br = br + buzz * (shaped - br);
    }

    dl.push(br * loopGain + extraInput);
    return d;
}

// ----------------------- PluckedStringVoice -----------------------
void PluckedStringVoice::prepare(double sampleRate, int maxBlock) {
    Voice::prepare(sampleRate, maxBlock);
    for (auto& s : strings_) s.prepare(4096);
    for (auto& s : polar_)   s.prepare(4096);
    body1_.setSampleRate(sampleRate);
    body2_.setSampleRate(sampleRate);
    body3_.setSampleRate(sampleRate);
}

void PluckedStringVoice::configureString(KsString& s, float loopGain, float damp,
                                         int dispStages, float dispCoef, float buzz) {
    s.loopGain = loopGain;
    s.loopDamp = damp;
    s.dispStages = dispStages;
    s.dispCoef = dispCoef;
    s.buzz = buzz;
}

void PluckedStringVoice::buildBurst(float velocity, Articulation art, Xorshift& rng, int& lenOut) {
    float ms;
    float cutoffCoef; // one-pole darkening of the burst (higher = darker)
    float pickAmt = 0.85f;
    switch (art) {
        case ART_HARMONIC: ms = 2.2f;  cutoffCoef = 0.05f; pickAmt = 0.0f;  break;
        case ART_MUTE:     ms = 3.0f;  cutoffCoef = 0.55f; pickAmt = 0.7f;  break;
        case ART_HAMMER:   ms = 7.0f;  cutoffCoef = 0.45f; pickAmt = 0.6f;  break;
        default:           ms = 5.0f;  cutoffCoef = 0.25f - velocity * 0.15f; pickAmt = 0.85f; break;
    }
    int len = static_cast<int>(ms * 0.001f * sampleRate_);
    if (len < 8) len = 8;
    if (len > kMaxBurst) len = kMaxBurst;

    float lp = 0.0f;
    const float c = clampf(cutoffCoef, 0.0f, 0.9f);
    for (int i = 0; i < len; ++i) {
        float w = rng.nextBipolar();
        lp = (1.0f - c) * w + c * lp;
        const float win = 0.5f * (1.0f - std::cos(kTwoPi * i / len));
        burst_[i] = lp * win;
    }

    // Pick-position comb: notch at harmonics determined by plucking point.
    const int pickDelay = static_cast<int>(ip_.ks_pickPos * (sampleRate_ / baseFreq_));
    if (pickAmt > 0.0f && pickDelay > 0 && pickDelay < len) {
        for (int i = len - 1; i >= pickDelay; --i)
            burst_[i] -= pickAmt * burst_[i - pickDelay];
    }

    const float vgain = 0.35f + 0.55f * velocity;
    for (int i = 0; i < len; ++i) burst_[i] *= vgain;

    // Finger/pick contact transient: a very short bright click layered at the
    // attack adds the tactile "bite" of a real plucked string. Scaled by both
    // velocity and the instrument's finger-noise amount.
    const float fn = ip_.ks_fingerNoise * (0.4f + 0.6f * velocity);
    if (fn > 0.0f) {
        const int click = std::min(len, static_cast<int>(0.0014f * sampleRate_));
        float hp = 0.0f, prev = 0.0f;
        for (int i = 0; i < click; ++i) {
            const float w = rng.nextBipolar();
            hp = 0.5f * (w - prev); prev = w;            // crude highpass → bright
            const float decayEnv = 1.0f - static_cast<float>(i) / click;
            burst_[i] += hp * fn * decayEnv * 0.6f;
        }
    }
    lenOut = len;
}

void PluckedStringVoice::noteOn(const InstrumentParams& ip, float midiNote, float velocity,
                                Articulation art, float artParam, Xorshift& rng) {
    ip_ = ip;
    art_ = art;
    rng_ = &rng;
    localRng_.seed(rng.nextU32());

    baseMidi_ = midiNote + ip.tuneSemis;
    // Analogue humanization: a tiny per-note random detune so repeats never
    // sound mechanically identical.
    const float humanCents = ip.ks_humanCents * localRng_.nextBipolar();
    humanDetune_ = std::pow(2.0f, humanCents / 1200.0f);
    baseFreq_ = midiToHz(baseMidi_) * humanDetune_;
    bendSemis_ = 0.0f;
    pressure_ = 0.0f;
    released = false;
    vibPhase_ = 0.0f;
    ampFollow_ = 0.0f;

    level = 0.25f + 0.75f * clampf(velocity, 0.0f, 1.0f);
    numStrings_ = clampf(static_cast<float>(ip.ks_unison), 1, kMaxUnison);

    // --- Per-register voicing: every note gets its own decay/brightness/inharm ---
    const float reg = registerT(midiNote, ip.ks_regLowMidi, ip.ks_regHighMidi);
    float decay = ip.ks_decaySec * lerp(ip.ks_decayLowScale, ip.ks_decayHighScale, reg);
    muted_ = (art == ART_MUTE);
    if (muted_) decay *= 0.18f;
    if (art == ART_HARMONIC) decay *= 0.8f;
    // Keep the natural ring musical, never an endless tail.
    decay = clampf(decay, 0.05f, 3.5f);

    const float baseDelay = static_cast<float>(sampleRate_) / baseFreq_;
    const float roundTrip = baseDelay / static_cast<float>(sampleRate_);
    float loopGain = clampf(std::pow(10.0f, -3.0f * roundTrip / std::max(decay, 0.05f)), 0.0f, 0.99995f);

    const float brightLow  = ip.ks_brightLow  >= 0.0f ? ip.ks_brightLow  : ip.ks_brightness * 0.82f;
    const float brightHigh = ip.ks_brightHigh >= 0.0f ? ip.ks_brightHigh : clampf(ip.ks_brightness * 1.12f, 0.0f, 1.0f);
    const float bright = lerp(brightLow, brightHigh, reg);
    float damp = (1.0f - bright) * 0.45f + ip.ks_damping * 0.3f;
    if (muted_) damp = clampf(damp + 0.2f, 0.0f, 0.49f);
    if (art == ART_HARMONIC) damp = clampf(damp * 0.4f, 0.0f, 0.49f);
    damp = clampf(damp, 0.0f, 0.49f);

    const float inh = ip.ks_inharm * lerp(ip.ks_inharmLowScale, ip.ks_inharmHighScale, reg);
    const float dispCoef = clampf(inh * 320.0f, 0.0f, 0.42f);
    const int dispStages = static_cast<int>(clampf(static_cast<float>(ip.ks_dispStages), 0, 8));

    for (int i = 0; i < numStrings_; ++i) {
        KsString& s = strings_[i];
        s.reset();
        // Spread unison courses symmetrically in cents.
        float cents = 0.0f;
        if (numStrings_ > 1)
            cents = ip.ks_unisonDet * (static_cast<float>(i) / (numStrings_ - 1) - 0.5f);
        s.detuneRatio = std::pow(2.0f, cents / 1200.0f);
        s.panOffset = (numStrings_ > 1) ? (static_cast<float>(i) / (numStrings_ - 1) - 0.5f) * 0.4f : 0.0f;
        configureString(s, loopGain, damp, dispStages, dispCoef, ip.ks_buzz);
        s.retune(baseFreq_, sampleRate_, false);
    }

    // --- Dual polarization: a second plane that rings longer and detunes a hair ---
    polActive_ = ip.ks_dualPolar;
    polLevel_ = ip.ks_polarLevel;
    polDetuneRatio_ = std::pow(2.0f, ip.ks_polarDetune / 1200.0f);
    if (polActive_) {
        const float polDecay = clampf(decay * ip.ks_polarDecay, 0.05f, 4.0f);
        const float polGain = clampf(std::pow(10.0f, -3.0f * roundTrip / std::max(polDecay, 0.05f)), 0.0f, 0.99997f);
        const float polDamp = clampf(damp * 0.85f, 0.0f, 0.49f);
        for (int i = 0; i < numStrings_; ++i) {
            KsString& s = polar_[i];
            s.reset();
            s.detuneRatio = strings_[i].detuneRatio * polDetuneRatio_;
            configureString(s, polGain, polDamp, dispStages, dispCoef, ip.ks_buzz * 0.5f);
            s.retune(baseFreq_, sampleRate_, false);
        }
    }

    // --- 3-mode body resonator + air ---
    body1_.reset(); body2_.reset(); body3_.reset();
    body1_.set(Biquad::PEAK, ip.ks_bodyHz, ip.ks_bodyQ, 6.0f);
    body2_.set(Biquad::PEAK, ip.ks_body2Hz, ip.ks_body2Q, 4.0f);
    body3Active_ = ip.ks_body3Hz > 0.0f;
    if (body3Active_) body3_.set(Biquad::PEAK, ip.ks_body3Hz, ip.ks_body3Q, 3.0f);
    bodyMix_ = ip.ks_bodyMix;

    int len;
    buildBurst(velocity, art, localRng_, len);
    burstLen_ = len;
    burstPos_ = 0;

    // Tremolo re-excitation.
    tremoloPeriod_ = 0;
    if (art == ART_TREMOLO) {
        const float rateHz = (artParam > 0.1f) ? artParam : 11.0f;
        tremoloPeriod_ = static_cast<int>(sampleRate_ / rateHz);
        tremoloCounter_ = tremoloPeriod_;
        tremoloVel_ = 0.45f + 0.3f * velocity;
    }

    gateRamp_.reset(0.0f);
    gateRamp_.to(1.0f, static_cast<int>(0.0015f * sampleRate_));
    active_ = true;
}

void PluckedStringVoice::setBend(float semitones) { bendSemis_ = semitones; }
void PluckedStringVoice::setPressure(float pressure) { pressure_ = clampf(pressure, 0.0f, 1.0f); }

void PluckedStringVoice::noteOff() {
    if (!active_) return;
    released = true;
    // Guarantee an ultra-quick tap is actually heard: if the attack ramp has not
    // risen yet (note released within the same block it started), snap the gate
    // up so the pluck sounds before the release fade.
    if (gateRamp_.value < 0.25f) gateRamp_.value = 0.9f;
    // Lifting the finger mutes the string. A defined gate fade gives a clean,
    // predictable release (no endless ring) while the raised damping makes the
    // fade sound like a real palm/finger mute rather than a hard cut.
    gateRamp_.to(0.0f, static_cast<int>(0.28f * sampleRate_));
    for (int i = 0; i < numStrings_; ++i) {
        strings_[i].loopGain *= 0.95f;
        strings_[i].loopDamp = clampf(strings_[i].loopDamp + 0.22f, 0.0f, 0.49f);
        if (polActive_) {
            polar_[i].loopGain *= 0.95f;
            polar_[i].loopDamp = clampf(polar_[i].loopDamp + 0.22f, 0.0f, 0.49f);
        }
    }
}

void PluckedStringVoice::kill() {
    gateRamp_.to(0.0f, static_cast<int>(0.002f * sampleRate_));
    released = true;
}

void PluckedStringVoice::renderAdd(float* out, int n) {
    if (!active_) return;

    const float vibInc = kTwoPi * 5.6f / static_cast<float>(sampleRate_);
    const float invSrFreq = static_cast<float>(sampleRate_);

    for (int k = 0; k < n; ++k) {
        // Meend / vibrato pitch modulation.
        vibPhase_ += vibInc;
        if (vibPhase_ > kTwoPi) vibPhase_ -= kTwoPi;
        const float vib = pressure_ * 0.22f * std::sin(vibPhase_);
        const float semis = bendSemis_ + vib;
        const float freq = baseFreq_ * std::pow(2.0f, semis / 12.0f);
        const float baseDelay = invSrFreq / std::max(freq, 20.0f);

        // Excitation sample (initial pluck or tremolo re-excite).
        float bs = 0.0f;
        if (burstPos_ < burstLen_) bs = burst_[burstPos_++];
        if (tremoloPeriod_ > 0 && !released) {
            if (--tremoloCounter_ <= 0) {
                int len;
                buildBurst(tremoloVel_, ART_PLUCK, localRng_, len);
                burstLen_ = len;
                burstPos_ = 0;
                tremoloCounter_ = tremoloPeriod_;
            }
        }

        // Sum both polarizations of each course string.
        float s = 0.0f;
        for (int i = 0; i < numStrings_; ++i) {
            KsString& st = strings_[i];
            st.curDelay = baseDelay * st.detuneRatio;
            s += st.step(bs);
            if (polActive_) {
                KsString& pv = polar_[i];
                pv.curDelay = baseDelay * pv.detuneRatio;
                s += pv.step(bs * 0.5f) * polLevel_;   // vertical plane, coupled
            }
        }
        s *= (numStrings_ > 1) ? 0.7f : 1.0f;

        // 3-mode body resonance blend.
        const float b1 = body1_.process(s);
        const float b2 = body2_.process(s);
        float bodySum; float bodyCount;
        if (body3Active_) { bodySum = b1 + b2 + body3_.process(s); bodyCount = 3.0f; }
        else              { bodySum = b1 + b2;                     bodyCount = 2.0f; }
        const float wet = s * (1.0f - bodyMix_) + (bodySum / bodyCount) * bodyMix_;

        const float g = gateRamp_.next() * level;
        const float o = wet * g;
        out[k] += o;

        const float a = std::fabs(o);
        ampFollow_ = (a > ampFollow_) ? a : ampFollow_ * 0.9997f;
    }

    // Auto-deactivate once faded.
    if (gateRamp_.done() && gateRamp_.value <= 0.0001f) active_ = false;
    if (ampFollow_ < 2.0e-5f && (released || burstPos_ >= burstLen_)) active_ = false;
}

} // namespace rubab
