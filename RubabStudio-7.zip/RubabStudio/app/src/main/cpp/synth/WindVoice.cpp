#include "WindVoice.h"
#include <cmath>

namespace rubab {

void WindVoice::prepare(double sampleRate, int maxBlock) {
    Voice::prepare(sampleRate, maxBlock);
    for (auto& r : res_) r.setSampleRate(sampleRate);
    formant_.setSampleRate(sampleRate);
}

void WindVoice::retuneResonators(float vibSemis) {
    const float f = baseFreq_ * std::pow(2.0f, (bendSemis_ + vibSemis) / 12.0f);
    for (int h = 0; h < kHarm; ++h) {
        const float hf = f * static_cast<float>(h + 1);
        if (hf > sampleRate_ * 0.45f) { harmAmp_[h] = 0.0f; continue; }
        // Higher harmonics get progressively higher Q (sharper) for clarity.
        const float q = 60.0f + 30.0f * h;
        res_[h].set(Biquad::BANDPASS, hf, q, 0.0f);
    }
}

void WindVoice::noteOn(const InstrumentParams& ip, float midiNote, float velocity,
                       Articulation art, float artParam, Xorshift& rng) {
    ip_ = ip;
    rng_.seed(rng.nextU32());
    baseFreq_ = midiToHz(midiNote + ip.tuneSemis);
    bendSemis_ = 0.0f;
    pressure_ = 0.0f;
    released = false;
    vibPhase_ = 0.0f;
    ampFollow_ = 0.0f;
    breathLpState_ = 0.0f;

    // Per-register voicing: breathier in the low register, purer up high.
    const float reg = registerT(midiNote, ip.wind_regLowMidi, ip.wind_regHighMidi);
    breathNoise_ = ip.wind_breath * lerp(ip.wind_breathLowScale, ip.wind_breathHighScale, reg);
    vibRate_ = ip.wind_vibRate;
    vibDepth_ = ip.wind_vibDepth;

    // Morph harmonic profile between flute (pure) and reed (rich).
    const float r = clampf(ip.wind_reediness, 0.0f, 1.0f);
    const float flute[kHarm] = {1.0f, 0.25f, 0.12f, 0.05f, 0.02f};
    const float reed[kHarm]  = {1.0f, 0.75f, 0.55f, 0.38f, 0.22f};
    for (int h = 0; h < kHarm; ++h) harmAmp_[h] = lerp(flute[h], reed[h], r);

    for (auto& res : res_) res.reset();
    formant_.reset();
    formant_.set(Biquad::PEAK, ip.wind_formant1, 1.2f, 5.0f);
    retuneResonators(0.0f);

    const float attack = (art == ART_BREATH_ACCENT) ? ip.wind_attackMs * 0.4f : ip.wind_attackMs;
    const float target = 0.4f + 0.6f * velocity;
    breath_.reset(0.0f);
    breath_.to(target, static_cast<int>(std::max(attack, 1.0f) * 0.001f * sampleRate_));

    level = 0.3f + 0.7f * clampf(velocity, 0.0f, 1.0f);
    gateRamp_.reset(0.0f);
    gateRamp_.to(1.0f, static_cast<int>(0.004f * sampleRate_));
    active_ = true;
}

void WindVoice::noteOff() {
    if (!active_) return;
    released = true;
    breath_.to(0.0f, static_cast<int>(0.13f * sampleRate_));
}

void WindVoice::kill() {
    gateRamp_.to(0.0f, static_cast<int>(0.005f * sampleRate_));
    released = true;
}

void WindVoice::renderAdd(float* out, int n) {
    if (!active_) return;

    // Vibrato updated at block (control) rate; resonators retuned once.
    vibPhase_ += kTwoPi * vibRate_ / static_cast<float>(sampleRate_) * n;
    while (vibPhase_ > kTwoPi) vibPhase_ -= kTwoPi;
    const float vib = (vibDepth_ + pressure_ * 0.06f) * std::sin(vibPhase_);
    retuneResonators(vib);

    for (int k = 0; k < n; ++k) {
        const float br = breath_.next() * (0.7f + 0.5f * pressure_);
        // Breath: lowpassed white noise (air turbulence).
        const float w = rng_.nextBipolar();
        breathLpState_ = 0.6f * w + 0.4f * breathLpState_;
        const float excite = breathLpState_ * (0.5f + breathNoise_);

        float tone = 0.0f;
        for (int h = 0; h < kHarm; ++h)
            tone += res_[h].process(excite * br) * harmAmp_[h];

        // Add a touch of unpitched breath air on top for realism.
        const float air = breathLpState_ * br * breathNoise_ * 0.25f;
        float sig = formant_.process(tone) + air;

        const float g = gateRamp_.next() * level * 2.2f;
        const float o = fastTanh(sig * g);
        out[k] += o;

        const float a = std::fabs(o);
        ampFollow_ = (a > ampFollow_) ? a : ampFollow_ * 0.9996f;
    }

    if (gateRamp_.done() && gateRamp_.value <= 0.0001f) active_ = false;
    if (released && breath_.done() && ampFollow_ < 5.0e-4f) active_ = false;
}

} // namespace rubab
