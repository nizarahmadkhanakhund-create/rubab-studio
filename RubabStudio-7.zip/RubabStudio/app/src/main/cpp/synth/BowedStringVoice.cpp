#include "BowedStringVoice.h"
#include <cmath>

namespace rubab {

void BowedStringVoice::prepare(double sampleRate, int maxBlock) {
    Voice::prepare(sampleRate, maxBlock);
    dl_.prepare(4096);
    body1_.setSampleRate(sampleRate);
    body2_.setSampleRate(sampleRate);
}

void BowedStringVoice::noteOn(const InstrumentParams& ip, float midiNote, float velocity,
                              Articulation art, float artParam, Xorshift& rng) {
    ip_ = ip;
    rng_.seed(rng.nextU32());
    baseFreq_ = midiToHz(midiNote + ip.tuneSemis);
    dl_.clear();
    lpPrev_ = 0.0f;
    vibPhase_ = 0.0f;
    ampFollow_ = 0.0f;
    bendSemis_ = 0.0f;
    pressure_ = 0.0f;
    released = false;

    curDelay_ = static_cast<float>(sampleRate_) / baseFreq_;
    loopGain_ = 0.9965f;

    // Per-register voicing: higher positions sound brighter; vibrato widens as
    // you climb (as a real player naturally does).
    const float reg = registerT(midiNote, ip.bow_regLowMidi, ip.bow_regHighMidi);
    loopDamp_ = clampf(0.12f + ip.bow_position * 1.5f - reg * 0.08f
                       - (ip.bow_bright - 0.5f) * 0.14f, 0.05f, 0.45f);

    bowForce_ = ip.bow_force * (0.6f + 0.6f * velocity);
    bowNoise_ = 0.015f + 0.02f * velocity;
    vibRate_ = ip.bow_vibRate;
    vibDepth_ = ip.bow_vibDepth * lerp(ip.bow_vibLowScale, ip.bow_vibHighScale, reg);

    const float attack = (art == ART_BOW_ACCENT) ? ip.bow_attackMs * 0.4f : ip.bow_attackMs;
    const float target = 0.08f + 0.28f * velocity;
    bowVel_.reset(0.0f);
    bowVel_.to(target, static_cast<int>(std::max(attack, 1.0f) * 0.001f * sampleRate_));

    body1_.reset();
    body2_.reset();
    body1_.set(Biquad::PEAK, ip.bow_bodyHz, ip.bow_bodyQ, 6.0f);
    body2_.set(Biquad::PEAK, ip.bow_bodyHz * 2.4f, ip.bow_bodyQ * 0.8f, 4.0f);
    bodyMix_ = 0.32f;

    level = 0.3f + 0.7f * clampf(velocity, 0.0f, 1.0f);
    gateRamp_.reset(0.0f);
    gateRamp_.to(1.0f, static_cast<int>(0.003f * sampleRate_));
    active_ = true;
}

void BowedStringVoice::noteOff() {
    if (!active_) return;
    released = true;
    // Bow lifts off: speed ramps to zero, string rings down through losses.
    bowVel_.to(0.0f, static_cast<int>(0.09f * sampleRate_));
}

void BowedStringVoice::kill() {
    gateRamp_.to(0.0f, static_cast<int>(0.004f * sampleRate_));
    released = true;
}

void BowedStringVoice::renderAdd(float* out, int n) {
    if (!active_) return;
    const float vibInc = kTwoPi * vibRate_ / static_cast<float>(sampleRate_);

    for (int k = 0; k < n; ++k) {
        vibPhase_ += vibInc;
        if (vibPhase_ > kTwoPi) vibPhase_ -= kTwoPi;
        const float vib = (vibDepth_ + pressure_ * 0.1f) * std::sin(vibPhase_);
        const float freq = baseFreq_ * std::pow(2.0f, (bendSemis_ + vib) / 12.0f);
        curDelay_ = static_cast<float>(sampleRate_) / std::max(freq, 20.0f);

        const float sv = dl_.read(curDelay_);
        const float bv = bowVel_.next() * (0.7f + 0.6f * pressure_);

        // Stick-slip friction: saturating relative-velocity curve.
        const float delta = bv - sv;
        float friction = bowForce_ * delta / (0.08f + std::fabs(delta));
        friction += bowNoise_ * rng_.nextBipolar() * bv;

        // Loop filter + feedback.
        const float lp = (1.0f - loopDamp_) * sv + loopDamp_ * lpPrev_;
        lpPrev_ = flushDenorm(lp);
        dl_.push(lp * loopGain_ + friction);

        const float b1 = body1_.process(sv);
        const float b2 = body2_.process(sv);
        const float wet = sv * (1.0f - bodyMix_) + (b1 + b2) * 0.5f * bodyMix_;

        const float g = gateRamp_.next() * level;
        const float o = fastTanh(wet * 1.4f) * g; // gentle body saturation
        out[k] += o;

        const float a = std::fabs(o);
        ampFollow_ = (a > ampFollow_) ? a : ampFollow_ * 0.9997f;
    }

    if (gateRamp_.done() && gateRamp_.value <= 0.0001f) active_ = false;
    if (ampFollow_ < 2.0e-5f && released) active_ = false;
}

} // namespace rubab
