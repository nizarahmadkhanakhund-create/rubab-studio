#include "ModalPercussionVoice.h"
#include <cmath>

namespace rubab {

void ModalPercussionVoice::prepare(double sampleRate, int maxBlock) {
    Voice::prepare(sampleRate, maxBlock);
}

void ModalPercussionVoice::updateCoeffs(float glideMul) {
    for (int i = 0; i < numModes_; ++i) {
        Mode& m = modes_[i];
        const float w = m.w * glideMul;
        m.a1 = 2.0f * m.r * std::cos(clampf(w, 0.0f, kPi * 0.98f));
        m.a2 = m.r * m.r;
    }
}

void ModalPercussionVoice::noteOn(const InstrumentParams& ip, float midiNote, float velocity,
                                  Articulation art, float artParam, Xorshift& rng) {
    ip_ = ip;
    rng_.seed(rng.nextU32());
    released = false;
    ampFollow_ = 0.0f;

    // Center the drum at its natural pitch but let the pad transpose it.
    const float ref = midiToHz(60.0f);
    const float baseHz = ip.mp_baseHz * (midiToHz(midiNote + ip.tuneSemis) / ref);

    numModes_ = clampf(static_cast<float>(ip.mp_numModes), 1, kMaxModes);

    // Articulation reshapes decay and mode balance.
    float decayScale = 1.0f, hiBoost = 1.0f, loBoost = 1.0f;
    switch (art) {
        case ART_PERC_CLOSED: decayScale = 0.25f; hiBoost = 1.2f; loBoost = 0.6f; break;
        case ART_PERC_RIM:    decayScale = 0.4f;  hiBoost = 1.8f; loBoost = 0.3f; break;
        case ART_PERC_BASS:   decayScale = 1.6f;  hiBoost = 0.4f; loBoost = 1.9f; break;
        case ART_PERC_OPEN:
        default:              decayScale = 1.0f;  hiBoost = 1.0f; loBoost = 1.0f; break;
    }

    for (int i = 0; i < numModes_; ++i) {
        Mode& m = modes_[i];
        m.y1 = m.y2 = 0.0f;
        const float f = baseHz * ip.mp_ratio[i];
        m.w = kTwoPi * f / static_cast<float>(sampleRate_);
        const float dec = ip.mp_decay[i] * decayScale;
        m.r = std::exp(-1.0f / (std::max(dec, 0.002f) * static_cast<float>(sampleRate_)));
        m.r = clampf(m.r, 0.0f, 0.99995f);
        const float balance = (ip.mp_ratio[i] < 2.0f) ? loBoost : hiBoost;
        m.amp = ip.mp_amp[i] * balance;
        m.gain = 1.0f;
    }

    glide_ = ip.mp_pitchGlide * ((art == ART_PERC_OPEN || art == ART_PERC_BASS) ? 1.0f : 0.3f);
    glideEnv_ = 1.0f + glide_;         // start sharp, fall to 1.0
    updateCoeffs(glideEnv_);

    transDecay_ = ip.mp_noiseDecay;
    transLen_ = clampf(transDecay_ * 3.0f * sampleRate_, 4.0f, 8192.0f);
    transPos_ = 0;
    transAmp_ = ip.mp_noiseAmt * (0.4f + 0.8f * velocity);

    level_ = 0.35f + 0.65f * clampf(velocity, 0.0f, 1.0f);
    gateRamp_.reset(0.0f);
    gateRamp_.to(1.0f, static_cast<int>(0.0008f * sampleRate_));
    active_ = true;
}

void ModalPercussionVoice::noteOff() {
    // One-shot; a held damp (finger on head) shortens the tail slightly.
    released = true;
}

void ModalPercussionVoice::kill() {
    gateRamp_.to(0.0f, static_cast<int>(0.003f * sampleRate_));
}

void ModalPercussionVoice::renderAdd(float* out, int n) {
    if (!active_) return;

    // Glide the pitch toward its resting value over ~80 ms (block-rate update).
    if (glide_ > 0.0001f) {
        const float coef = std::exp(-static_cast<float>(n) / (0.08f * sampleRate_));
        glideEnv_ = 1.0f + (glideEnv_ - 1.0f) * coef;
        updateCoeffs(glideEnv_);
    }

    for (int k = 0; k < n; ++k) {
        // Membrane transient excitation.
        float e = 0.0f;
        if (transPos_ < static_cast<int>(transLen_)) {
            const float env = std::exp(-static_cast<float>(transPos_) /
                                       (transDecay_ * static_cast<float>(sampleRate_)));
            e = rng_.nextBipolar() * env * transAmp_;
            ++transPos_;
        }

        float s = 0.0f;
        for (int i = 0; i < numModes_; ++i) {
            Mode& m = modes_[i];
            const float y = m.a1 * m.y1 - m.a2 * m.y2 + e * m.gain;
            m.y2 = m.y1;
            m.y1 = flushDenorm(y);
            s += y * m.amp;
        }
        // Add part of the raw transient (slap) for attack definition.
        s += e * 0.5f;

        if (released) s *= 0.9996f; // gentle hand-damp while held

        const float g = gateRamp_.next() * level_;
        const float o = s * g * 0.6f;
        out[k] += o;

        const float a = std::fabs(o);
        ampFollow_ = (a > ampFollow_) ? a : ampFollow_ * 0.9995f;
    }

    if (gateRamp_.done() && gateRamp_.value <= 0.0001f) active_ = false;
    if (ampFollow_ < 1.0e-4f && transPos_ >= static_cast<int>(transLen_)) active_ = false;
}

} // namespace rubab
