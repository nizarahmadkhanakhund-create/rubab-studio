#pragma once
#include "../engine/Voice.h"

namespace rubab {

// Modal percussion: a bank of independently-tuned, independently-decaying
// two-pole resonators (the drum's modes) rung by a short membrane transient.
// Stroke articulations (open/closed/rim/bass) reshape which modes sound and how
// long they ring — enough to render tabla bols (na, tin, dha, ge), dhol, cajon,
// frame drum and hand percussion from one data-driven model. Supports the
// downward pitch glide that gives tabla its characteristic "dha" inflection.
class ModalPercussionVoice : public Voice {
public:
    void prepare(double sampleRate, int maxBlock) override;
    void noteOn(const InstrumentParams& ip, float midiNote, float velocity,
                Articulation art, float artParam, Xorshift& rng) override;
    void noteOff() override;
    void renderAdd(float* out, int n) override;
    bool isActive() const override { return active_; }
    void kill() override;

private:
    struct Mode {
        float y1 = 0, y2 = 0;
        float a1 = 0, a2 = 0;   // resonator coefficients
        float w  = 0;            // radian freq (for glide recompute)
        float r  = 0;            // pole radius (decay)
        float amp = 0;
        float gain = 0;          // excitation coupling
    };

    void updateCoeffs(float glideMul);

    InstrumentParams ip_;
    Mode modes_[kMaxModes];
    int  numModes_ = 4;

    // Membrane transient (the stick/finger impact).
    float transLen_ = 0.0f;
    int   transPos_ = 0;
    float transDecay_ = 0.02f;
    float transAmp_ = 0.3f;
    Xorshift rng_;

    // Pitch glide (tabla).
    float glide_ = 0.0f;         // amount
    float glideEnv_ = 1.0f;      // current multiplier → 1.0

    Ramp  gateRamp_;
    float ampFollow_ = 0.0f;
    float level_ = 1.0f;
};

} // namespace rubab
