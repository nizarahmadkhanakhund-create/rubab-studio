#include "SympatheticBank.h"
#include <cmath>

namespace rubab {

void SympatheticBank::prepare(double sampleRate) {
    sr_ = sampleRate;
    strings_.clear();
}

void SympatheticBank::configure(int count, float baseHz, float decaySec, float drive) {
    count = std::max(0, std::min(count, 16));
    drive_ = drive;
    activeCount_ = count;
    strings_.assign(count, Str());

    // Tune to a typical sympathetic (tarab) layout: a chromatic-ish ladder
    // spanning just over an octave around the base pitch.
    static const float kScale[16] = {
        1.0f, 1.0595f, 1.1225f, 1.1892f, 1.2599f, 1.3348f, 1.4142f, 1.4983f,
        1.5874f, 1.6818f, 1.7818f, 1.8877f, 2.0f, 2.1189f, 2.2449f, 2.3784f
    };
    for (int i = 0; i < count; ++i) {
        Str& s = strings_[i];
        s.dl.prepare(4096);
        s.dl.clear();
        const float f = baseHz * kScale[i % 16];
        s.delay = sr_ / std::max(f, 20.0f);
        const float roundTrip = s.delay / static_cast<float>(sr_);
        s.gain = clampf(std::pow(10.0f, -3.0f * roundTrip / std::max(decaySec, 0.5f)), 0.0f, 0.99996f);
        s.damp = 0.15f;
        s.lp = 0.0f;
    }
}

void SympatheticBank::reset() {
    for (auto& s : strings_) { s.dl.clear(); s.lp = 0.0f; }
}

float SympatheticBank::process(float in) {
    if (!enabled_ || activeCount_ <= 0) return 0.0f;
    float sum = 0.0f;
    const float exc = in * drive_;
    const int n = std::min(activeCount_, (int)strings_.size());
    for (int i = 0; i < n; ++i) {
        Str& s = strings_[i];
        const float d = s.dl.read(s.delay);
        const float lp = (1.0f - s.damp) * d + s.damp * s.lp;
        s.lp = flushDenorm(lp);
        s.dl.push(lp * s.gain + exc);
        sum += d;
    }
    return sum * (1.0f / std::sqrt((float)n));
}

} // namespace rubab
