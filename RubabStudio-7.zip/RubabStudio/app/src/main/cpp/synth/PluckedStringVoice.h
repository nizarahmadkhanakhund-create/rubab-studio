#pragma once
#include "../engine/Voice.h"
#include "../util/DelayLine.h"
#include "../fx/Biquad.h"

namespace rubab {

// One physical string (waveguide). Multiple of these form a course (unison /
// 12-string) inside a single voice.
struct KsString {
    DelayLine dl;
    float targetDelay = 100.0f;
    float curDelay    = 100.0f;
    float delaySmooth = 0.0f;      // one-pole coefficient for meend glide

    float loopGain = 0.999f;       // from T60
    float loopDamp = 0.3f;         // lowpass coefficient (brightness/damping)
    float lpPrev   = 0.0f;

    // Dispersion allpass cascade (string stiffness → inharmonicity).
    int   dispStages = 2;
    float dispCoef   = 0.0f;
    float apX[8] = {0};
    float apY[8] = {0};

    float buzz = 0.0f;             // jawari bridge nonlinearity
    float detuneRatio = 1.0f;      // course detune
    float panOffset = 0.0f;

    void prepare(int maxLen) { dl.prepare(maxLen); }
    void reset();
    void retune(float freqHz, double sr, bool glide);
    void excite(float* burst, int len);     // inject one wavelength of energy
    inline float step(float extraInput);     // one sample of the loop
};

// Extended Karplus-Strong plucked-string voice: dispersion, dual body
// resonances, jawari buzz, unison courses, meend (microtonal glide),
// tremolo re-excitation, palm mute and natural harmonics. This is the
// flagship engine powering the Acoustic Rubab and the whole plucked family.
class PluckedStringVoice : public Voice {
public:
    void prepare(double sampleRate, int maxBlock) override;
    void noteOn(const InstrumentParams& ip, float midiNote, float velocity,
                Articulation art, float artParam, Xorshift& rng) override;
    void configureString(KsString& s, float loopGain, float damp, int dispStages,
                         float dispCoef, float buzz);
    void noteOff() override;
    void setBend(float semitones) override;
    void setPressure(float pressure) override;
    void renderAdd(float* out, int n) override;
    bool isActive() const override { return active_; }
    void kill() override;

private:
    void buildBurst(float velocity, Articulation art, Xorshift& rng, int& lenOut);

    static constexpr int kMaxBurst = 4096;

    InstrumentParams ip_;
    int   numStrings_ = 1;
    KsString strings_[kMaxUnison];     // horizontal polarization / courses
    KsString polar_[kMaxUnison];       // vertical polarization partners
    bool  polActive_ = false;
    float polLevel_ = 0.0f;
    float polDetuneRatio_ = 1.0f;

    float baseMidi_ = 60.0f;
    float baseFreq_ = 261.63f;
    float humanDetune_ = 1.0f;         // per-note micro-detune ratio

    // 3-mode body resonator + air (shared by the voice's strings).
    Biquad body1_, body2_, body3_;
    bool   body3Active_ = false;
    float  bodyMix_ = 0.25f;

    // Output envelope for click-free start/stop and auto-deactivation.
    Ramp   gateRamp_;
    float  ampFollow_ = 0.0f;

    // Articulation state.
    Articulation art_ = ART_NORMAL;
    bool   muted_ = false;
    int    tremoloPeriod_ = 0;   // samples between re-excites (0 = off)
    int    tremoloCounter_ = 0;
    float  tremoloVel_ = 0.6f;

    // Pressure → vibrato (expressive aftertouch).
    float  vibPhase_ = 0.0f;

    float  burst_[kMaxBurst];
    int    burstLen_ = 0;
    int    burstPos_ = 0;
    Xorshift* rng_ = nullptr;
    Xorshift localRng_;
};

} // namespace rubab
