#pragma once
#include "../engine/Voice.h"
#include "../util/DelayLine.h"
#include "../fx/Biquad.h"

namespace rubab {

// Digital-waveguide bowed string. Energy is sustained by a saturating
// stick-slip friction nonlinearity at the bow point, giving the characteristic
// Helmholtz motion of violin / viola / cello. Supports continuous vibrato,
// bow-pressure (aftertouch) and legato pitch glide.
class BowedStringVoice : public Voice {
public:
    void prepare(double sampleRate, int maxBlock) override;
    void noteOn(const InstrumentParams& ip, float midiNote, float velocity,
                Articulation art, float artParam, Xorshift& rng) override;
    void noteOff() override;
    void renderAdd(float* out, int n) override;
    bool isActive() const override { return active_; }
    void kill() override;

private:
    InstrumentParams ip_;
    DelayLine dl_;
    float curDelay_ = 200.0f;
    float baseFreq_ = 220.0f;
    float loopGain_ = 0.996f;
    float loopDamp_ = 0.25f;
    float lpPrev_ = 0.0f;

    Ramp  bowVel_;          // attack / release of bow speed
    float bowForce_ = 0.3f;
    float bowNoise_ = 0.02f;

    Biquad body1_, body2_;
    float  bodyMix_ = 0.3f;

    Ramp   gateRamp_;
    float  ampFollow_ = 0.0f;
    float  vibPhase_ = 0.0f;
    float  vibRate_ = 5.5f;
    float  vibDepth_ = 0.15f;
    Xorshift rng_;
};

} // namespace rubab
