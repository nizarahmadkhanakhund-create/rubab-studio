#pragma once
#include <vector>
#include "../util/DelayLine.h"
#include "../util/DspMath.h"

namespace rubab {

// A bank of lightly-damped Karplus-Strong resonators tuned to a drone scale.
// It is driven by whatever is currently being played and rings sympathetically
// — the unmistakable halo behind a sitar or rubab. Owned by the engine (shared
// across all voices of a sympathetic instrument), which is both cheaper and
// more physically accurate than per-voice sympathetic strings.
class SympatheticBank {
public:
    void prepare(double sampleRate);
    // Build the full set of resonators once (off the audio thread).
    void configure(int count, float baseHz, float decaySec, float drive);
    // Realtime-safe runtime controls (no allocation): called from audio thread.
    void setRuntime(int activeCount, float drive) {
        activeCount_ = (activeCount < 0) ? 0 : (activeCount > (int)strings_.size() ? (int)strings_.size() : activeCount);
        drive_ = drive;
    }
    void setEnabled(bool e) { enabled_ = e; }
    bool enabled() const { return enabled_; }

    // Process the mono mix in place-ish: returns the summed sympathetic signal
    // to be added back to the bus. `in` is the dry mono excitation.
    float process(float in);
    void reset();

private:
    struct Str {
        DelayLine dl;
        float delay = 100.0f;
        float gain = 0.999f;
        float damp = 0.2f;
        float lp = 0.0f;
    };
    double sr_ = 48000.0;
    std::vector<Str> strings_;
    float drive_ = 0.05f;
    int   activeCount_ = 0;
    bool  enabled_ = false;
};

} // namespace rubab
