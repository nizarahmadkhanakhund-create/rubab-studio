package com.epic.rubab

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import com.epic.rubab.engine.AudioController
import com.epic.rubab.engine.MidiController
import com.epic.rubab.ui.AppRoot
import com.epic.rubab.ui.PlayViewModel
import com.epic.rubab.ui.theme.RubabTheme

class MainActivity : ComponentActivity() {

    private val vm: PlayViewModel by viewModels()
    private var midi: MidiController? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        // Start the low-latency engine; push settings once it's up.
        AudioController.start { ok ->
            if (ok) {
                vm.onEngineReady()
                midi = MidiController(applicationContext) { vm.settings.value.instrumentId }.also {
                    runCatching { it.start() }
                }
            }
        }

        setContent {
            val settings by vm.settings.collectAsState()
            RubabTheme(theme = settings.theme) {
                AppRoot(vm)
            }
        }
    }

    override fun onResume() {
        super.onResume()
        if (!AudioController.ready) AudioController.start { ok -> if (ok) vm.onEngineReady() }
    }

    override fun onDestroy() {
        super.onDestroy()
        if (isFinishing) {
            midi?.stop()
            AudioController.allNotesOff()
            AudioController.stop()
        }
    }
}
