package com.epic.rubab.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.input.pointer.*
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.unit.IntSize
import com.epic.rubab.engine.Articulation
import com.epic.rubab.features.assist.MusicTheory
import com.epic.rubab.ui.PlayViewModel

private val whiteSemis = intArrayOf(0, 2, 4, 5, 7, 9, 11)
private val blackSemis = intArrayOf(1, 3, 6, 8, 10)

private data class Key(val midi: Int, val rect: Rect, val black: Boolean)

/**
 * Multi-touch piano keyboard. Velocity comes from where the key is struck
 * (lower = louder), sliding between keys re-triggers (glissando), and keys in
 * the active scale are highlighted when scale-assist is on.
 */
@Composable
fun Keyboard(
    vm: PlayViewModel,
    lowNote: Int,
    octaves: Int,
    scaleTonic: Int,
    scaleIndex: Int,
    scaleAssist: Boolean,
    accent: Color,
    modifier: Modifier = Modifier
) {
    val active = remember { mutableStateMapOf<PointerId, Pair<Int, Int>>() } // ptr -> (touchId, midi)
    var sizePx by remember { mutableStateOf(IntSize.Zero) }

    val keys by remember(sizePx, lowNote, octaves) {
        derivedStateOf {
            if (sizePx.width > 0) buildKeys(lowNote, octaves, sizePx.width.toFloat(), sizePx.height.toFloat())
            else emptyList()
        }
    }
    val scale = MusicTheory.scales[scaleIndex.coerceIn(0, MusicTheory.scales.lastIndex)]

    Canvas(
        modifier = modifier
            .fillMaxSize()
            .onSizeChanged { sizePx = it }
            .pointerInput(lowNote, octaves) {
                awaitPointerEventScope {
                    while (true) {
                        val event = awaitPointerEvent()
                        for (c in event.changes) {
                            when {
                                c.pressed && !active.containsKey(c.id) -> {
                                    val k = hitTest(keys, c.position) ?: continue
                                    val vel = velocityFor(k, c.position)
                                    val tid = vm.noteOn(k.midi.toFloat(), vel, Articulation.PLUCK)
                                    active[c.id] = tid to k.midi
                                    c.consume()
                                }
                                c.pressed && active.containsKey(c.id) -> {
                                    // Glissando: slid onto a different key.
                                    val k = hitTest(keys, c.position)
                                    val cur = active[c.id]
                                    if (k != null && cur != null && k.midi != cur.second) {
                                        vm.noteOff(cur.first)
                                        val vel = velocityFor(k, c.position)
                                        val tid = vm.noteOn(k.midi.toFloat(), vel, Articulation.HAMMER)
                                        active[c.id] = tid to k.midi
                                    }
                                    c.consume()
                                }
                                !c.pressed && active.containsKey(c.id) -> {
                                    active.remove(c.id)?.let { vm.noteOff(it.first) }
                                    c.consume()
                                }
                            }
                        }
                    }
                }
            }
    ) {
        val pressedMidis = active.values.map { it.second }.toSet()
        drawKeyboard(keys, pressedMidis, scaleTonic, scale, scaleAssist, accent)
    }
}

private fun buildKeys(low: Int, octaves: Int, w: Float, h: Float): List<Key> {
    val whiteCount = octaves * 7 + 1
    val whiteW = w / whiteCount
    val blackH = h * 0.6f
    val list = ArrayList<Key>()
    // White keys, aligned to the C at or below `low`.
    val startC = low - (low % 12)
    var wi = 0
    var idx = 0
    while (wi < whiteCount) {
        val octave = idx / 7
        val deg = idx % 7
        val m = startC + octave * 12 + whiteSemis[deg]
        val left = wi * whiteW
        list.add(Key(m, Rect(left, 0f, left + whiteW, h), false))
        wi++; idx++
    }
    // Black keys overlaid
    for (w2 in 0 until whiteCount) {
        val octave = w2 / 7
        val deg = w2 % 7
        // Black key sits after white degrees 0,1,3,4,5 (C,D,F,G,A)
        if (deg == 0 || deg == 1 || deg == 3 || deg == 4 || deg == 5) {
            val semi = whiteSemis[deg] + 1
            val m = startC + octave * 12 + semi
            val center = (w2 + 1) * whiteW
            val bw = whiteW * 0.62f
            list.add(Key(m, Rect(center - bw / 2, 0f, center + bw / 2, blackH), true))
        }
    }
    return list
}

private fun hitTest(keys: List<Key>, p: Offset): Key? {
    // Black keys first (drawn on top).
    keys.firstOrNull { it.black && it.rect.contains(p) }?.let { return it }
    return keys.firstOrNull { !it.black && it.rect.contains(p) }
}

private fun velocityFor(k: Key, p: Offset): Float {
    val local = (p.y - k.rect.top) / (k.rect.height).coerceAtLeast(1f)
    return (0.45f + 0.55f * local).coerceIn(0.1f, 1f)
}

private fun DrawScope.drawKeyboard(
    keys: List<Key>, pressed: Set<Int>, tonic: Int,
    scale: MusicTheory.Scale, assist: Boolean, accent: Color
) {
    // White keys
    for (k in keys.filter { !it.black }) {
        val inScale = MusicTheory.isInScale(k.midi, tonic, scale)
        val base = when {
            pressed.contains(k.midi) -> accent
            assist && inScale -> accent.copy(alpha = 0.18f)
            else -> Color(0xFFF3ECE0)
        }
        drawRect(base, topLeft = Offset(k.rect.left + 1.5f, k.rect.top),
            size = androidx.compose.ui.geometry.Size(k.rect.width - 3f, k.rect.height))
        drawRect(Color(0x33000000), topLeft = Offset(k.rect.left, k.rect.top),
            size = androidx.compose.ui.geometry.Size(1.5f, k.rect.height))
    }
    // Black keys
    for (k in keys.filter { it.black }) {
        val col = if (pressed.contains(k.midi)) accent else Color(0xFF221B14)
        drawRect(col, topLeft = Offset(k.rect.left, k.rect.top),
            size = androidx.compose.ui.geometry.Size(k.rect.width, k.rect.height))
    }
}
