package com.epic.rubab.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.epic.rubab.ui.PlayViewModel

@Composable
fun LooperScreen(vm: PlayViewModel) {
    var recording by remember { mutableStateOf(vm.looper.isRecording) }
    var playing by remember { mutableStateOf(vm.looper.isPlaying) }
    var lengthSec by remember { mutableStateOf(vm.looper.loopLengthMs / 1000f) }
    var version by remember { mutableStateOf(0) } // force track list refresh

    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text("Multi-Track Looper", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        Text("Gesture-based layers — each repeat is re-synthesised live, so loops stay crisp.",
            style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Spacer(Modifier.height(16.dp))

        Text("Loop length: ${"%.1f".format(lengthSec)} s", style = MaterialTheme.typography.labelSmall)
        Slider(value = lengthSec, onValueChange = { lengthSec = it; vm.looper.setLoopLength((it * 1000).toLong()) },
            valueRange = 1f..16f)

        Spacer(Modifier.height(12.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Button(onClick = {
                if (recording) { vm.looperStopRecording(); recording = false; version++ }
                else { vm.looperStartRecording(); recording = true; playing = true }
            }, colors = ButtonDefaults.buttonColors(
                containerColor = if (recording) Color(0xFFE5484D) else MaterialTheme.colorScheme.primary
            )) {
                Icon(Icons.Filled.FiberManualRecord, null); Spacer(Modifier.width(6.dp))
                Text(if (recording) "Stop Rec" else "Record Layer")
            }
            FilledTonalButton(onClick = { vm.looperTogglePlay(); playing = vm.looper.isPlaying }) {
                Icon(if (playing) Icons.Filled.Stop else Icons.Filled.PlayArrow, null)
                Spacer(Modifier.width(6.dp)); Text(if (playing) "Stop" else "Play")
            }
            FilledTonalButton(onClick = { vm.looperClear(); playing = false; recording = false; version++ }) {
                Icon(Icons.Filled.DeleteSweep, null); Spacer(Modifier.width(6.dp)); Text("Clear")
            }
        }

        Spacer(Modifier.height(10.dp))
        Surface(color = MaterialTheme.colorScheme.surfaceVariant, shape = MaterialTheme.shapes.medium) {
            Text("Tip: tap Record Layer, switch to the Play tab, perform your part — it captures while you play and loops back here.",
                Modifier.padding(12.dp), style = MaterialTheme.typography.labelSmall)
        }

        Spacer(Modifier.height(16.dp))
        Text("Tracks", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
        key(version) {
            val tracks = vm.looper.tracks
            if (tracks.isEmpty()) {
                Text("No layers yet.", Modifier.padding(top = 8.dp),
                    color = MaterialTheme.colorScheme.onSurfaceVariant)
            } else {
                LazyColumn {
                    itemsIndexed(tracks) { i, track ->
                        var muted by remember { mutableStateOf(track.muted) }
                        Row(Modifier.fillMaxWidth().padding(vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically) {
                            Text("Layer ${i + 1}", Modifier.weight(1f),
                                style = MaterialTheme.typography.titleMedium)
                            Text("${track.events.size / 2} notes",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Spacer(Modifier.width(12.dp))
                            Text("Mute", style = MaterialTheme.typography.labelSmall)
                            Switch(checked = muted, onCheckedChange = { muted = it; track.muted = it })
                        }
                        Divider()
                    }
                }
            }
        }
    }
}
