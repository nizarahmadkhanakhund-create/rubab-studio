package com.epic.rubab.features.looper

import com.epic.rubab.engine.AudioController
import kotlinx.coroutines.*
import java.util.concurrent.CopyOnWriteArrayList

/** A single recorded note event, timestamped relative to the loop start. */
data class LoopEvent(
    val timeMs: Long,
    val isNoteOn: Boolean,
    val localId: Int,          // identifies the note within the track
    val instrumentId: Int,
    val midi: Float,
    val velocity: Float,
    val articulation: Int
)

/** One loop track: an ordered list of events plus mute/level state. */
class LoopTrack(val index: Int) {
    val events = CopyOnWriteArrayList<LoopEvent>()
    @Volatile var muted: Boolean = false
    val isEmpty get() = events.isEmpty()
    fun clear() = events.clear()
}

/**
 * Event-based multi-track looper. Note events are captured with timestamps and
 * replayed in sync with a fixed-length loop, layering unlimited tracks. Because
 * it records gestures (not audio), every repeat is re-synthesised live — so
 * loops stay crisp and react to later effect changes.
 */
class Looper(private val scope: CoroutineScope) {

    val tracks = CopyOnWriteArrayList<LoopTrack>()
    @Volatile var loopLengthMs: Long = 4000L
    @Volatile var isPlaying = false
        private set
    @Volatile var isRecording = false
        private set

    private var recordTrack: LoopTrack? = null
    private var recordStart = 0L
    private var playJob: Job? = null
    private var localIdCounter = 0

    fun setLoopLength(ms: Long) { loopLengthMs = ms.coerceIn(500L, 60000L) }

    fun startRecording(instrumentDefault: Int) {
        val t = LoopTrack(tracks.size)
        tracks.add(t)
        recordTrack = t
        recordStart = System.currentTimeMillis()
        isRecording = true
        if (!isPlaying) startPlayback()
    }

    fun stopRecording() {
        isRecording = false
        recordTrack = null
    }

    /** Called by the ViewModel for every user note while recording. */
    fun captureNoteOn(instrumentId: Int, midi: Float, velocity: Float, articulation: Int): Int {
        val id = localIdCounter++
        recordTrack?.let {
            val t = (System.currentTimeMillis() - recordStart) % loopLengthMs
            it.events.add(LoopEvent(t, true, id, instrumentId, midi, velocity, articulation))
        }
        return id
    }

    fun captureNoteOff(localId: Int, instrumentId: Int, midi: Float) {
        recordTrack?.let {
            val t = (System.currentTimeMillis() - recordStart) % loopLengthMs
            it.events.add(LoopEvent(t, false, localId, instrumentId, midi, 0f, 0))
        }
    }

    fun startPlayback() {
        if (isPlaying) return
        isPlaying = true
        playJob = scope.launch(Dispatchers.Default) {
            while (isActive && isPlaying) {
                val loopStart = System.currentTimeMillis()
                // Gather and sort events across all (unmuted) tracks for this cycle.
                val live = HashMap<Int, Int>() // localId -> engine touchId
                while (isActive && isPlaying) {
                    val now = System.currentTimeMillis() - loopStart
                    if (now >= loopLengthMs) break
                    for (track in tracks) {
                        if (track.muted || track === recordTrack) continue
                        for (e in track.events) {
                            // Fire events whose time has just passed in this tick window.
                            if (e.timeMs <= now && e.timeMs > now - 16) {
                                val key = track.index * 100000 + e.localId
                                if (e.isNoteOn) {
                                    val tid = AudioController.newTouchId()
                                    live[key] = tid
                                    AudioController.noteOn(tid, e.instrumentId, e.midi, e.velocity, e.articulation)
                                } else {
                                    live.remove(key)?.let { AudioController.noteOff(it) }
                                }
                            }
                        }
                    }
                    delay(8)
                }
                // Release any hanging notes at loop boundary.
                live.values.forEach { AudioController.noteOff(it) }
            }
        }
    }

    fun stopPlayback() {
        isPlaying = false
        playJob?.cancel()
        playJob = null
        AudioController.allNotesOff()
    }

    fun clearAll() {
        stopPlayback()
        tracks.clear()
    }

    fun removeTrack(index: Int) {
        tracks.removeAll { it.index == index }
    }
}
