package com.epic.rubab.engine

import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.concurrent.atomic.AtomicInteger

/**
 * App-level owner of the native engine. Handles start/stop with the activity
 * lifecycle and exposes a small, UI-friendly API. All calls are cheap and
 * non-blocking: the native side queues events for the audio thread.
 */
object AudioController {

    @Volatile var ready: Boolean = false
        private set

    private val scope = CoroutineScope(Dispatchers.Default)
    private val touchCounter = AtomicInteger(1)

    /** Starts the engine off the main thread. Safe to call repeatedly. */
    fun start(onReady: (Boolean) -> Unit = {}) {
        scope.launch {
            val ok = withContext(Dispatchers.Default) { NativeBridge.init() }
            ready = ok
            withContext(Dispatchers.Main) { onReady(ok) }
        }
    }

    fun stop() {
        if (NativeBridge.initialized) NativeBridge.destroy()
        ready = false
    }

    /** Allocates a unique touch id for a new press/gesture. */
    fun newTouchId(): Int = touchCounter.getAndIncrement()

    // ---- Note API ----
    fun noteOn(touchId: Int, instrumentId: Int, midiNote: Float, velocity: Float,
               articulation: Int = Articulation.NORMAL, artParam: Float = 0f) {
        if (ready) NativeBridge.nativeNoteOn(touchId, instrumentId, midiNote, velocity, articulation, artParam)
    }

    fun noteOff(touchId: Int) { if (ready) NativeBridge.nativeNoteOff(touchId) }
    fun bend(touchId: Int, semitones: Float) { if (ready) NativeBridge.nativeBend(touchId, semitones) }
    fun pressure(touchId: Int, p: Float) { if (ready) NativeBridge.nativePressure(touchId, p) }
    fun allNotesOff() { if (ready) NativeBridge.nativeAllNotesOff() }

    fun activeVoices(): Int = if (ready) NativeBridge.nativeActiveVoices() else 0
    fun sampleRate(): Double = if (ready) NativeBridge.nativeSampleRate() else 0.0

    // ---- FX passthrough ----
    fun setMasterGain(g: Float) = NativeBridge.nativeSetMasterGain(g)
    fun setReverbSpace(space: Int) = NativeBridge.nativeSetReverbSpace(space)
    fun setReverbMix(mix: Float) = NativeBridge.nativeSetReverbMix(mix)
    fun setAlgoReverb(room: Float, damp: Float, mix: Float) = NativeBridge.nativeSetAlgoReverb(room, damp, mix)
    fun setDelay(timeMs: Float, fb: Float, mix: Float) = NativeBridge.nativeSetDelay(timeMs, fb, mix)
    fun setModulation(rate: Float, depth: Float, mix: Float) = NativeBridge.nativeSetModulation(rate, depth, mix)
    fun setEq(low: Float, mid: Float, high: Float) = NativeBridge.nativeSetEq(low, mid, high)
    fun setSaturation(drive: Float, mix: Float) = NativeBridge.nativeSetSaturation(drive, mix)
    fun setSpatial(width: Float, depth: Float) = NativeBridge.nativeSetSpatial(width, depth)
    fun setMetronome(on: Boolean, bpm: Float, beats: Int) = NativeBridge.nativeSetMetronome(on, bpm, beats)

    // ---- Recording ----
    fun recordArm() = NativeBridge.nativeRecordArm()
    fun recordDisarm() = NativeBridge.nativeRecordDisarm()
    fun isRecording(): Boolean = NativeBridge.nativeIsRecording()
    fun exportWav(path: String): Int = NativeBridge.nativeExportWav(path)
}
