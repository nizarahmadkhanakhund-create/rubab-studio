package com.epic.rubab.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.*
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.unit.IntSize
import com.epic.rubab.engine.Articulation
import com.epic.rubab.features.assist.MusicTheory
import com.epic.rubab.innovation.ArticulationDetector
import com.epic.rubab.ui.PlayViewModel
import kotlin.math.abs

private class FretTouch(
    val touchId: Int,
    val startX: Float,
    val startY: Float,
    val midi: Int,
    var lastBend: Float = 0f
)

/**
 * Fretboard surface with expressive gestures: tap a position to sound a note,
 * drag horizontally for meend (microtonal bend), drag vertically for vibrato /
 * pressure. Multiple fingers are independent, so chords and drones hold while
 * the melody string bends — the heart of Rubab and sitar playing.
 */
@Composable
fun Fretboard(
    vm: PlayViewModel,
    lowNote: Int,
    numStrings: Int,
    frets: Int,
    supportsBend: Boolean,
    scaleTonic: Int,
    scaleIndex: Int,
    scaleAssist: Boolean,
    accent: Color,
    modifier: Modifier = Modifier
) {
    val touches = remember { mutableStateMapOf<PointerId, FretTouch>() }
    var sizePx by remember { mutableStateOf(IntSize.Zero) }
    val scale = MusicTheory.scales[scaleIndex.coerceIn(0, MusicTheory.scales.lastIndex)]

    // Open string notes tuned in fourths (5 semitones), highest string on top.
    val openNotes = remember(lowNote, numStrings) {
        IntArray(numStrings) { s -> lowNote + (numStrings - 1 - s) * 5 }
    }

    Canvas(
        modifier = modifier
            .fillMaxSize()
            .onSizeChanged { sizePx = it }
            .pointerInput(lowNote, numStrings, frets, supportsBend) {
                awaitPointerEventScope {
                    while (true) {
                        val event = awaitPointerEvent()
                        val w = sizePx.width.toFloat().coerceAtLeast(1f)
                        val h = sizePx.height.toFloat().coerceAtLeast(1f)
                        val rowH = h / numStrings
                        val cellW = w / frets
                        for (c in event.changes) {
                            when {
                                c.pressed && !touches.containsKey(c.id) -> {
                                    val s = (c.position.y / rowH).toInt().coerceIn(0, numStrings - 1)
                                    val f = (c.position.x / cellW).toInt().coerceIn(0, frets - 1)
                                    val midi = openNotes[s] + f
                                    val vel = (0.55f + (1f - c.position.y % rowH / rowH) * 0.4f).coerceIn(0.15f, 1f)
                                    val tid = vm.noteOn(midi.toFloat(), vel, Articulation.PLUCK)
                                    touches[c.id] = FretTouch(tid, c.position.x, c.position.y, midi)
                                    c.consume()
                                }
                                c.pressed && touches.containsKey(c.id) -> {
                                    val t = touches[c.id]!!
                                    if (supportsBend) {
                                        val dx = c.position.x - t.startX
                                        val bend = ArticulationDetector.dragToBend(dx, cellW)
                                        if (abs(bend - t.lastBend) > 0.01f) {
                                            vm.bend(t.touchId, bend); t.lastBend = bend
                                        }
                                        val dy = c.position.y - t.startY
                                        vm.pressure(t.touchId, ArticulationDetector.dragToPressure(dy, rowH))
                                    }
                                    c.consume()
                                }
                                !c.pressed && touches.containsKey(c.id) -> {
                                    touches.remove(c.id)?.let { vm.noteOff(it.touchId) }
                                    c.consume()
                                }
                            }
                        }
                    }
                }
            }
    ) {
        drawFretboard(numStrings, frets, openNotes, touches.values.map { it.midi }.toSet(),
            scaleTonic, scale, scaleAssist, accent)
    }
}

private fun androidx.compose.ui.graphics.drawscope.DrawScope.drawFretboard(
    numStrings: Int, frets: Int, openNotes: IntArray, pressed: Set<Int>,
    tonic: Int, scale: MusicTheory.Scale, assist: Boolean, accent: Color
) {
    val w = size.width; val h = size.height
    val rowH = h / numStrings
    val cellW = w / frets
    // Fretboard wood
    drawRect(Color(0xFF2A1C10))

    // Fret lines
    for (f in 0..frets) {
        val x = f * cellW
        drawLine(Color(0xFF6B5033), Offset(x, 0f), Offset(x, h), strokeWidth = if (f == 0) 6f else 2f)
    }
    // Fret position markers
    val markers = intArrayOf(3, 5, 7, 9, 12)
    for (m in markers) if (m < frets) {
        drawCircle(Color(0x33FFFFFF), radius = rowH * 0.12f,
            center = Offset((m + 0.5f) * cellW, h / 2))
    }

    // Strings + note cells
    for (s in 0 until numStrings) {
        val y = (s + 0.5f) * rowH
        // scale highlights
        for (f in 0 until frets) {
            val midi = openNotes[s] + f
            val inScale = MusicTheory.isInScale(midi, tonic, scale)
            if (pressed.contains(midi)) {
                drawCircle(accent, radius = rowH * 0.3f, center = Offset((f + 0.5f) * cellW, y))
            } else if (assist && inScale) {
                drawCircle(accent.copy(alpha = 0.22f), radius = rowH * 0.22f, center = Offset((f + 0.5f) * cellW, y))
            }
        }
        // String line (thicker for lower strings)
        val thickness = 1.5f + (s.toFloat() / numStrings) * 4f
        drawLine(Color(0xFFCDB68A), Offset(0f, y), Offset(w, y), strokeWidth = thickness)
    }
}
