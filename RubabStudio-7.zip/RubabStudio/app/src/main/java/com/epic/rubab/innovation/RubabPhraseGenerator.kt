package com.epic.rubab.innovation

import com.epic.rubab.engine.Articulation
import com.epic.rubab.engine.AudioController
import com.epic.rubab.features.assist.MusicTheory
import kotlinx.coroutines.*
import kotlin.random.Random

/** A generated note with absolute timing (ms from phrase start). */
data class PhraseNote(
    val midi: Int,
    val startMs: Long,
    val durMs: Long,
    val velocity: Float,
    val articulation: Int = Articulation.PLUCK
)

/**
 * Fully on-device Markov melody generator tuned for the Rubab idiom. A
 * weighted transition model over scale degrees favours stepwise motion,
 * characteristic returns to the tonic (Sa) and the occasional expressive leap
 * with a meend (bend). Also produces a drone/accompaniment so the player can
 * practise over a living backing — no network, no samples.
 */
class RubabPhraseGenerator(private val seed: Long = System.nanoTime()) {

    private val rng = Random(seed)

    // Transition weights between scale-degree indices (0..6). Row = from degree.
    // Hand-tuned to sound idiomatic rather than random-walk.
    private val transitions = arrayOf(
        //   to:  Sa   Re   Ga   Ma   Pa   Dha  Ni
        /*Sa */ floatArrayOf(2f,  5f,  3f,  1f,  3f,  1f,  1f),
        /*Re */ floatArrayOf(5f,  1f,  5f,  2f,  2f,  1f,  1f),
        /*Ga */ floatArrayOf(3f,  5f,  1f,  4f,  3f,  1f,  1f),
        /*Ma */ floatArrayOf(2f,  2f,  5f,  1f,  5f,  2f,  1f),
        /*Pa */ floatArrayOf(4f,  2f,  3f,  4f,  1f,  5f,  2f),
        /*Dha*/ floatArrayOf(2f,  1f,  2f,  2f,  5f,  1f,  4f),
        /*Ni */ floatArrayOf(5f,  1f,  1f,  1f,  3f,  3f,  1f),
    )

    private fun pickNext(from: Int): Int {
        val row = transitions[from.coerceIn(0, 6)]
        val total = row.sum()
        var r = rng.nextFloat() * total
        for (i in row.indices) { r -= row[i]; if (r <= 0f) return i }
        return row.size - 1
    }

    /**
     * Generates a melodic phrase.
     * @param scale the raga/scale providing pitch material
     * @param tonicMidi the Sa (tonic) midi note
     * @param bars number of bars, [beatMs] the beat length
     */
    fun generatePhrase(
        scale: MusicTheory.Scale,
        tonicMidi: Int,
        bars: Int = 4,
        beatMs: Long = 500
    ): List<PhraseNote> {
        val degrees = scale.intervals
        val n = degrees.size.coerceAtMost(7)
        val notes = ArrayList<PhraseNote>()
        var degIdx = 0 // start on Sa
        var t = 0L
        val totalBeats = bars * 4
        var octaveShift = 0

        var beat = 0
        while (beat < totalBeats) {
            // Occasionally sustain (half/whole) or subdivide into two quick notes.
            val roll = rng.nextFloat()
            val subdiv = if (roll < 0.25f) 2 else 1
            val durBeats = if (roll > 0.85f) 2 else 1
            val stepMs = beatMs / subdiv

            repeat(subdiv) {
                val interval = degrees[degIdx % n]
                // Rare octave excursions for an expressive leap.
                if (rng.nextFloat() < 0.08f) octaveShift = if (octaveShift == 0) 12 else 0
                val midi = tonicMidi + interval + octaveShift
                val leap = rng.nextFloat() < 0.15f
                val art = when {
                    leap -> Articulation.HAMMER
                    rng.nextFloat() < 0.12f -> Articulation.TREMOLO
                    else -> Articulation.PLUCK
                }
                val vel = 0.55f + rng.nextFloat() * 0.35f
                notes.add(PhraseNote(midi, t, stepMs * durBeats, vel, art))
                t += stepMs
                degIdx = pickNext(degIdx % n)
            }
            beat += durBeats
        }
        // Resolve to Sa.
        notes.add(PhraseNote(tonicMidi, t, beatMs, 0.7f, Articulation.PLUCK))
        return notes
    }
}

/** Schedules and plays a generated phrase/accompaniment on the engine. */
class PhrasePlayer {
    private var job: Job? = null
    val isPlaying get() = job?.isActive == true

    fun play(
        scope: CoroutineScope,
        instrumentId: Int,
        notes: List<PhraseNote>,
        loop: Boolean = true,
        onNote: (PhraseNote) -> Unit = {}
    ) {
        stop()
        job = scope.launch(Dispatchers.Default) {
            do {
                val start = System.currentTimeMillis()
                for (note in notes) {
                    val wait = note.startMs - (System.currentTimeMillis() - start)
                    if (wait > 0) delay(wait)
                    if (!isActive) return@launch
                    val tid = AudioController.newTouchId()
                    AudioController.noteOn(tid, instrumentId, note.midi.toFloat(), note.velocity, note.articulation)
                    onNote(note)
                    launch {
                        delay(note.durMs)
                        AudioController.noteOff(tid)
                    }
                }
                val totalMs = (notes.lastOrNull()?.let { it.startMs + it.durMs } ?: 0L)
                val elapsed = System.currentTimeMillis() - start
                if (elapsed < totalMs) delay(totalMs - elapsed)
            } while (loop && isActive)
        }
    }

    fun stop() {
        job?.cancel()
        job = null
    }
}
