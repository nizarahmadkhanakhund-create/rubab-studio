package com.epic.rubab.innovation

import kotlin.math.roundToInt

/**
 * Adaptive difficulty engine for learn mode. It observes the player's recent
 * hit accuracy and timing error and nudges difficulty up or down so practice
 * stays in the productive "flow" zone — challenging but achievable. Entirely
 * on-device and stateless beyond a short rolling window.
 */
class AdaptiveDifficulty(
    private val windowSize: Int = 12,
    startLevel: Int = 3
) {
    data class Difficulty(
        val level: Int,          // 1..10
        val tempoBpm: Float,     // suggested practice tempo
        val noteDensity: Float,  // 0..1 notes per beat target
        val timingWindowMs: Long // how tight the timing must be to "hit"
    )

    private data class Attempt(val hit: Boolean, val timingErrorMs: Long)

    private val window = ArrayDeque<Attempt>()
    var level: Int = startLevel.coerceIn(1, 10)
        private set

    /** Records the outcome of one target note. */
    fun record(hit: Boolean, timingErrorMs: Long) {
        window.addLast(Attempt(hit, timingErrorMs))
        while (window.size > windowSize) window.removeFirst()
        if (window.size >= windowSize) reevaluate()
    }

    private fun reevaluate() {
        val hits = window.count { it.hit }
        val accuracy = hits.toFloat() / window.size
        val avgErr = window.filter { it.hit }.map { it.timingErrorMs }.average()
            .let { if (it.isNaN()) 999.0 else it }

        when {
            // Mastering it → step up.
            accuracy >= 0.85f && avgErr < 90 -> { level = (level + 1).coerceAtMost(10); window.clear() }
            // Struggling → step down to rebuild confidence.
            accuracy < 0.5f -> { level = (level - 1).coerceAtLeast(1); window.clear() }
            // Otherwise hold.
        }
    }

    fun current(): Difficulty {
        val l = level
        return Difficulty(
            level = l,
            tempoBpm = 50f + l * 12f,                       // 62 → 170 bpm
            noteDensity = (0.3f + l * 0.07f).coerceAtMost(1f),
            timingWindowMs = (220 - l * 16).toLong().coerceAtLeast(60) // tighter as you improve
        )
    }

    fun accuracy(): Float =
        if (window.isEmpty()) 0f else window.count { it.hit }.toFloat() / window.size

    fun progressPercent(): Int = (level / 10f * 100).roundToInt()
}
