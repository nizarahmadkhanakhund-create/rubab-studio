package com.epic.rubab.ui

import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.navigation.NavDestination.Companion.hierarchy
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.epic.rubab.ui.screens.*

private data class Dest(val route: String, val label: String, val icon: ImageVector)

private val destinations = listOf(
    Dest("play", "Play", Icons.Filled.MusicNote),
    Dest("looper", "Looper", Icons.Filled.Loop),
    Dest("learn", "Learn", Icons.Filled.School),
    Dest("tuner", "Tuner", Icons.Filled.GraphicEq),
    Dest("settings", "Studio", Icons.Filled.Tune),
)

@Composable
fun AppRoot(vm: PlayViewModel) {
    val navController = rememberNavController()
    val backStack by navController.currentBackStackEntryAsState()
    val current = backStack?.destination

    Scaffold(
        bottomBar = {
            NavigationBar {
                destinations.forEach { d ->
                    val selected = current?.hierarchy?.any { it.route == d.route } == true
                    NavigationBarItem(
                        selected = selected,
                        onClick = {
                            navController.navigate(d.route) {
                                popUpTo(navController.graph.findStartDestination().id) { saveState = true }
                                launchSingleTop = true
                                restoreState = true
                            }
                        },
                        icon = { Icon(d.icon, contentDescription = d.label) },
                        label = { Text(d.label) }
                    )
                }
            }
        }
    ) { padding ->
        NavHost(
            navController = navController,
            startDestination = "play",
            modifier = Modifier.padding(padding)
        ) {
            composable("play") { PlayScreen(vm) }
            composable("looper") { LooperScreen(vm) }
            composable("learn") { LearnScreen(vm) }
            composable("tuner") { TunerScreen(vm) }
            composable("settings") { SettingsScreen(vm) }
        }
    }
}
