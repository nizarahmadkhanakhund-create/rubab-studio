package com.epic.rubab.ui.screens

import android.Manifest
import android.content.pm.PackageManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import com.epic.rubab.ui.PlayViewModel
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.rememberCoroutineScope
import kotlin.math.abs

@Composable
fun TunerScreen(vm: PlayViewModel) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var granted by remember {
        mutableStateOf(
            ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO)
                    == PackageManager.PERMISSION_GRANTED
        )
    }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted = it }
    val reading by vm.tuner.reading.collectAsState()

    DisposableEffect(granted) {
        if (granted) startTuner(vm, scope)
        onDispose { vm.tuner.stop() }
    }

    Column(
        Modifier.fillMaxSize().padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text("Chromatic Tuner", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(8.dp))
        Text("Autocorrelation pitch detection, fully on-device",
            style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Spacer(Modifier.height(40.dp))

        if (!granted) {
            Text("Microphone access is needed to tune.", textAlign = androidx.compose.ui.text.style.TextAlign.Center)
            Spacer(Modifier.height(16.dp))
            Button(onClick = { launcher.launch(Manifest.permission.RECORD_AUDIO) }) {
                Text("Enable Microphone")
            }
        } else {
            Text(reading.noteName, style = MaterialTheme.typography.displayLarge,
                fontWeight = FontWeight.Bold,
                color = if (abs(reading.cents) <= 5 && reading.confident)
                    Color(0xFF3CB371) else MaterialTheme.colorScheme.primary)
            Spacer(Modifier.height(8.dp))
            val centsStr = (if (reading.cents >= 0) "+" else "") + reading.cents
            Text(if (reading.confident) "$centsStr cents · ${reading.frequency.toInt()} Hz" else "Listening…",
                style = MaterialTheme.typography.titleMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant)
            Spacer(Modifier.height(32.dp))
            CentsMeter(reading.cents, reading.confident)
        }
    }
}

private fun startTuner(vm: PlayViewModel, scope: CoroutineScope) {
    try { vm.tuner.start(scope) } catch (_: SecurityException) { }
}

@Composable
private fun CentsMeter(cents: Int, confident: Boolean) {
    Canvas(Modifier.fillMaxWidth().height(90.dp)) {
        val w = size.width; val h = size.height
        val cx = w / 2
        // Scale ticks
        for (c in -50..50 step 10) {
            val x = cx + (c / 50f) * (w / 2 - 20)
            drawLine(Color(0x55FFFFFF), Offset(x, h * 0.3f), Offset(x, h * 0.7f),
                strokeWidth = if (c == 0) 4f else 1.5f)
        }
        if (confident) {
            val x = cx + (cents.coerceIn(-50, 50) / 50f) * (w / 2 - 20)
            val col = if (abs(cents) <= 5) Color(0xFF3CB371) else Color(0xFFE0A043)
            drawLine(col, Offset(x, h * 0.15f), Offset(x, h * 0.85f), strokeWidth = 6f)
            drawCircle(col, radius = 10f, center = Offset(x, h * 0.15f))
        }
    }
}
