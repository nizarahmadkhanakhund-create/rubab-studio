package com.epic.rubab.features.tuner

import android.Manifest
import android.annotation.SuppressLint
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import androidx.annotation.RequiresPermission
import com.epic.rubab.features.assist.MusicTheory
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlin.math.abs
import kotlin.math.ln
import kotlin.math.roundToInt

data class TunerReading(
    val frequency: Float = 0f,
    val noteName: String = "—",
    val cents: Int = 0,
    val confident: Boolean = false
)

/**
 * Chromatic tuner using the device microphone. Pitch is estimated with a
 * normalised autocorrelation (robust for plucked/bowed acoustic tone), then
 * mapped to the nearest equal-tempered note and cents deviation. 100% on-device.
 */
class Tuner {
    private val sampleRate = 44100
    private var job: Job? = null
    private val _reading = MutableStateFlow(TunerReading())
    val reading: StateFlow<TunerReading> = _reading

    @SuppressLint("MissingPermission")
    @RequiresPermission(Manifest.permission.RECORD_AUDIO)
    fun start(scope: CoroutineScope) {
        if (job != null) return
        job = scope.launch(Dispatchers.Default) {
            val minBuf = AudioRecord.getMinBufferSize(
                sampleRate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT
            )
            val bufSize = maxOf(minBuf, 4096)
            val recorder = AudioRecord(
                MediaRecorder.AudioSource.MIC, sampleRate,
                AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, bufSize * 2
            )
            if (recorder.state != AudioRecord.STATE_INITIALIZED) return@launch
            val buf = ShortArray(bufSize)
            val samples = FloatArray(bufSize)
            try {
                recorder.startRecording()
                while (isActive) {
                    val read = recorder.read(buf, 0, bufSize)
                    if (read <= 0) continue
                    for (i in 0 until read) samples[i] = buf[i] / 32768f
                    val freq = detectPitch(samples, read)
                    _reading.value = toReading(freq)
                }
            } finally {
                runCatching { recorder.stop() }
                recorder.release()
            }
        }
    }

    fun stop() { job?.cancel(); job = null; _reading.value = TunerReading() }

    /** Normalised autocorrelation pitch detector over 70–1200 Hz. */
    private fun detectPitch(x: FloatArray, n: Int): Float {
        // RMS gate: ignore silence.
        var rms = 0f
        for (i in 0 until n) rms += x[i] * x[i]
        rms = kotlin.math.sqrt(rms / n)
        if (rms < 0.01f) return 0f

        val minLag = sampleRate / 1200
        val maxLag = (sampleRate / 70).coerceAtMost(n - 1)
        var bestLag = -1
        var bestVal = 0f
        var prev = 0f
        var rising = false
        for (lag in minLag..maxLag) {
            var sum = 0f
            var norm = 0f
            for (i in 0 until n - lag) {
                sum += x[i] * x[i + lag]
                norm += x[i + lag] * x[i + lag]
            }
            val nac = if (norm > 1e-6f) sum / kotlin.math.sqrt(norm) else 0f
            // Pick the first strong local peak after the autocorrelation rises.
            if (!rising && nac > prev) rising = true
            if (rising && nac > bestVal) { bestVal = nac; bestLag = lag }
            prev = nac
        }
        if (bestLag <= 0 || bestVal < 0.3f) return 0f
        return sampleRate.toFloat() / bestLag
    }

    private fun toReading(freq: Float): TunerReading {
        if (freq <= 0f) return TunerReading()
        // midi = 69 + 12*log2(f/440)
        val midiF = 69.0 + 12.0 * (ln(freq / 440.0) / ln(2.0))
        val midi = midiF.roundToInt()
        val cents = ((midiF - midi) * 100.0).roundToInt()
        return TunerReading(
            frequency = freq,
            noteName = MusicTheory.noteName(midi),
            cents = cents,
            confident = true
        )
    }
}
