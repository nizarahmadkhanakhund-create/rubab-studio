package com.epic.rubab.ui.screens

import android.widget.Toast
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.clickable
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.epic.rubab.instruments.Family
import com.epic.rubab.instruments.InstrumentInfo
import com.epic.rubab.instruments.Instruments
import com.epic.rubab.instruments.PlaySurface
import com.epic.rubab.ui.PlayViewModel
import com.epic.rubab.ui.components.DrumPads
import com.epic.rubab.ui.components.Fretboard
import com.epic.rubab.ui.components.Keyboard

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PlayScreen(vm: PlayViewModel) {
    val settings by vm.settings.collectAsState()
    val instrument by vm.selectedInstrument.collectAsState()
    val voices by vm.activeVoices.collectAsState()
    val metronome by vm.metronomeOn.collectAsState()
    val recording by vm.recording.collectAsState()
    val context = LocalContext.current

    var showPicker by remember { mutableStateOf(false) }
    val surface = PlaySurface.entries[settings.surface.coerceIn(0, 2)]

    Column(Modifier.fillMaxSize()) {
        // ---- Header ----
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(Modifier.weight(1f).clickable { showPicker = true }) {
                Text("INSTRUMENT", style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant)
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(instrument.name, style = MaterialTheme.typography.headlineSmall,
                        color = instrument.accent, fontWeight = FontWeight.Bold)
                    Icon(Icons.Filled.ArrowDropDown, null, tint = instrument.accent)
                }
            }
            VoiceMeter(voices)
        }

        // ---- Surface selector ----
        Row(Modifier.fillMaxWidth().padding(horizontal = 14.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            PlaySurface.entries.forEach { s ->
                FilterChip(
                    selected = surface == s,
                    onClick = { vm.setSurface(s) },
                    label = { Text(s.name.lowercase().replaceFirstChar { it.uppercase() }) }
                )
            }
        }

        // ---- Play surface ----
        Box(Modifier.weight(1f).fillMaxWidth().padding(10.dp).clip(RoundedCornerShape(18.dp))) {
            when (surface) {
                PlaySurface.KEYBOARD -> Keyboard(
                    vm = vm,
                    lowNote = 12 * (settings.octave + 1),
                    octaves = 2,
                    scaleTonic = settings.tonic,
                    scaleIndex = settings.scaleIndex,
                    scaleAssist = settings.scaleAssist,
                    accent = instrument.accent
                )
                PlaySurface.FRETBOARD -> Fretboard(
                    vm = vm,
                    lowNote = instrument.lowNote,
                    numStrings = numStringsFor(instrument),
                    frets = 13,
                    supportsBend = instrument.supportsBend,
                    scaleTonic = settings.tonic,
                    scaleIndex = settings.scaleIndex,
                    scaleAssist = settings.scaleAssist,
                    accent = instrument.accent
                )
                PlaySurface.PADS -> DrumPads(
                    vm = vm,
                    instrumentId = instrument.id,
                    lowNote = instrument.lowNote,
                    accent = instrument.accent
                )
            }
        }

        // ---- Transport ----
        Column(Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 6.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                if (surface != PlaySurface.PADS) {
                    OctaveStepper(settings.octave, { vm.setOctave(it) })
                    Spacer(Modifier.width(6.dp))
                }
                AssistToggle(settings.scaleAssist) { vm.setScaleAssist(it) }
                Spacer(Modifier.weight(1f))
                IconToggle(Icons.Filled.Timer, metronome, instrument.accent) { vm.toggleMetronome() }
                IconToggle(Icons.Filled.FiberManualRecord, recording, Color(0xFFE5484D)) { vm.toggleRecording() }
                FilledTonalIconButton(onClick = {
                    val f = vm.exportWav()
                    Toast.makeText(context,
                        if (f != null) "Exported ${f.name}" else "Record something first",
                        Toast.LENGTH_SHORT).show()
                }) { Icon(Icons.Filled.Save, "Export WAV") }
                FilledTonalIconButton(onClick = {
                    if (vm.phrasePlayer.isPlaying) vm.stopPhrase() else vm.generateAndPlayPhrase()
                }) { Icon(Icons.Filled.AutoAwesome, "Generate phrase") }
            }
        }
    }

    if (showPicker) {
        InstrumentPicker(
            current = instrument.id,
            onPick = { vm.selectInstrument(it); showPicker = false },
            onDismiss = { showPicker = false }
        )
    }
}

private fun numStringsFor(i: InstrumentInfo): Int = when (i.id) {
    0 -> 3            // rubab melody strings
    9, 12 -> 4        // basses
    else -> 6
}

@Composable
private fun VoiceMeter(voices: Int) {
    Column(horizontalAlignment = Alignment.End) {
        Text("VOICES", style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant)
        Text("$voices", style = MaterialTheme.typography.titleMedium,
            color = MaterialTheme.colorScheme.primary)
    }
}

@Composable
private fun OctaveStepper(octave: Int, onChange: (Int) -> Unit) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        FilledTonalIconButton(onClick = { onChange(octave - 1) }) { Icon(Icons.Filled.Remove, "Lower") }
        Text("Oct $octave", Modifier.padding(horizontal = 4.dp), style = MaterialTheme.typography.labelSmall)
        FilledTonalIconButton(onClick = { onChange(octave + 1) }) { Icon(Icons.Filled.Add, "Higher") }
    }
}

@Composable
private fun AssistToggle(on: Boolean, onToggle: (Boolean) -> Unit) {
    FilterChip(selected = on, onClick = { onToggle(!on) },
        leadingIcon = { Icon(Icons.Filled.Insights, null) },
        label = { Text("Scale") })
}

@Composable
private fun IconToggle(icon: androidx.compose.ui.graphics.vector.ImageVector, on: Boolean, tint: Color, onClick: () -> Unit) {
    FilledTonalIconButton(onClick = onClick,
        colors = IconButtonDefaults.filledTonalIconButtonColors(
            containerColor = if (on) tint.copy(alpha = 0.3f) else MaterialTheme.colorScheme.surfaceVariant
        )) {
        Icon(icon, null, tint = if (on) tint else MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun InstrumentPicker(current: Int, onPick: (Int) -> Unit, onDismiss: () -> Unit) {
    ModalBottomSheet(onDismissRequest = onDismiss) {
        LazyColumn(Modifier.fillMaxWidth().padding(bottom = 24.dp)) {
            Family.entries.forEach { fam ->
                val list = Instruments.byFamily[fam] ?: emptyList()
                if (list.isNotEmpty()) {
                    item {
                        Text(fam.display, Modifier.padding(start = 20.dp, top = 14.dp, bottom = 4.dp),
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    items(list) { inst ->
                        InstrumentRow(inst, inst.id == current) { onPick(inst.id) }
                    }
                }
            }
        }
    }
}

@Composable
private fun InstrumentRow(inst: InstrumentInfo, selected: Boolean, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().clickable { onClick() }.padding(horizontal = 20.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(Modifier.size(28.dp).clip(RoundedCornerShape(8.dp)).then(Modifier)) {
            Surface(color = inst.accent, modifier = Modifier.matchParentSize()) {}
        }
        Spacer(Modifier.width(14.dp))
        Text(inst.name, style = MaterialTheme.typography.titleMedium,
            fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal,
            color = if (selected) inst.accent else MaterialTheme.colorScheme.onSurface)
        if (inst.id == 0) {
            Spacer(Modifier.width(8.dp))
            AssistChipLabel("FLAGSHIP", inst.accent)
        }
    }
}

@Composable
private fun AssistChipLabel(text: String, color: Color) {
    Surface(color = color.copy(alpha = 0.2f), shape = RoundedCornerShape(6.dp)) {
        Text(text, Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
            style = MaterialTheme.typography.labelSmall, color = color)
    }
}
