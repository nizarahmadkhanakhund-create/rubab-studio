package com.epic.rubab.engine

/**
 * Thin Kotlin facade over the native Oboe audio engine (librubabengine.so).
 *
 * Every public method here maps 1:1 to a JNI entry point in native-lib.cpp.
 * The names/signatures are kept by ProGuard (see proguard-rules.pro) because
 * the native side binds to them by symbol.
 */
object NativeBridge {

    init {
        System.loadLibrary("rubabengine")
    }

    @Volatile
    var initialized: Boolean = false
        private set

    fun init(): Boolean {
        initialized = nativeInit()
        return initialized
    }

    fun destroy() {
        nativeDestroy()
        initialized = false
    }

    // --- Lifecycle / info ---
    private external fun nativeInit(): Boolean
    private external fun nativeDestroy()
    external fun nativeSampleRate(): Double
    external fun nativeActiveVoices(): Int
    external fun nativeInstrumentCount(): Int

    // --- Note events ---
    external fun nativeNoteOn(touchId: Int, instrumentId: Int, midiNote: Float,
                              velocity: Float, articulation: Int, artParam: Float)
    external fun nativeNoteOff(touchId: Int)
    external fun nativeBend(touchId: Int, semitones: Float)
    external fun nativePressure(touchId: Int, pressure: Float)
    external fun nativeAllNotesOff()

    // --- FX / parameters ---
    external fun nativeSetMasterGain(g: Float)
    external fun nativeSetReverbSpace(space: Int)
    external fun nativeSetReverbMix(mix: Float)
    external fun nativeSetAlgoReverb(room: Float, damp: Float, mix: Float)
    external fun nativeSetDelay(timeMs: Float, feedback: Float, mix: Float)
    external fun nativeSetModulation(rateHz: Float, depthMs: Float, mix: Float)
    external fun nativeSetEq(lowDb: Float, midDb: Float, highDb: Float)
    external fun nativeSetSaturation(drive: Float, mix: Float)
    external fun nativeSetSpatial(width: Float, depth: Float)
    external fun nativeSetMetronome(on: Boolean, bpm: Float, beats: Int)

    // --- Recording / export ---
    external fun nativeRecordArm()
    external fun nativeRecordDisarm()
    external fun nativeIsRecording(): Boolean
    external fun nativeExportWav(path: String): Int
}

/** Articulation codes — MUST match the native `Articulation` enum order. */
object Articulation {
    const val NORMAL = 0
    const val PLUCK = 1
    const val STRUM = 2
    const val TREMOLO = 3
    const val HAMMER = 4
    const val MUTE = 5
    const val HARMONIC = 6
    const val BOW_LEGATO = 7
    const val BOW_ACCENT = 8
    const val BREATH_SOFT = 9
    const val BREATH_ACCENT = 10
    const val PERC_OPEN = 11
    const val PERC_CLOSED = 12
    const val PERC_RIM = 13
    const val PERC_BASS = 14
}
