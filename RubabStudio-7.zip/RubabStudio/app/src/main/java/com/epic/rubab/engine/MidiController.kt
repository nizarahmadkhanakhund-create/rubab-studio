package com.epic.rubab.engine

import android.content.Context
import android.content.pm.PackageManager
import android.media.midi.MidiDeviceInfo
import android.media.midi.MidiManager
import android.media.midi.MidiReceiver
import android.os.Handler
import android.os.Looper
import java.util.concurrent.ConcurrentHashMap

/**
 * Optional USB/BLE MIDI input. Parses note-on/off and pitch-bend from the first
 * available MIDI device and routes them through the engine, so external
 * keyboards and controllers play Rubab Studio. Degrades silently on devices
 * without MIDI.
 *
 * @param currentInstrument supplies the instrument id to play (from the VM).
 */
class MidiController(
    private val context: Context,
    private val currentInstrument: () -> Int
) {
    private var manager: MidiManager? = null
    private val noteToTouch = ConcurrentHashMap<Int, Int>()

    fun start() {
        if (!context.packageManager.hasSystemFeature(PackageManager.FEATURE_MIDI)) return
        manager = context.getSystemService(Context.MIDI_SERVICE) as? MidiManager ?: return
        val infos = manager?.devices ?: return
        infos.firstOrNull { it.inputPortCount > 0 || it.outputPortCount > 0 }?.let { open(it) }
    }

    private fun open(info: MidiDeviceInfo) {
        manager?.openDevice(info, { device ->
            if (device == null) return@openDevice
            // Output port of the device = data coming INTO the app.
            val port = device.openOutputPort(0) ?: return@openDevice
            port.connect(object : MidiReceiver() {
                override fun onSend(msg: ByteArray, offset: Int, count: Int, timestamp: Long) {
                    parse(msg, offset, count)
                }
            })
        }, Handler(Looper.getMainLooper()))
    }

    private fun parse(msg: ByteArray, offset: Int, count: Int) {
        var i = offset
        val end = offset + count
        while (i < end) {
            val status = msg[i].toInt() and 0xFF
            val cmd = status and 0xF0
            when (cmd) {
                0x90 -> { // note on
                    if (i + 2 < end) {
                        val note = msg[i + 1].toInt() and 0x7F
                        val vel = msg[i + 2].toInt() and 0x7F
                        if (vel > 0) noteOn(note, vel / 127f) else noteOff(note)
                    }
                    i += 3
                }
                0x80 -> { // note off
                    if (i + 2 < end) noteOff(msg[i + 1].toInt() and 0x7F)
                    i += 3
                }
                0xE0 -> { // pitch bend
                    if (i + 2 < end) {
                        val lsb = msg[i + 1].toInt() and 0x7F
                        val msbv = msg[i + 2].toInt() and 0x7F
                        val value = ((msbv shl 7) or lsb) - 8192
                        val semis = value / 8192f * 2f // ±2 semitone range
                        noteToTouch.values.forEach { AudioController.bend(it, semis) }
                    }
                    i += 3
                }
                else -> i += 1
            }
        }
    }

    private fun noteOn(note: Int, velocity: Float) {
        val tid = AudioController.newTouchId()
        AudioController.noteOn(tid, currentInstrument(), note.toFloat(), velocity, Articulation.PLUCK)
        noteToTouch[note] = tid
    }

    private fun noteOff(note: Int) {
        noteToTouch.remove(note)?.let { AudioController.noteOff(it) }
    }

    fun stop() {
        noteToTouch.values.forEach { AudioController.noteOff(it) }
        noteToTouch.clear()
    }
}
