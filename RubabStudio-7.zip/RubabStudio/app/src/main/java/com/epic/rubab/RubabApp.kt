package com.epic.rubab

import android.app.Application

/** Application entry point. Kept lean — the engine is owned by AudioController
 *  and started/stopped with the Activity lifecycle. */
class RubabApp : Application()
