package com.epic.rubab.instruments

import androidx.compose.ui.graphics.Color

enum class PlaySurface { KEYBOARD, FRETBOARD, PADS }

enum class Family(val display: String) {
    FLAGSHIP("Flagship"),
    ACOUSTIC_STRING("Acoustic Strings"),
    WORLD_STRING("World Strings"),
    CLASSICAL("Classical / World"),
    WIND("Winds"),
    PERCUSSION("Percussion")
}

/**
 * Kotlin mirror of the native InstrumentRegistry. The [id] ordering is the
 * contract between the two layers and must not be reordered. Adding an
 * instrument = append here and in InstrumentRegistry.cpp.
 */
data class InstrumentInfo(
    val id: Int,
    val name: String,
    val family: Family,
    val defaultSurface: PlaySurface,
    val supportsBend: Boolean,
    val lowNote: Int,
    val highNote: Int,
    val accent: Color
)

object Instruments {
    // Ids match native InstrumentId.
    val all: List<InstrumentInfo> = listOf(
        InstrumentInfo(0,  "Acoustic Rubab",      Family.FLAGSHIP,        PlaySurface.FRETBOARD, true,  43, 79, Color(0xFFE0A043)),
        InstrumentInfo(1,  "Steel-String Guitar", Family.ACOUSTIC_STRING, PlaySurface.FRETBOARD, true,  40, 76, Color(0xFFC9A227)),
        InstrumentInfo(2,  "Nylon Guitar",        Family.ACOUSTIC_STRING, PlaySurface.FRETBOARD, true,  40, 76, Color(0xFFB98B4E)),
        InstrumentInfo(3,  "12-String Guitar",    Family.ACOUSTIC_STRING, PlaySurface.FRETBOARD, true,  40, 76, Color(0xFFD4AF37)),
        InstrumentInfo(4,  "Sitar",               Family.WORLD_STRING,    PlaySurface.FRETBOARD, true,  48, 84, Color(0xFFCE5C3D)),
        InstrumentInfo(5,  "Santoor",             Family.WORLD_STRING,    PlaySurface.KEYBOARD,  false, 55, 91, Color(0xFF8FB7C9)),
        InstrumentInfo(6,  "Oud",                 Family.WORLD_STRING,    PlaySurface.FRETBOARD, true,  43, 76, Color(0xFFA9774B)),
        InstrumentInfo(7,  "Mandolin",            Family.ACOUSTIC_STRING, PlaySurface.FRETBOARD, true,  55, 91, Color(0xFFCBB067)),
        InstrumentInfo(8,  "Banjo",               Family.ACOUSTIC_STRING, PlaySurface.FRETBOARD, true,  50, 86, Color(0xFFE2C275)),
        InstrumentInfo(9,  "Acoustic Bass",       Family.ACOUSTIC_STRING, PlaySurface.FRETBOARD, true,  28, 60, Color(0xFF8A6D3B)),
        InstrumentInfo(10, "Grand Piano",         Family.CLASSICAL,       PlaySurface.KEYBOARD,  false, 36, 96, Color(0xFFEDEDED)),
        InstrumentInfo(11, "Violin",              Family.CLASSICAL,       PlaySurface.FRETBOARD, true,  55, 91, Color(0xFFD98C5F)),
        InstrumentInfo(12, "Cello",               Family.CLASSICAL,       PlaySurface.FRETBOARD, true,  36, 72, Color(0xFFB5663B)),
        InstrumentInfo(13, "Viola",               Family.CLASSICAL,       PlaySurface.FRETBOARD, true,  48, 84, Color(0xFFCB7A4E)),
        InstrumentInfo(14, "Concert Flute",       Family.WIND,            PlaySurface.KEYBOARD,  true,  60, 96, Color(0xFFBFD7D1)),
        InstrumentInfo(15, "Bansuri",             Family.WIND,            PlaySurface.KEYBOARD,  true,  60, 90, Color(0xFFA7C4A0)),
        InstrumentInfo(16, "Ney",                 Family.WIND,            PlaySurface.KEYBOARD,  true,  55, 88, Color(0xFFBCB08A)),
        InstrumentInfo(17, "Duduk",               Family.WIND,            PlaySurface.KEYBOARD,  true,  53, 82, Color(0xFF9A7F55)),
        InstrumentInfo(18, "Harmonium",           Family.CLASSICAL,       PlaySurface.KEYBOARD,  false, 48, 84, Color(0xFFBF7F6F)),
        InstrumentInfo(19, "Tabla",               Family.PERCUSSION,      PlaySurface.PADS,      false, 48, 72, Color(0xFFD08A4A)),
        InstrumentInfo(20, "Dhol",                Family.PERCUSSION,      PlaySurface.PADS,      false, 36, 60, Color(0xFFB5633A)),
        InstrumentInfo(21, "Frame Drum",          Family.PERCUSSION,      PlaySurface.PADS,      false, 48, 72, Color(0xFFCBA06A)),
        InstrumentInfo(22, "Cajon",               Family.PERCUSSION,      PlaySurface.PADS,      false, 45, 69, Color(0xFF9C7B57)),
        InstrumentInfo(23, "Hand Percussion",     Family.PERCUSSION,      PlaySurface.PADS,      false, 55, 84, Color(0xFFD9C27A)),
    )

    val flagship: InstrumentInfo get() = all[0]

    fun byId(id: Int): InstrumentInfo = all.getOrElse(id) { all[0] }

    val byFamily: Map<Family, List<InstrumentInfo>> by lazy { all.groupBy { it.family } }
}
