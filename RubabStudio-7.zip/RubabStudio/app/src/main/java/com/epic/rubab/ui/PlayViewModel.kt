package com.epic.rubab.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.epic.rubab.data.AppSettings
import com.epic.rubab.data.SettingsRepository
import com.epic.rubab.data.ThemeMode
import com.epic.rubab.engine.Articulation
import com.epic.rubab.engine.AudioController
import com.epic.rubab.features.assist.MusicTheory
import com.epic.rubab.features.looper.Looper
import com.epic.rubab.features.tuner.Tuner
import com.epic.rubab.innovation.AdaptiveDifficulty
import com.epic.rubab.innovation.PhrasePlayer
import com.epic.rubab.innovation.RubabPhraseGenerator
import com.epic.rubab.instruments.InstrumentInfo
import com.epic.rubab.instruments.Instruments
import com.epic.rubab.instruments.PlaySurface
import com.epic.rubab.util.Haptics
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.io.File
import java.util.concurrent.ConcurrentHashMap

class PlayViewModel(app: Application) : AndroidViewModel(app) {

    private val repo = SettingsRepository(app)
    val haptics = Haptics(app)

    val looper = Looper(viewModelScope)
    val tuner = Tuner()
    private val phraseGen = RubabPhraseGenerator()
    val phrasePlayer = PhrasePlayer()
    val adaptive = AdaptiveDifficulty()

    val settings: StateFlow<AppSettings> =
        repo.settings.stateIn(viewModelScope, SharingStarted.Eagerly, AppSettings())

    private val _activeVoices = MutableStateFlow(0)
    val activeVoices: StateFlow<Int> = _activeVoices

    private val _metronomeOn = MutableStateFlow(false)
    val metronomeOn: StateFlow<Boolean> = _metronomeOn

    private val _recording = MutableStateFlow(false)
    val recording: StateFlow<Boolean> = _recording

    private data class ActiveNote(val localId: Int, val midi: Float)
    private val active = ConcurrentHashMap<Int, ActiveNote>()

    val selectedInstrument: StateFlow<InstrumentInfo> =
        settings.map { Instruments.byId(it.instrumentId) }
            .stateIn(viewModelScope, SharingStarted.Eagerly, Instruments.flagship)

    init {
        // Push audio settings to the engine whenever they change.
        viewModelScope.launch {
            settings.collect { s -> applyAudioSettings(s) }
        }
        // Poll active voice count for the UI meter.
        viewModelScope.launch {
            while (true) {
                _activeVoices.value = AudioController.activeVoices()
                kotlinx.coroutines.delay(100)
            }
        }
    }

    private fun applyAudioSettings(s: AppSettings) {
        if (!AudioController.ready) return
        haptics.enabled = s.haptics
        AudioController.setMasterGain(s.masterGain)
        AudioController.setReverbSpace(s.reverbSpace)
        AudioController.setReverbMix(s.reverbMix)
        // Keep the algorithmic reverb very subtle so the tone stays dry & pure;
        // the (short) convolution reverb carries the main sense of space.
        AudioController.setAlgoReverb(0.4f, 0.6f, (s.reverbMix * 0.2f))
        AudioController.setDelay(380f, 0.33f, s.delayMix)
        AudioController.setModulation(0.5f, 6f, s.chorusMix)
        AudioController.setEq(s.eqLow, s.eqMid, s.eqHigh)
        AudioController.setSpatial(s.spatialWidth, s.spatialDepth)
    }

    /** Called once the engine reports ready to push the initial settings. */
    fun onEngineReady() = applyAudioSettings(settings.value)

    // ---------------- Play API ----------------
    fun noteOn(midi: Float, velocity: Float, articulation: Int = Articulation.PLUCK, artParam: Float = 0f): Int {
        val s = settings.value
        val inst = Instruments.byId(s.instrumentId)
        var m = midi
        if (s.scaleAssist && inst.defaultSurface != PlaySurface.PADS) {
            val scale = MusicTheory.scales[s.scaleIndex.coerceIn(0, MusicTheory.scales.lastIndex)]
            m = MusicTheory.snapToScale(midi.toInt(), s.tonic, scale).toFloat()
        }
        val vel = if (s.dynamicVelocity) velocity.coerceIn(0.05f, 1f) else s.fixedVelocity
        val tid = AudioController.newTouchId()
        AudioController.noteOn(tid, s.instrumentId, m, vel, articulation, artParam)
        haptics.tap(vel)
        if (looper.isRecording) {
            val lid = looper.captureNoteOn(s.instrumentId, m, vel, articulation)
            active[tid] = ActiveNote(lid, m)
        } else {
            active[tid] = ActiveNote(-1, m)
        }
        return tid
    }

    fun noteOff(touchId: Int) {
        AudioController.noteOff(touchId)
        active.remove(touchId)?.let { n ->
            if (n.localId >= 0 && looper.isRecording) looper.captureNoteOff(n.localId, settings.value.instrumentId, n.midi)
        }
    }

    fun bend(touchId: Int, semis: Float) = AudioController.bend(touchId, semis)
    fun pressure(touchId: Int, p: Float) = AudioController.pressure(touchId, p)

    // ---------------- Settings mutations ----------------
    fun selectInstrument(id: Int) = viewModelScope.launch {
        AudioController.allNotesOff()
        repo.setInstrument(id)
        // Default surface follows the instrument on first selection.
        repo.setSurface(Instruments.byId(id).defaultSurface.ordinal)
    }
    fun setSurface(s: PlaySurface) = viewModelScope.launch { repo.setSurface(s.ordinal) }
    fun setOctave(o: Int) = viewModelScope.launch { repo.setOctave(o.coerceIn(1, 7)) }
    fun setScaleAssist(b: Boolean) = viewModelScope.launch { repo.setScaleAssist(b) }
    fun setScale(i: Int) = viewModelScope.launch { repo.setScaleIndex(i) }
    fun setTonic(t: Int) = viewModelScope.launch { repo.setTonic(t) }
    fun setDynamicVelocity(b: Boolean) = viewModelScope.launch { repo.setDynamicVelocity(b) }
    fun setReverbSpace(i: Int) = viewModelScope.launch { repo.setReverbSpace(i) }
    fun setReverbMix(v: Float) = viewModelScope.launch { repo.setReverbMix(v) }
    fun setDelayMix(v: Float) = viewModelScope.launch { repo.setDelayMix(v) }
    fun setChorusMix(v: Float) = viewModelScope.launch { repo.setChorusMix(v) }
    fun setEq(low: Float, mid: Float, high: Float) = viewModelScope.launch { repo.setEq(low, mid, high) }
    fun setSpatial(width: Float, depth: Float) = viewModelScope.launch { repo.setSpatial(width, depth) }
    fun setMasterGain(v: Float) = viewModelScope.launch { repo.setMasterGain(v) }
    fun setHaptics(b: Boolean) = viewModelScope.launch { repo.setHaptics(b) }
    fun setTheme(t: ThemeMode) = viewModelScope.launch { repo.setTheme(t) }
    fun setBpm(v: Float) = viewModelScope.launch { repo.setBpm(v) }

    // ---------------- Transport ----------------
    fun toggleMetronome() {
        val on = !_metronomeOn.value
        _metronomeOn.value = on
        AudioController.setMetronome(on, settings.value.bpm, 4)
    }

    fun toggleRecording() {
        if (AudioController.isRecording()) {
            AudioController.recordDisarm()
            _recording.value = false
        } else {
            AudioController.recordArm()
            _recording.value = true
        }
    }

    fun exportWav(): File? {
        val dir = File(getApplication<Application>().getExternalFilesDir(null), "exports").apply { mkdirs() }
        val file = File(dir, "rubab_${System.currentTimeMillis()}.wav")
        val frames = AudioController.exportWav(file.absolutePath)
        return if (frames > 0) file else null
    }

    // ---------------- Looper ----------------
    fun looperStartRecording() = looper.startRecording(settings.value.instrumentId)
    fun looperStopRecording() = looper.stopRecording()
    fun looperTogglePlay() = if (looper.isPlaying) looper.stopPlayback() else looper.startPlayback()
    fun looperClear() = looper.clearAll()

    // ---------------- Generative ----------------
    fun generateAndPlayPhrase() {
        val s = settings.value
        val scale = MusicTheory.scales[s.scaleIndex.coerceIn(0, MusicTheory.scales.lastIndex)]
        val tonic = 12 * (s.octave + 1) + s.tonic
        val phrase = phraseGen.generatePhrase(scale, tonic, bars = 4, beatMs = (60000f / s.bpm).toLong())
        phrasePlayer.play(viewModelScope, s.instrumentId, phrase, loop = true)
    }
    fun stopPhrase() = phrasePlayer.stop()

    override fun onCleared() {
        super.onCleared()
        phrasePlayer.stop()
        looper.stopPlayback()
        tuner.stop()
    }
}
