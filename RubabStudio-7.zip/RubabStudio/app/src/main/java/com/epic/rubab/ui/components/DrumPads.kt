package com.epic.rubab.ui.components

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.background
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.*
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import com.epic.rubab.engine.Articulation
import com.epic.rubab.instruments.Instruments
import com.epic.rubab.ui.PlayViewModel

private data class Pad(val label: String, val midi: Int, val articulation: Int)

private fun padsFor(instrumentId: Int, lowNote: Int): List<Pad> {
    return when (instrumentId) {
        19 -> listOf( // Tabla bols
            Pad("Dha", lowNote + 0, Articulation.PERC_OPEN),
            Pad("Dhin", lowNote + 4, Articulation.PERC_OPEN),
            Pad("Na", lowNote + 7, Articulation.PERC_CLOSED),
            Pad("Tin", lowNote + 9, Articulation.PERC_CLOSED),
            Pad("Ti", lowNote + 12, Articulation.PERC_RIM),
            Pad("Ke", lowNote + 2, Articulation.PERC_CLOSED),
            Pad("Ge", lowNote - 5, Articulation.PERC_BASS),
            Pad("Dhun", lowNote - 2, Articulation.PERC_BASS),
        )
        else -> listOf(
            Pad("Bass", lowNote - 5, Articulation.PERC_BASS),
            Pad("Open", lowNote + 0, Articulation.PERC_OPEN),
            Pad("Open 2", lowNote + 3, Articulation.PERC_OPEN),
            Pad("Slap", lowNote + 7, Articulation.PERC_CLOSED),
            Pad("Rim", lowNote + 12, Articulation.PERC_RIM),
            Pad("Tone", lowNote + 5, Articulation.PERC_OPEN),
            Pad("Edge", lowNote + 9, Articulation.PERC_CLOSED),
            Pad("High", lowNote + 14, Articulation.PERC_RIM),
        )
    }
}

/**
 * Multi-touch drum pad grid. Each pad maps to a stroke articulation (open,
 * closed, rim, bass) so a single percussion model renders expressive hits —
 * tabla bols, dhol strokes, cajon tones. Velocity comes from where the pad is
 * struck.
 */
@Composable
fun DrumPads(
    vm: PlayViewModel,
    instrumentId: Int,
    lowNote: Int,
    accent: Color,
    modifier: Modifier = Modifier
) {
    val pads = remember(instrumentId, lowNote) { padsFor(instrumentId, lowNote) }
    val cols = 4
    val rows = (pads.size + cols - 1) / cols

    Column(modifier.fillMaxSize().padding(6.dp)) {
        for (r in 0 until rows) {
            Row(Modifier.weight(1f).fillMaxWidth()) {
                for (cIdx in 0 until cols) {
                    val index = r * cols + cIdx
                    if (index < pads.size) {
                        PadButton(pads[index], accent, vm, Modifier.weight(1f).fillMaxHeight().padding(5.dp))
                    } else {
                        Spacer(Modifier.weight(1f))
                    }
                }
            }
        }
    }
}

@Composable
private fun PadButton(pad: Pad, accent: Color, vm: PlayViewModel, modifier: Modifier) {
    var pressed by remember { mutableStateOf(false) }
    var sizePx by remember { mutableStateOf(IntSize.Zero) }
    val active = remember { mutableStateMapOf<PointerId, Int>() }

    Box(
        modifier = modifier
            .clip(RoundedCornerShape(16.dp))
            .background(if (pressed) accent else accent.copy(alpha = 0.16f))
            .onSizeChanged { sizePx = it }
            .pointerInput(pad.midi) {
                awaitPointerEventScope {
                    while (true) {
                        val event = awaitPointerEvent()
                        for (c in event.changes) {
                            when {
                                c.pressed && !active.containsKey(c.id) -> {
                                    val h = sizePx.height.toFloat().coerceAtLeast(1f)
                                    val vel = (0.5f + (c.position.y / h) * 0.5f).coerceIn(0.2f, 1f)
                                    val tid = vm.noteOn(pad.midi.toFloat(), vel, pad.articulation)
                                    active[c.id] = tid
                                    pressed = true
                                    c.consume()
                                }
                                !c.pressed && active.containsKey(c.id) -> {
                                    active.remove(c.id)?.let { vm.noteOff(it) }
                                    if (active.isEmpty()) pressed = false
                                    c.consume()
                                }
                            }
                        }
                    }
                }
            },
        contentAlignment = Alignment.Center
    ) {
        Text(pad.label, color = MaterialTheme.colorScheme.onSurface, style = MaterialTheme.typography.titleMedium)
    }
}
