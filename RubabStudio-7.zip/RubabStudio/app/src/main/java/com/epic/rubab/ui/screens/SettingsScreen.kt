package com.epic.rubab.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.horizontalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.epic.rubab.data.ThemeMode
import com.epic.rubab.features.assist.MusicTheory
import com.epic.rubab.ui.PlayViewModel

private val reverbSpaces = listOf("Room", "Chamber", "Concert Hall", "Cathedral", "Plate")

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(vm: PlayViewModel) {
    val s by vm.settings.collectAsState()

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp)) {
        SectionTitle("Acoustic Space")
        Text("Convolution reverb — procedurally generated impulse responses",
            style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Spacer(Modifier.height(8.dp))
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            reverbSpaces.forEachIndexed { i, name ->
                FilterChip(selected = s.reverbSpace == i, onClick = { vm.setReverbSpace(i) }, label = { Text(name) })
            }
        }
        LabeledSlider("Reverb Mix", s.reverbMix, 0f..1f) { vm.setReverbMix(it) }
        LabeledSlider("Spatial Width", s.spatialWidth, 0f..2f) { vm.setSpatial(it, s.spatialDepth) }
        LabeledSlider("Spatial Depth", s.spatialDepth, 0f..1f) { vm.setSpatial(s.spatialWidth, it) }

        SectionTitle("Time & Modulation")
        LabeledSlider("Delay Mix", s.delayMix, 0f..1f) { vm.setDelayMix(it) }
        LabeledSlider("Chorus / Ensemble", s.chorusMix, 0f..1f) { vm.setChorusMix(it) }

        SectionTitle("Tone (EQ)")
        LabeledSlider("Low", s.eqLow, -12f..12f, "dB") { vm.setEq(it, s.eqMid, s.eqHigh) }
        LabeledSlider("Mid", s.eqMid, -12f..12f, "dB") { vm.setEq(s.eqLow, it, s.eqHigh) }
        LabeledSlider("High", s.eqHigh, -12f..12f, "dB") { vm.setEq(s.eqLow, s.eqMid, it) }

        SectionTitle("Master")
        LabeledSlider("Output Gain", s.masterGain, 0f..1.2f) { vm.setMasterGain(it) }
        LabeledSlider("Tempo (BPM)", s.bpm, 40f..220f, "bpm") { vm.setBpm(it) }

        SectionTitle("Scale & Assist")
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            MusicTheory.noteNames.forEachIndexed { i, n ->
                FilterChip(selected = s.tonic == i, onClick = { vm.setTonic(i) }, label = { Text(n) })
            }
        }
        Spacer(Modifier.height(6.dp))
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            MusicTheory.scales.forEachIndexed { i, sc ->
                FilterChip(selected = s.scaleIndex == i, onClick = { vm.setScale(i) }, label = { Text(sc.name) })
            }
        }
        ToggleRow("Snap notes to scale", s.scaleAssist) { vm.setScaleAssist(it) }
        ToggleRow("Dynamic velocity (touch position)", s.dynamicVelocity) { vm.setDynamicVelocity(it) }

        SectionTitle("Feel")
        ToggleRow("Haptic feedback", s.haptics) { vm.setHaptics(it) }

        SectionTitle("Appearance")
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            ThemeMode.entries.forEach { t ->
                FilterChip(selected = s.theme == t, onClick = { vm.setTheme(t) },
                    label = { Text(t.name.lowercase().replaceFirstChar { it.uppercase() }) })
            }
        }
        Spacer(Modifier.height(40.dp))
    }
}

@Composable
private fun SectionTitle(text: String) {
    Spacer(Modifier.height(18.dp))
    Text(text, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold,
        color = MaterialTheme.colorScheme.primary)
    Spacer(Modifier.height(4.dp))
}

@Composable
private fun LabeledSlider(label: String, value: Float, range: ClosedFloatingPointRange<Float>,
                          unit: String = "", onChange: (Float) -> Unit) {
    Column(Modifier.padding(vertical = 2.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(label, style = MaterialTheme.typography.labelSmall)
            Text(if (unit.isEmpty()) String.format("%.2f", value) else "${value.toInt()} $unit",
                style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Slider(value = value, onValueChange = onChange, valueRange = range)
    }
}

@Composable
private fun ToggleRow(label: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth().padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(label, Modifier.weight(1f), style = MaterialTheme.typography.titleMedium)
        Switch(checked = checked, onCheckedChange = onChange)
    }
}
