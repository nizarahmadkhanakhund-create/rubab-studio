package com.epic.rubab.innovation

import com.epic.rubab.engine.Articulation
import kotlin.math.abs

/**
 * Heuristic expressive-articulation detection from raw touch gesture features.
 * The fretboard/pad surfaces feed gesture data here and the detector decides
 * which articulation the engine should use — turning a touchscreen into an
 * expressive controller without the player choosing modes manually.
 */
object ArticulationDetector {

    data class Gesture(
        val pressVelocity: Float,   // 0..1, derived from press speed / size
        val horizontalDragPx: Float,
        val verticalDragPx: Float,
        val durationMs: Long,
        val tapIntervalMs: Long,    // time since previous tap at same area
        val nearEdge: Boolean       // near string edge → mute/harmonic zone
    )

    data class Result(val articulation: Int, val param: Float)

    /** Classifies a press into an articulation + parameter. */
    fun classify(g: Gesture, supportsBend: Boolean): Result {
        // Rapid repeated taps → tremolo; param carries the rate in Hz.
        if (g.tapIntervalMs in 1..140) {
            val rate = (1000f / g.tapIntervalMs).coerceIn(6f, 18f)
            return Result(Articulation.TREMOLO, rate)
        }
        // A fast vertical swipe across strings → strum; param = stagger.
        if (abs(g.verticalDragPx) > 80f && g.durationMs < 160) {
            return Result(Articulation.STRUM, (abs(g.verticalDragPx) / 400f).coerceIn(0f, 1f))
        }
        // Edge zone with a light touch → harmonic; firm → mute.
        if (g.nearEdge) {
            return if (g.pressVelocity < 0.35f) Result(Articulation.HARMONIC, 0f)
            else Result(Articulation.MUTE, 0f)
        }
        // Very soft, slow press → hammer/legato feel.
        if (g.pressVelocity < 0.25f) return Result(Articulation.HAMMER, 0f)
        // Default pluck.
        return Result(Articulation.PLUCK, 0f)
    }

    /**
     * Converts a horizontal drag during a held note into a meend (pitch bend)
     * in semitones. Non-linear so small moves are subtle and large pulls reach
     * a full tone-and-a-half — the classic Rubab/sitar gesture.
     */
    fun dragToBend(horizontalDragPx: Float, stringSpacingPx: Float, maxSemis: Float = 3f): Float {
        val norm = (horizontalDragPx / (stringSpacingPx * 3f)).coerceIn(-1f, 1f)
        val shaped = norm * abs(norm) // ease-in curve
        return shaped * maxSemis
    }

    /** Vertical finger movement on a held note → aftertouch-style vibrato/pressure. */
    fun dragToPressure(verticalDragPx: Float, rangePx: Float): Float =
        (abs(verticalDragPx) / rangePx).coerceIn(0f, 1f)
}
