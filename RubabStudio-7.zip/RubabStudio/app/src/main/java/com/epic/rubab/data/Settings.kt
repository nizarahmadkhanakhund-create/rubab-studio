package com.epic.rubab.data

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.*
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "rubab_settings")

enum class ThemeMode { SYSTEM, DARK, LIGHT }

data class AppSettings(
    val instrumentId: Int = 0,
    val surface: Int = 0,          // ordinal of PlaySurface
    val octave: Int = 4,
    val dynamicVelocity: Boolean = true,
    val fixedVelocity: Float = 0.8f,
    val scaleIndex: Int = 1,       // Major
    val tonic: Int = 0,            // C
    val scaleAssist: Boolean = false,
    val masterGain: Float = 0.9f,
    val reverbSpace: Int = 0,      // Room (short, clean)
    val reverbMix: Float = 0.10f,  // subtle by default — dry & pure
    val delayMix: Float = 0.0f,
    val chorusMix: Float = 0.0f,
    val eqLow: Float = 0f,
    val eqMid: Float = 0f,
    val eqHigh: Float = 0f,
    val spatialWidth: Float = 1.05f,
    val spatialDepth: Float = 0.18f,
    val haptics: Boolean = true,
    val theme: ThemeMode = ThemeMode.SYSTEM,
    val bpm: Float = 100f
)

class SettingsRepository(private val context: Context) {
    private object Keys {
        val instrument = intPreferencesKey("instrument")
        val surface = intPreferencesKey("surface")
        val octave = intPreferencesKey("octave")
        val dynVel = booleanPreferencesKey("dynVel")
        val fixedVel = floatPreferencesKey("fixedVel")
        val scaleIdx = intPreferencesKey("scaleIdx")
        val tonic = intPreferencesKey("tonic")
        val scaleAssist = booleanPreferencesKey("scaleAssist")
        val masterGain = floatPreferencesKey("masterGain")
        val reverbSpace = intPreferencesKey("reverbSpace")
        val reverbMix = floatPreferencesKey("reverbMix")
        val delayMix = floatPreferencesKey("delayMix")
        val chorusMix = floatPreferencesKey("chorusMix")
        val eqLow = floatPreferencesKey("eqLow")
        val eqMid = floatPreferencesKey("eqMid")
        val eqHigh = floatPreferencesKey("eqHigh")
        val spatialWidth = floatPreferencesKey("spatialWidth")
        val spatialDepth = floatPreferencesKey("spatialDepth")
        val haptics = booleanPreferencesKey("haptics")
        val theme = intPreferencesKey("theme")
        val bpm = floatPreferencesKey("bpm")
    }

    val settings: Flow<AppSettings> = context.dataStore.data.map { p ->
        AppSettings(
            instrumentId = p[Keys.instrument] ?: 0,
            surface = p[Keys.surface] ?: 0,
            octave = p[Keys.octave] ?: 4,
            dynamicVelocity = p[Keys.dynVel] ?: true,
            fixedVelocity = p[Keys.fixedVel] ?: 0.8f,
            scaleIndex = p[Keys.scaleIdx] ?: 1,
            tonic = p[Keys.tonic] ?: 0,
            scaleAssist = p[Keys.scaleAssist] ?: false,
            masterGain = p[Keys.masterGain] ?: 0.9f,
            reverbSpace = p[Keys.reverbSpace] ?: 2,
            reverbMix = p[Keys.reverbMix] ?: 0.22f,
            delayMix = p[Keys.delayMix] ?: 0f,
            chorusMix = p[Keys.chorusMix] ?: 0f,
            eqLow = p[Keys.eqLow] ?: 0f,
            eqMid = p[Keys.eqMid] ?: 0f,
            eqHigh = p[Keys.eqHigh] ?: 0f,
            spatialWidth = p[Keys.spatialWidth] ?: 1.2f,
            spatialDepth = p[Keys.spatialDepth] ?: 0.35f,
            haptics = p[Keys.haptics] ?: true,
            theme = ThemeMode.entries[(p[Keys.theme] ?: 0).coerceIn(0, 2)],
            bpm = p[Keys.bpm] ?: 100f
        )
    }

    // Typed convenience setters.
    suspend fun setInstrument(id: Int) = context.dataStore.edit { it[Keys.instrument] = id }
    suspend fun setSurface(s: Int) = context.dataStore.edit { it[Keys.surface] = s }
    suspend fun setOctave(o: Int) = context.dataStore.edit { it[Keys.octave] = o }
    suspend fun setDynamicVelocity(b: Boolean) = context.dataStore.edit { it[Keys.dynVel] = b }
    suspend fun setFixedVelocity(v: Float) = context.dataStore.edit { it[Keys.fixedVel] = v }
    suspend fun setScaleIndex(i: Int) = context.dataStore.edit { it[Keys.scaleIdx] = i }
    suspend fun setTonic(t: Int) = context.dataStore.edit { it[Keys.tonic] = t }
    suspend fun setScaleAssist(b: Boolean) = context.dataStore.edit { it[Keys.scaleAssist] = b }
    suspend fun setMasterGain(v: Float) = context.dataStore.edit { it[Keys.masterGain] = v }
    suspend fun setReverbSpace(i: Int) = context.dataStore.edit { it[Keys.reverbSpace] = i }
    suspend fun setReverbMix(v: Float) = context.dataStore.edit { it[Keys.reverbMix] = v }
    suspend fun setDelayMix(v: Float) = context.dataStore.edit { it[Keys.delayMix] = v }
    suspend fun setChorusMix(v: Float) = context.dataStore.edit { it[Keys.chorusMix] = v }
    suspend fun setEq(low: Float, mid: Float, high: Float) = context.dataStore.edit {
        it[Keys.eqLow] = low; it[Keys.eqMid] = mid; it[Keys.eqHigh] = high
    }
    suspend fun setSpatial(width: Float, depth: Float) = context.dataStore.edit {
        it[Keys.spatialWidth] = width; it[Keys.spatialDepth] = depth
    }
    suspend fun setHaptics(b: Boolean) = context.dataStore.edit { it[Keys.haptics] = b }
    suspend fun setTheme(t: ThemeMode) = context.dataStore.edit { it[Keys.theme] = t.ordinal }
    suspend fun setBpm(v: Float) = context.dataStore.edit { it[Keys.bpm] = v }
}
