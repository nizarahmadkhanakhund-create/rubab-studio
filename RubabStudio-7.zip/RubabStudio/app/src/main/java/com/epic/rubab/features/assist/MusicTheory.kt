package com.epic.rubab.features.assist

/** Scales, ragas and chords used by the scale/chord assist and learn mode. */
object MusicTheory {

    val noteNames = arrayOf("C", "C#", "D", "D#", "E", "F", "F#", "G", "G#", "A", "A#", "B")

    fun noteName(midi: Int): String {
        val n = ((midi % 12) + 12) % 12
        val octave = midi / 12 - 1
        return "${noteNames[n]}$octave"
    }

    /** Scale/raga definitions as semitone offsets from the tonic. */
    data class Scale(val name: String, val intervals: List<Int>)

    val scales = listOf(
        Scale("Chromatic",    (0..11).toList()),
        Scale("Major (Ionian)", listOf(0, 2, 4, 5, 7, 9, 11)),
        Scale("Natural Minor", listOf(0, 2, 3, 5, 7, 8, 10)),
        Scale("Harmonic Minor", listOf(0, 2, 3, 5, 7, 8, 11)),
        Scale("Dorian",       listOf(0, 2, 3, 5, 7, 9, 10)),
        Scale("Phrygian",     listOf(0, 1, 3, 5, 7, 8, 10)),
        Scale("Mixolydian",   listOf(0, 2, 4, 5, 7, 9, 10)),
        Scale("Pentatonic Major", listOf(0, 2, 4, 7, 9)),
        Scale("Pentatonic Minor", listOf(0, 3, 5, 7, 10)),
        // A few ragas (ascending, simplified).
        Scale("Raga Yaman",   listOf(0, 2, 4, 6, 7, 9, 11)),
        Scale("Raga Bhairav", listOf(0, 1, 4, 5, 7, 8, 11)),
        Scale("Raga Bhairavi", listOf(0, 1, 3, 5, 7, 8, 10)),
        Scale("Raga Kafi",    listOf(0, 2, 3, 5, 7, 9, 10)),
    )

    fun isInScale(midi: Int, tonic: Int, scale: Scale): Boolean {
        val rel = (((midi - tonic) % 12) + 12) % 12
        return scale.intervals.contains(rel)
    }

    /** Snaps a midi note to the nearest scale tone (used by the assist/learn). */
    fun snapToScale(midi: Int, tonic: Int, scale: Scale): Int {
        if (scale.intervals.size >= 12) return midi
        for (d in 0..6) {
            if (isInScale(midi - d, tonic, scale)) return midi - d
            if (isInScale(midi + d, tonic, scale)) return midi + d
        }
        return midi
    }

    data class Chord(val name: String, val intervals: List<Int>)

    val chords = listOf(
        Chord("Maj",   listOf(0, 4, 7)),
        Chord("Min",   listOf(0, 3, 7)),
        Chord("Maj7",  listOf(0, 4, 7, 11)),
        Chord("Min7",  listOf(0, 3, 7, 10)),
        Chord("Dom7",  listOf(0, 4, 7, 10)),
        Chord("Sus2",  listOf(0, 2, 7)),
        Chord("Sus4",  listOf(0, 5, 7)),
        Chord("Add9",  listOf(0, 4, 7, 14)),
        Chord("Dim",   listOf(0, 3, 6)),
    )

    fun chordNotes(rootMidi: Int, chord: Chord): List<Int> = chord.intervals.map { rootMidi + it }
}
