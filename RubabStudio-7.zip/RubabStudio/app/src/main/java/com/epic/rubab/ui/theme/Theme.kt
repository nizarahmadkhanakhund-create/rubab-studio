package com.epic.rubab.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp
import com.epic.rubab.data.ThemeMode

// Warm, wood-and-amber palette evoking an acoustic instrument.
private val Amber = Color(0xFFE0A043)
private val AmberDeep = Color(0xFFB9772B)
private val Ember = Color(0xFFCE5C3D)

private val DarkColors = darkColorScheme(
    primary = Amber,
    onPrimary = Color(0xFF1A120B),
    secondary = Ember,
    onSecondary = Color(0xFF1A120B),
    tertiary = Color(0xFF8FB7C9),
    background = Color(0xFF14100C),
    onBackground = Color(0xFFEFE6DA),
    surface = Color(0xFF1E1813),
    onSurface = Color(0xFFEFE6DA),
    surfaceVariant = Color(0xFF2A221B),
    onSurfaceVariant = Color(0xFFCDBFAE),
    outline = Color(0xFF6B5A47)
)

private val LightColors = lightColorScheme(
    primary = AmberDeep,
    onPrimary = Color.White,
    secondary = Ember,
    background = Color(0xFFFBF3E7),
    onBackground = Color(0xFF221A12),
    surface = Color(0xFFFFF8EE),
    onSurface = Color(0xFF221A12),
    surfaceVariant = Color(0xFFEADFCB),
    outline = Color(0xFFB5A588)
)

private val AppTypography = Typography(
    headlineSmall = TextStyle(fontWeight = FontWeight.SemiBold, fontSize = 22.sp),
    titleMedium = TextStyle(fontWeight = FontWeight.Medium, fontSize = 16.sp),
    labelSmall = TextStyle(fontWeight = FontWeight.Medium, fontSize = 11.sp)
)

@Composable
fun RubabTheme(theme: ThemeMode, content: @Composable () -> Unit) {
    val dark = when (theme) {
        ThemeMode.SYSTEM -> isSystemInDarkTheme()
        ThemeMode.DARK -> true
        ThemeMode.LIGHT -> false
    }
    MaterialTheme(
        colorScheme = if (dark) DarkColors else LightColors,
        typography = AppTypography,
        content = content
    )
}
