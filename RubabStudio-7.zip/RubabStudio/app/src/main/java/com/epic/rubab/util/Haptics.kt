package com.epic.rubab.util

import android.content.Context
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager

/** Lightweight expressive haptics for note-ons, pad hits and UI confirmation. */
class Haptics(context: Context) {

    private val vibrator: Vibrator? = runCatching {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            val mgr = context.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as? VibratorManager
            mgr?.defaultVibrator
        } else {
            @Suppress("DEPRECATION")
            context.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
        }
    }.getOrNull()

    var enabled: Boolean = true

    /** Velocity-scaled tap: harder hits feel stronger. */
    fun tap(velocity: Float) {
        if (!enabled) return
        val v = vibrator ?: return
        if (!v.hasVibrator()) return
        val amp = (40 + (velocity.coerceIn(0f, 1f) * 160f)).toInt().coerceIn(1, 255)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            v.vibrate(VibrationEffect.createOneShot(12, amp))
        } else {
            @Suppress("DEPRECATION") v.vibrate(12)
        }
    }

    fun click() {
        if (!enabled) return
        val v = vibrator ?: return
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            v.vibrate(VibrationEffect.createOneShot(8, 90))
        } else {
            @Suppress("DEPRECATION") v.vibrate(8)
        }
    }
}
