package com.epic.rubab.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.epic.rubab.engine.Articulation
import com.epic.rubab.features.assist.MusicTheory
import com.epic.rubab.ui.PlayViewModel
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

@Composable
fun LearnScreen(vm: PlayViewModel) {
    val s by vm.settings.collectAsState()
    val scope = rememberCoroutineScope()
    val scale = MusicTheory.scales[s.scaleIndex.coerceIn(0, MusicTheory.scales.lastIndex)]
    val tonicMidi = 12 * (s.octave + 1) + s.tonic

    // Practice pitches: one octave of the current scale.
    val practice = remember(scale, tonicMidi) {
        (scale.intervals.map { tonicMidi + it } + (tonicMidi + 12))
    }

    var target by remember { mutableStateOf(practice.random()) }
    var shownAt by remember { mutableStateOf(System.currentTimeMillis()) }
    var feedback by remember { mutableStateOf("Tap the highlighted note") }
    var level by remember { mutableStateOf(vm.adaptive.level) }
    var accuracy by remember { mutableStateOf(0f) }
    val diff = vm.adaptive.current()

    fun nextTarget() {
        target = practice.random()
        shownAt = System.currentTimeMillis()
    }

    fun onPlay(note: Int) {
        val tid = vm.noteOn(note.toFloat(), 0.8f, Articulation.PLUCK)
        scope.launch { delay(450); vm.noteOff(tid) }
        val correct = note == target
        val timing = System.currentTimeMillis() - shownAt
        val hit = correct && timing <= diff.timingWindowMs
        vm.adaptive.record(hit, if (correct) timing else 9999L)
        level = vm.adaptive.level
        accuracy = vm.adaptive.accuracy()
        feedback = when {
            hit -> "Perfect! (${timing}ms)"
            correct -> "Right note, a touch late"
            else -> "That was ${MusicTheory.noteName(note)} — try again"
        }
        if (correct) nextTarget()
    }

    Column(Modifier.fillMaxSize().padding(20.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Text("Adaptive Practice", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        Text("Difficulty rises and falls with your accuracy and timing — entirely on-device.",
            style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
            textAlign = TextAlign.Center)
        Spacer(Modifier.height(16.dp))

        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
            Stat("Level", "$level/10")
            Stat("Accuracy", "${(accuracy * 100).toInt()}%")
            Stat("Tempo", "${diff.tempoBpm.toInt()} bpm")
        }
        LinearProgressIndicator(progress = level / 10f, modifier = Modifier.fillMaxWidth().padding(vertical = 12.dp))

        Spacer(Modifier.height(12.dp))
        Surface(color = MaterialTheme.colorScheme.primary, shape = RoundedCornerShape(20.dp)) {
            Column(Modifier.padding(horizontal = 36.dp, vertical = 24.dp),
                horizontalAlignment = Alignment.CenterHorizontally) {
                Text("PLAY", style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onPrimary)
                Text(MusicTheory.noteName(target), style = MaterialTheme.typography.displayMedium,
                    fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onPrimary)
            }
        }
        Spacer(Modifier.height(12.dp))
        Text(feedback, style = MaterialTheme.typography.titleMedium)

        Spacer(Modifier.height(24.dp))
        // Note buttons
        FlowNoteButtons(practice, target) { onPlay(it) }
    }
}

@Composable
private fun Stat(label: String, value: String) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(value, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.primary)
        Text(label, style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
private fun FlowNoteButtons(notes: List<Int>, target: Int, onPlay: (Int) -> Unit) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        notes.chunked(4).forEach { row ->
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.padding(vertical = 5.dp)) {
                row.forEach { n ->
                    val isTarget = n == target
                    Button(
                        onClick = { onPlay(n) },
                        colors = if (isTarget) ButtonDefaults.buttonColors()
                        else ButtonDefaults.filledTonalButtonColors()
                    ) { Text(MusicTheory.noteName(n)) }
                }
            }
        }
    }
}
