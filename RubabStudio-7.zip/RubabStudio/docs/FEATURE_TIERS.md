# Feature tiers

Per the brief: **A** = fully implemented and working on first run; **B** = fully
implemented with a working procedural/local fallback; **C** = working local
on-device implementation (no external service). Nothing was trimmed.

## 1. Instruments
| Feature | Tier | Notes |
|---|---|---|
| Acoustic Rubab (flagship) | A | Extended KS: pluck, strum, tremolo, meend, body resonance, sympathetic ring, damping, velocity, round-robin (per-voice RNG), inharmonicity, jawari buzz |
| Steel / nylon / 12-string guitar | A | 12-string uses unison courses |
| Sitar / santoor / oud / mandolin / banjo / acoustic bass | A | Sitar: sympathetic + buzz + meend |
| Piano / violin / cello / viola | A | Bowed friction model; piano coupled strings |
| Flute / bansuri / ney / duduk / harmonium | A | Breath resonator bank; harmonium sustained reed |
| Tabla / dhol / frame drum / cajon / hand percussion | A | Modal; tabla bols + pitch glide |
| Modular registry (plug-in instruments) | A | Data-driven `InstrumentRegistry` |

## 2. Sound engine
| Feature | Tier | Notes |
|---|---|---|
| C++ via Oboe/JNI, low-latency, polyphony + voice stealing | A | Pooled voices, lock-free events |
| Per-instrument synthesis (KS+dispersion+body, modal, wavetable/additive, bowed) | A | 5 distinct models |
| Distinct timbre & articulation per instrument | A | Via `InstrumentParams` + model choice |
| Convolution reverb w/ procedural IRs (multiple spaces) | A | FFT partitioned; 5 spaces |
| Algorithmic reverb, delay, EQ, saturation, modulation | A | Full master chain |
| Per-instrument default presets | A | Registry defaults + FX defaults |
| Sample-rate handling, denormal protection, click-free start/stop | A | |
| MIDI input | A | `MidiController` (note on/off, pitch bend) |
| WAV export | A | `Recorder` + `WavWriter` |
| Bundled samples | B | Models are procedural (no sample licensing needed); sample layering hooks exist in the plucked excitation path |

## 3. UI / UX
| Feature | Tier | Notes |
|---|---|---|
| Keyboard / fretboard / drum-pad surfaces (multi-touch) | A | |
| Bend/vibrato gestures (fretboard) | A | Horizontal = meend, vertical = vibrato |
| Velocity + pressure-style expression | A | Position-derived velocity; drag pressure |
| Haptics, animations, themes, adaptive layouts | A | Light/dark warm theme |
| Recording, multi-track looping | A | Gesture-based looper |
| Metronome, tuner | A | On-device autocorrelation tuner |
| Scale/chord assist, learning mode | A | Scales + ragas; adaptive learn |
| Settings persistence | A | DataStore |

## 4. Technical
| Feature | Tier | Notes |
|---|---|---|
| Kotlin + C++/JNI, Gradle Kotlin DSL, CMake, NDK | A | |
| Android 8.0+ (API 26), compileSdk 34 | A | |
| Modular packages, manifest permissions, ProGuard | A | |

## 5. On-device innovation
| Feature | Tier | Notes |
|---|---|---|
| Markov Rubab phrase generator + accompaniment | C | `RubabPhraseGenerator` + `PhrasePlayer` |
| Heuristic articulation detection from gesture | C | `ArticulationDetector` |
| Adaptive difficulty learn mode | C | `AdaptiveDifficulty` |
| Spatial audio rendering | C | `Spatializer` (width + early reflections + head shadow) |
