# Architecture

Two layers talk over a thin JNI bridge.

```
┌─────────────────────────────────────────────────────────────┐
│  Kotlin / Jetpack Compose (UI + features + on-device AI)      │
│                                                               │
│  MainActivity ─ AppRoot(nav) ─ PlayViewModel                  │
│     ├─ ui/components: Keyboard · Fretboard · DrumPads         │
│     ├─ ui/screens:    Play · Looper · Learn · Tuner · Studio  │
│     ├─ features:      Looper · Tuner · MusicTheory(assist)    │
│     ├─ innovation:    Markov phrases · ArticulationDetector · │
│     │                 AdaptiveDifficulty                      │
│     ├─ data:          SettingsRepository (DataStore)          │
│     └─ engine:        AudioController · MidiController         │
│                              │ NativeBridge (JNI)             │
└──────────────────────────────┼───────────────────────────────┘
                               ▼
┌─────────────────────────────────────────────────────────────┐
│  C++ realtime engine  (librubabengine.so, Oboe)              │
│                                                               │
│  native-lib.cpp  ──►  AudioEngine (Oboe callback)            │
│     ├─ lock-free event queue (UI thread → audio thread)      │
│     ├─ VoiceAllocator (pooled voices + voice stealing)       │
│     │     ├─ PluckedStringVoice  (extended Karplus–Strong)   │
│     │     ├─ BowedStringVoice    (stick-slip friction)       │
│     │     ├─ WindVoice           (breath resonator bank)     │
│     │     ├─ ModalPercussionVoice(modal + transient)         │
│     │     └─ KeyedVoice          (piano / harmonium)         │
│     ├─ SympatheticBank (sitar/rubab tarab resonance)         │
│     ├─ FX chain: EQ → Spatializer → Chorus → Delay →         │
│     │            AlgoReverb → ConvolutionReverb → Saturator  │
│     ├─ ImpulseFactory (procedural IRs) + Fft                 │
│     └─ Recorder → WavWriter (offline WAV export)             │
│                                                               │
│  InstrumentRegistry (data-driven; drives the generic voices) │
└─────────────────────────────────────────────────────────────┘
```

## Realtime discipline

- **No allocation on the audio thread.** Voices, delay lines, reverb buffers and the
  record buffer are all sized up-front in `prepare()`.
- **UI → audio communication is lock-free**: `AudioEngine` exposes `postNoteOn/Off/
  Bend/Pressure` which enqueue small PODs; the audio callback drains them. Producers
  are serialised with a mutex *off* the audio thread only.
- **Parameters** are atomics applied at block boundaries. The convolution IR can be
  swapped off-thread; the callback uses `try_lock` so it never blocks.
- **Denormals** are flushed in every feedback path (`flushDenorm`), and gains ramp
  to avoid clicks on start/stop/steal.

## Synthesis models (why each instrument sounds distinct)

| Model | Instruments | Technique |
|-------|-------------|-----------|
| `PluckedStringVoice` | rubab, guitars, 12-string, sitar, santoor, oud, mandolin, banjo, bass | Waveguide (fractional delay) + dispersion all-pass cascade (inharmonicity) + one-pole loop damping (brightness/decay) + dual body biquads + jawari buzz nonlinearity + unison courses + per-sample meend/vibrato |
| `BowedStringVoice` | violin, cello, viola | Waveguide driven by a saturating stick-slip friction curve → Helmholtz motion; body resonances; bow attack/pressure/vibrato |
| `WindVoice` | flute, bansuri, ney, duduk | Breath-noise excitation into a bank of high-Q harmonic resonators morphed flute↔reed; formant colour; breath envelope |
| `ModalPercussionVoice` | tabla, dhol, frame drum, cajon, hand perc | Bank of tuned two-pole modal resonators + membrane transient; stroke articulations reshape modes; tabla pitch glide |
| `KeyedVoice` | piano, harmonium | Piano: coupled, detuned, inharmonic hammered strings + soundboard. Harmonium: additive free-reed drone with beating + bellows noise |

The instrument's timbre is entirely **data** (`InstrumentParams`). The engine chooses
a model and feeds it parameters — so adding an instrument is a registry edit, not an
engine change.

### Premium voicing layer (every string / every key individually voiced)

Rather than one parameter set stretched across the whole range, each note is voiced
for its register and humanised:

- **Per-register morph** — decay, brightness and inharmonicity interpolate across the
  playable range (`registerT` + low/high scale params). Low strings ring long, warm
  and stiffer; high notes are tight and bright — on plucked, bowed, wind and keyed.
- **Dual-polarization strings** (plucked) — two coupled waveguides per string, micro-
  detuned with different decay (`ks_polarDetune/Decay/Level`). This produces the
  two-stage decay, bloom and gentle beating of a real plucked string.
- **3-mode body + air resonator**, a **finger/pick contact transient** at the attack,
  and **per-note micro-detune** (`ks_humanCents`) so no two plucks are identical.
- The **Acoustic Rubab** is the most carefully tuned: mulberry-bowl + mid + goat-skin
  "sparkle" body modes, 13 sympathetic strings, jawari buzz, register voicing across
  G2–G5, dual polarization and finger noise.

## Effects

- **ConvolutionReverb** — uniform-partitioned overlap-add FFT convolution against a
  stereo IR from `ImpulseFactory` (early-reflection pattern + decorrelated damped
  diffuse tail per space). Fixed partition-sized latency on the wet path only.
- **AlgoReverb** — Freeverb (8 combs + 4 all-passes / channel), always available.
- **Spatializer** — mid/side width + decorrelated early reflections + head-shadow
  tilt for a sense of stage depth.
- **Delay / Modulation / Biquad EQ / Saturator** — stereo, parameterised from the UI.

## On-device innovation

- `RubabPhraseGenerator` — weighted Markov transition matrix over scale degrees,
  tuned for idiomatic rubab motion; `PhrasePlayer` schedules it (loopable) through
  the engine as live accompaniment.
- `ArticulationDetector` — maps gesture features (press velocity, drag vectors, tap
  interval, edge zone) to articulations, and turns horizontal drag into non-linear
  meend and vertical drag into vibrato/pressure.
- `AdaptiveDifficulty` — rolling-window accuracy/timing model that raises or lowers
  level, tempo, note density and the timing window to keep practice in flow.
